from pathlib import Path
import subprocess,tarfile,json,hashlib
root=Path("/Users/biran/code/skills/loop/Orca");a=root/"worktree-archives/2026-10-10-main-cleanup"
def git(*args):return subprocess.check_output(["/usr/bin/git","-C",str(root),*args],text=True)
assert git("branch","--show-current").strip()=="main"
paths=[("control-foundation","/Users/biran/.codex/worktrees/control-foundation-0919/Orca"),("usage-settlement","/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca"),(None,"/Users/biran/.codex/worktrees/codex-skill-support/Orca")]
for name,path in paths:
 p=Path(path);head=subprocess.check_output(["/usr/bin/git","-C",path,"rev-parse","HEAD"],text=True).strip();subprocess.run(["/usr/bin/git","-C",str(root),"merge-base","--is-ancestor",head,"main"],check=True)
 if name:
  m=json.loads((a/(name+"-ignored-manifest.json")).read_text())
  for f,expected in m.items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==expected["sha256"],f
 if name=="control-foundation":
  with tarfile.open(a/"control-foundation-handoff.tar.gz") as t:assert t.extractfile("control-foundation-handoff.md").read()==(p/"docs/handoff/handoff.md").read_bytes()
  subprocess.run(["/usr/bin/git","-C",path,"restore","--","docs/handoff/handoff.md"],check=True)
 if (p/"node_modules").is_symlink():assert (p/"node_modules").readlink()==root/"node_modules";(p/"node_modules").unlink()
 assert subprocess.check_output(["/usr/bin/git","-C",path,"status","--porcelain","-uall"])==b""
 subprocess.run(["/usr/bin/git","-C",str(root),"worktree","remove",path],check=True);print("removed",path,flush=True)
for b in ["codex/control-foundation-0919","codex/d9-m3-implementation","codex/feedback-maintenance-20261010","codex/usage-settlement-handoff-retry","ui/panel-contrast","ui/panel-redesign"]:
 subprocess.run(["/usr/bin/git","-C",str(root),"merge-base","--is-ancestor",b,"main"],check=True);subprocess.run(["/usr/bin/git","-C",str(root),"branch","-d",b],check=True)
subprocess.run(["/usr/bin/git","-C",str(root),"worktree","prune"],check=True)
