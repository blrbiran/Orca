import subprocess,json,sys
from pathlib import Path
r=Path(__file__).parent;e=json.loads((r/"env.json").read_text());results=[]
steps=[
("build",["npm","run","build"],"/Users/biran/code/skills/loop/Orca"),
("typecheck",["npm","run","typecheck"],"/Users/biran/code/skills/loop/Orca"),
("web-build",["npm","run","build","--workspace","web"],"/Users/biran/code/skills/loop/Orca"),
("panel",["npm","run","verify:panel"],"/Users/biran/code/skills/loop/Orca"),
("pin",["npm","run","verify:ccloop-pin"],"/Users/biran/code/skills/loop/Orca"),
("ccloop-typecheck",["npm","run","typecheck"],"/Users/biran/code/skills/loop/ccloop"),
("ccloop-build",["npm","run","build"],"/Users/biran/code/skills/loop/ccloop"),
("ccmem-config",["node","--test","tests/unit/v013-config-sync.test.mjs","tests/unit/v013-config-fallback.test.mjs","tests/unit/v014-config-delta.test.mjs","tests/unit/v014-config-value-parity.test.mjs"],"/Users/biran/code/skills/ccmem")
]
for name,argv,cwd in steps:
 with (r/(name+".log")).open("w") as f:p=subprocess.run(argv,cwd=cwd,env=e,stdout=f,stderr=subprocess.STDOUT)
 (r/(name+".rc")).write_text(str(p.returncode)+"\n");results.append(dict(name=name,argv=argv,cwd=cwd,rc=p.returncode));(r/"checks.json").write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
