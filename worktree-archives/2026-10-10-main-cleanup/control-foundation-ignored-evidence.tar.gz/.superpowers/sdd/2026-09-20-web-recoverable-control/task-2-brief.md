### Task 2: Durable command ledger, revisions, and projection journal

**Files:**
- Create: `src/control/commandLedger.ts`
- Create: `src/control/projectionJournal.ts`
- Create: `tests/control/commandLedger.test.ts`
- Create: `tests/control/projectionJournal.test.ts`
- Modify: `src/control/migrations.ts`
- Modify: `src/control/store.ts`
- Modify: `src/control/commands.ts`
- Modify: `src/control/queries.ts`
- Modify: `tests/control/commands.test.ts`
- Modify: `tests/control/store.test.ts`

**Interfaces:**
- Consumes: Task 1 canonical hashes and command schemas.
- Produces: `applyWebCommand()`, `lookupCommandResult()`, `recordProjectionChange()`, global `changeSeq`, per-group `projectionSeq`, durable scheduler-wake rows, and schema migration/open validation used by Tasks 4–10.

- [ ] **Step 1: Write failing command/revision/projection tests**

```ts
it("replays the persisted effective default and separates authority from projection", () => {
  const first = applyWebCommand(h.store, requestWithOmittedDefault, () => accepted("profile-a"));
  h.defaults.profileId = "profile-b";
  expect(applyWebCommand(h.store, requestWithOmittedDefault, () => accepted("profile-b"))).toEqual(first);
  observeUsage(h.store, "g", amount(1));
  expect(readVersions(h.store, "g")).toEqual({ commandRevision: 1, projectionSeq: 2 });
});
```

Cover same-ID/different actor, verb, target, revision, or raw payload; stale revision precedence; durable 4xx result replay; one projection bump per transaction; changeSeq gap retention; and safe-integer overflow.

- [ ] **Step 2: Run focused tests and verify RED**

Run: `rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts`

Expected: FAIL on missing ledger/journal APIs.

- [ ] **Step 3: Migrate storage without weakening old schema safety**

Add versioned migration support that transforms schema 1 to the Web schema in one transaction and refuses unknown future versions. Persist canonical raw request, expanded effective payload, all three hashes, status/body, actor/verb/target, command revision, projection sequence, and global-command scope. Add projection journal retention metadata, global change sequence, proposal/estimate/snapshot/stop/recovery tables, and durable wake/request/join records required by later tasks.

- [ ] **Step 4: Implement atomic command and projection helpers**

```ts
export function applyWebCommand<T>(store: ControlStore, input: WebCommandInput<T>): StoredCommandOutcome<T>;
export function lookupCommandResult(store: ControlStore, groupId: string, commandId: string): CommandLookupV1 | null;
export function recordProjectionChange(store: ControlStore, groupIds: readonly string[]): number;
```

Lookup existing command identity before reading dynamic defaults. Increment authority and presentation sequences exactly as spec §3.2 states. Keep old `applyCommand` behavior available to completed foundation callers while routing new Web commands through the new ledger.

- [ ] **Step 5: Verify GREEN, old command regressions, and typecheck**

Run: `rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts && rtk npm run typecheck`

Expected: all tests pass and legacy command behavior remains green.

- [ ] **Step 6: Commit Task 2**

```bash
rtk git add src/control/commandLedger.ts src/control/projectionJournal.ts src/control/migrations.ts src/control/store.ts src/control/commands.ts src/control/queries.ts tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts
rtk git commit -m "feat(control): persist web command lifecycle"
```

---

