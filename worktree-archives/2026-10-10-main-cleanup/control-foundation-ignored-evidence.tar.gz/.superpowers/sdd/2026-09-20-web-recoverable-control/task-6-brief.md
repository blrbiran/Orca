### Task 6: Draft defaults, estimator, proposal editing, and confirmation

**Files:**
- Create: `src/control/estimator.ts`
- Create: `src/control/webService.ts`
- Create: `tests/control/estimator.test.ts`
- Create: `tests/control/proposal.test.ts`
- Create: `tests/control/confirmation.test.ts`
- Modify: `src/control/executionSnapshot.ts`
- Modify: `src/panel/controlApi.ts`
- Modify: `src/control/budget.ts`
- Modify: `src/control/schedulerBridge.ts`

**Interfaces:**
- Consumes: Tasks 1–5 command/profile/import/read foundations.
- Produces: proposal edit, re-estimate, confirm, set-limit commands; exact estimator request/contract/output records; immutable derived contracts and execution snapshot used by dispatch.

- [ ] **Step 1: Write failing arithmetic/preflight/provenance tests**

```ts
it("builds the five-task complex-1m ledger exactly", () => {
  expect(complex1mDefaults(5)).toEqual({
    base: { tokens: 17750000, activeMs: 85500000, attempts: 17, sessions: 17 },
    reserve: { tokens: 3550000, activeMs: 17100000, attempts: 4, sessions: 4 },
    limit: { tokens: 21300000, activeMs: 102600000, attempts: 21, sessions: 21 },
  });
});
```

Cover safe-integer aggregate overflow, duplicate edit target, no-op, dirty-field protection, model estimate never mutating authority, exact input formula, input-too-large no-call, capability degradation after request freeze, invalid whole output, estimate response replay, and reserve transfer/refund.

- [ ] **Step 2: Run focused tests and verify RED**

Run: `rtk npm test -- tests/control/estimator.test.ts tests/control/proposal.test.ts tests/control/confirmation.test.ts`

Expected: FAIL on missing estimator/Web service operations.

- [ ] **Step 3: Implement estimator and proposal commands**

```ts
export function complex1mDefaults(taskCount: number): DefaultLedger;
export function buildBudgetEstimateRequest(input: EstimateInput): FrozenEstimateRequest;
export class WebControlService {
  editProposal(command: ProposalEditCommand): CommandSuccessV1;
  createEstimate(command: ReestimateCommand): CommandSuccessV1;
  confirm(command: ConfirmCommand): CommandSuccessV1;
  setLimit(command: SetLimitCommand): CommandSuccessV1;
}
```

Freeze effective estimator capabilities at creation, create deterministic wakes only for eligible calls, and validate complete output atomically. Confirmation writes all grants, per-field provenance, profiles, context policy, derived contracts, and `ExecutionSnapshotV1` in one transaction.

- [ ] **Step 4: Prove derived policy cannot exceed grant**

Add literal contract fixtures for exact mapping of tokens, active time, attempts, session outer bound, per-attempt timeout, recovery window, mechanical/model-assisted handoff eligibility, and `execution-policy-unrepresentable` rollback.

- [ ] **Step 5: Wire mutation routes and verify replay statuses**

Implement import/estimate/proposal/confirm/set-limit routes with the exact 200/201/202 statuses and `CommandSuccessV1`; lookup must return the persisted original status/value.

- [ ] **Step 6: Verify GREEN and commit**

Run: `rtk npm test -- tests/control/estimator.test.ts tests/control/proposal.test.ts tests/control/confirmation.test.ts tests/panel/controlReadApi.test.ts tests/control/budget.test.ts tests/control/schedulerBridge.test.ts && rtk npm run typecheck`

```bash
rtk git add src/control/estimator.ts src/control/webService.ts src/control/executionSnapshot.ts src/control/budget.ts src/control/schedulerBridge.ts src/panel/controlApi.ts tests/control/estimator.test.ts tests/control/proposal.test.ts tests/control/confirmation.test.ts
rtk git commit -m "feat(control): confirm accounted web proposals"
```

---

