# Task 6 independent review

Scope: frozen range `15ffcff..24029f4`, Task 6 only. Read the approved full design, Task 6 plan, implementer report, frozen review package, changed production/test files, and relevant existing command/accounting/read boundaries. Actual provider dispatch/proof delivery and Panel lifecycle construction remain Task 7/later as ruled by the controller.

## Critical

None found.

## Important

### I1. Invalid model numbers prevent terminal failure settlement

- Location: `src/control/webService.ts:274` (also the raw-record publication at line 301).
- `completeEstimate` hashes `rawOutput` with the protocol canonicalizer before reaching whole-output validation and before the same-transaction terminal callback. A syntactically valid model response containing a fractional/unsafe number or lone surrogate throws `control-non-canonical-json` here. The callback, terminal estimate state, usage settlement/refund, and receipt never commit. Replaying the same response repeats the failure, leaving the estimate nonterminal and preventing ordinary start.
- Executed reproduction: claim a fixture estimate, pass `{work:{tokens:0.5}}` plus the valid terminal callback used by existing tests. Result: `control-non-canonical-json`; persisted estimate remains `running`.
- Required change: separate retention/identity of invalid raw provider output from canonical valid `BudgetEstimateV1` storage. Every invalid whole output must be able to settle as `failed` after verified terminal usage, without partially publishing suggestions. Add fractional/unsafe-number and lone-surrogate regressions, including replay/refund behavior. Spec §§5.4, 9.1 require invalid integer/schema output to reject the whole estimate, not strand its lifecycle.

### I2. Known soft deficit cannot complete estimator settlement

- Location: `src/control/webService.ts:296`, with the same problem at line 304.
- Completion calls `residual`, which rejects any negative result, both before and after releasing the terminal estimate remainder. A valid known soft overrun may exceed available reserve and produce the nonnegative `budgetDeficit` already recorded by `syncWebBudget`. Completion then throws `group-budget-unavailable` and rolls back the terminal callback instead of preserving actual used amounts, terminating the commitment, and retaining the deficit/blocker. The group cannot repair this through set-limit because the usage path has already put it in `blocked`.
- Executed reproduction: claim the fixture soft estimate, record known cumulative usage of 6,000,000 tokens, then complete with verified terminal callback. Result: `group-budget-unavailable`; estimate remains `running`.
- Required change: use the settlement conservation formula `reserve=max(limit-used-remainingCommitments,0)` / `deficit=max(used+remainingCommitments-limit,0)` rather than admission-only residual rejection. Preserve the known overrun block while settling the run/estimate and releasing remaining unused dimensions atomically. Add a deficit-producing soft-overrun settlement test. Spec §5.1.1 explicitly permits known settled deficits and terminal estimate commitment zero.

### I3. Late usage can spend commitments already released by estimate completion

- Location: `src/control/webService.ts:303-306`, interacting with `src/control/usage.ts:20`.
- Task 6 completes runs under the new `failed-before-provider` / `settled-*` names and frees their remaining commitment, but `recordUsage` rejects new events only for the old `state === "settled"` literal. A later, previously unseen usage event on a completed estimate therefore still applies. It subtracts from `group.reserved` using the terminal run's retained `remaining` amount even though that estimate no longer owns a commitment. This consumes other task/review commitments and breaks the allocation-sum invariant; a late unknown event can likewise poison the already-terminal estimate's accounting.
- Executed reproduction: complete a zero-usage estimate as failed, then submit new sequence 1 with 1,000 cumulative tokens. `recordUsage` returns `{applied:true,highWater:1}`; group reserved tokens fall from 4,300,000 to 4,299,000 while estimate state stays `failed`.
- Required change: use one terminal/active predicate across the new run lifecycle and usage writer. Preserve byte-identical already-retained event replay, but reject or explicitly quarantine any unseen post-terminal event without changing used/reserved. Cover all new terminal names and late known/unknown events. Spec §5.1.1 requires each allocation to occupy exactly one commitment state; Task 6's new state writer must integrate with the existing usage guard.

### I4. Missing observed handoff execution support still permits estimator claim

- Location: `src/control/estimator.ts:71-73` and `src/control/estimator.ts:102-107`.
- The extracted creation preflight removed the previous `observed.handoffExecution === null` guard, and the new claim-time degradation check also omits it. A successful probe can report durable handoff control but no support for the declared handoff execution mode; `intersectCapabilities` deliberately represents that as `null`. The estimate is nevertheless eligible and its session/run claim commits despite lacking the accepted handoff path. Actual provider delivery being deferred to Task 7 does not remove Task 6's claim-time no-run-on-capability-loss requirement.
- Executed reproduction: import normally, then set the probe's `handoffExecution` to `null` before `claimEstimate`. Result: a new run is claimed and estimate becomes `running`.
- Required change: reject unavailable/mismatched effective handoff execution at both creation and claim, preserving the appropriate terminal blocked estimate, no wake/run/session at creation, and commitment refund at pre-claim degradation. Add tests for explicit null and a probe mode different from the frozen declaration. Spec §3.1 defines exact handoff-mode intersection and §4.4 requires no run/session on capability degradation.

## Minor

### M1. Model-assisted handoff grant failure uses the wrong typed code

- Location: `src/control/webService.ts:335` and `tests/control/confirmation.test.ts` model-assisted handoff case.
- The implemented eligibility rejection uses `execution-policy-unrepresentable`; spec §3.1 explicitly requires `handoff-grant-insufficient`, already present in the error catalog. The existing test locks in the wrong code. Return the dedicated durable 422 code and adjust the regression so clients can identify the exact editable grant problem.

## Verification performed

- Verified the checkout HEAD was `24029f4` and production source had no uncommitted edits before executing reproductions; only the preserved handoff modification and untracked node_modules existed.
- Used the frozen commit's existing fixture, transpiled in memory with its Vitest spy replaced by a no-op wrapper, and isolated temporary ControlStores. No production/test source was edited, no provider was invoked, and fixture directories were disposed by the existing fixture cleanup.
- Initial sandbox invocation failed on the existing ControlStore `ps` probe (`EPERM`), then the exact diagnostic was rerun with approved escalation and exited 0.
- Reproduction output:

```text
fractional-output {"error":"control-non-canonical-json","state":"running"}
known-deficit {"error":"group-budget-unavailable","state":"running"}
late-usage completion succeeded
late-usage {"result":{"applied":true,"highWater":1},"beforeReserved":4300000,"afterReserved":4299000,"estimateState":"failed"}
handoff-unavailable {"claimed":true,"estimate":"running"}
```

Existing focused/full-suite success is recorded in the implementer report; those tests do not cover the four reproductions above. No full-suite rerun was necessary for this read-only review.

## Verdict

**Needs changes.** Four Important issues must be fixed and independently re-reviewed before Task 6 is marked complete or this completed scope is merged. M1 is small and should be corrected in the same pass. No finding requires starting Task 7 or broadening the handoff scope.
