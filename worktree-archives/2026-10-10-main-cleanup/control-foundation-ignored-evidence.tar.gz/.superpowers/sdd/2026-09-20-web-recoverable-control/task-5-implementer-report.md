# Task 5 Implementer Report: Canonical Read Models and Invalidation API

## Outcome

Implemented the authenticated V1 control read surface over validated ControlStore authority: config, full/incremental summaries, complete group lists, full group snapshots, retained command lookup, recovery state, and verified evidence manifests. The implementation uses the existing Panel token middleware, strict canonical `sinceChangeSeq` parsing, closed server/browser DTOs, deterministic sorting, and the exact typed error envelope. Forged immediate-kill paths remain absent and return typed `404 route-not-found`.

## Files

- `src/panel/controlViews.ts` — canonical summary, group, recovery, and evidence projections with cross-record/hash validation.
- `src/panel/controlApi.ts` — V1 read routes, strict query parsing, command-result lookup, and typed control fallback/error handling.
- `src/panel/controlErrors.ts` — closed, disjoint HTTP classification and exact V1 error-envelope helpers.
- `src/panel/api.ts` — optional control read dependencies registered behind the existing `/api` token middleware without changing legacy API error bodies.
- `web/src/controlTypes.ts` — browser-local closed DTO mirrors; authority remains server-side.
- `tests/panel/controlReadApi.test.ts` — real-HTTP read, invalidation, authority, sorting, evidence, auth, and error coverage.
- `tests/panel/security.test.ts` — exact typed token-error envelope assertion.
- `tests/panel/webParity.test.ts` — bidirectional compile-time server/Web assignability checks.

## RED evidence

Initial command:

`rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/security.test.ts tests/panel/webParity.test.ts`

Result before implementation: 2 test files failed and 1 passed; 4 tests failed. The new read routes returned `404`, browser DTOs were absent, and the security suite could not load the absent control-error module.

After the first GREEN implementation, a second focused RED cycle added a confirmed-snapshot integrity case:

`rtk npm test -- tests/panel/controlReadApi.test.ts`

Result before the fix: 1 test failed because a persisted work-item derived-contract hash inconsistent with the confirmed execution snapshot returned `200` instead of failing closed with `423 recovery-blocked`.

## GREEN evidence

- `rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/security.test.ts tests/panel/webParity.test.ts`: 3 files passed, 18 tests passed.
- Second-cycle `rtk npm test -- tests/panel/controlReadApi.test.ts`: 1 file passed, 4 tests passed.
- `rtk npm run typecheck`: passed (`tsc --noEmit -p tsconfig.json`).
- `rtk npm --workspace web run check`: 9 files passed, 34 tests passed.

Coverage includes missing/malformed/negative/fractional/exponent/leading-zero/overflow/duplicate/misspelled `sinceChangeSeq`; absent, complete, incremental, ahead, and retention-gap summary behavior; complete-summary sorting/deletion semantics; confirmed profiles and snapshot hashes; estimate output display; paused/stop state; command status/body replay; recovery sorting; artifact hash verification; no filesystem/executable path exposure; auth; typed misses; and forged immediate-kill `404`.

## Full-suite verification

Command:

`rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

Final result after the last production change: 159 test files passed, 1 skipped; 1,337 tests passed, 3 skipped; exit 0 in 86.77 seconds.

Additional verification:

- `rtk git diff --check` passed.
- The pre-existing `docs/handoff/handoff.md` modification and untracked `node_modules` were preserved and excluded from Task 5 staging.

## Self-review

- Every group view begins with verified archived plan/proposal/estimate authority. Confirmed views additionally re-read canonical execution-snapshot bytes, verify canonical encoding/hash and proposal identity, require the exact task set, and cross-check each persisted derived-contract hash.
- Summary handling preserves the process epoch, delegates retained-gap/ahead logic to the projection journal, returns complete replacement snapshots when required, and emits only changed groups for ordinary incremental reads.
- Declared object collections and scalar ID sets are deterministically sorted and de-duplicated. Full views expose stable IDs, hashes, display text, and manifest URLs but no repository, executable, adapter, archive, or evidence filesystem paths.
- Command lookup returns the persisted original status and parsed value unchanged inside the closed lookup wrapper. Missing resources, malformed queries, recovery-blocked authority, token failure, unknown routes, transient reads, and unexpected failures use the V1 envelope and fixed status/retryability rules.
- Evidence manifests collect canonical references, verify every archived artifact through the content-addressed reader before returning byte length/hash metadata, and never return retained bytes or server paths.
- Server/Web parity is structural and bidirectional at compile time; browser declarations contain shapes only and perform no authoritative derivation.

## Concerns / handoff notes

No Task 5 blocker remains. Panel lifecycle construction does not inject the optional control dependencies yet; that integration remains in the planned later Panel lifecycle task. The V1 endpoint list defines the evidence manifest route only, so this task returns its closed manifest and does not add an undeclared raw-evidence route.

## Fix round 1

### Outcome

Applied the controller ruling to fail closed on missing, malformed, non-canonical, or cross-record-inconsistent read authority. Confirmed views now verify exact snapshot allocations and every referenced derived-contract record, including ownership, canonical bytes/hash, task identity, proposal version, grants, and deterministic derivation from the archived source contract. Run views now require a closed persisted run record and validate row/group/work-or-estimate identity, active graph version, current/lineage membership, frozen profile bindings, phase/state/ordinal vocabulary, grant/accounting relationships, and handoff-request phase identity without display fallbacks. Stopped groups require a canonical stop intent; contradictory stop rows block. Evidence collection rejects malformed, dangling, or wrong-group references and includes handoff-request and run-scoped recovery-blocker artifacts. Control-route Host rejection and mapped read failures preserve the exact V1 error envelope, applicable command revision, and blocker evidence IDs.

### RED evidence

- `rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/metricsApi.test.ts`: 2 files failed; 6 tests failed and 18 passed. The failures pinned confirmed/derived authority, persisted run authority, stop intent authority, legacy stopped flags, handoff/recovery evidence inclusion, and the control Host envelope.
- `rtk npm test -- tests/panel/controlReadApi.test.ts`: 1 test failed and 7 passed after adding a correctly canonical-hashed but semantically forged derived contract; the view incorrectly returned `200` instead of `423`.
- Final self-review RED, `rtk npm test -- tests/panel/controlReadApi.test.ts`: 2 tests failed and 6 passed. An active run with a stale graph version and a target-run outbox with a malformed artifact collection both incorrectly returned `200` instead of `423`.

### GREEN and final verification

- First focused GREEN: `rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/metricsApi.test.ts` — 2 files passed, 24 tests passed.
- Forged-contract GREEN: `rtk npm test -- tests/panel/controlReadApi.test.ts` — 1 file passed, 8 tests passed.
- Final self-review GREEN: `rtk npm test -- tests/panel/controlReadApi.test.ts` — 1 file passed, 8 tests passed.
- Final focused Panel/security/parity run: `rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/metricsApi.test.ts tests/panel/security.test.ts tests/panel/webParity.test.ts` — 4 files passed, 38 tests passed.
- `rtk npm run typecheck` — passed (`tsc --noEmit -p tsconfig.json`).
- `rtk npm --workspace web run check` — 9 files passed, 34 tests passed. An earlier sandboxed attempt could not create Vite's temporary config file (`EPERM`); the permitted rerun passed unchanged.
- Final full root suite: `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test` — 159 files passed, 1 skipped; 1,342 tests passed, 3 skipped; exit 0 in 92.16 seconds.
- `rtk git diff --check` — passed.

### Files changed

- `src/panel/controlViews.ts`
- `src/panel/controlApi.ts`
- `src/panel/controlErrors.ts`
- `src/panel/server.ts`
- `tests/panel/controlReadApi.test.ts`
- `tests/panel/metricsApi.test.ts`

The pre-existing `docs/handoff/handoff.md` modification and untracked `node_modules` remain untouched and are excluded from staging.

### Self-review and concern

The read layer now validates before projection, sorts every declared set, returns only closed DTOs, and never exposes evidence or executable filesystem paths. Error context is best-effort only for enriching the primary typed failure and cannot weaken or mask that failure. Immediate-kill routes remain absent.

Existing budget/continuation run writers do not yet persist the Task 5 closed authority fields (`phase`, `claimOrdinal`, `providerAttemptOrdinal`, `failureCode`, `estimateId`, and explicit nullable profile slots), nor do they maintain the specified work-item current/lineage fields. Under the controller ruling these legacy run rows correctly return `423 recovery-blocked`; Task 5 does not synthesize values or change mutation behavior. Recommendation for Task 6: persist the closed run/work authority atomically at claim and phase transitions, and migrate only fields derivable from durable cross-record evidence; ambiguous historical rows must remain recovery-blocked.

## Fix round 2

### Outcome

Evidence collection elements are now always treated as required references: null or malformed checkpoint/outbox artifact-array elements return `423 recovery-blocked`, matching the already-strict handoff and recovery-blocker evidence-ID schemas. Optional scalar references retain their schema-permitted absent/null behavior. The valid manifest fixture now repeats artifacts across usage, checkpoint, outbox, handoff, and recovery sources and proves one lexicographically sorted, deduplicated result.

Derived-contract validation now distinguishes group-owned execution snapshots from globally content-addressed derived records. The execution snapshot must still belong to the current group. A derived record may have been first persisted by another group, but it is accepted only through the current group's verified snapshot reference and only after its canonical hash/bytes, original task identity, proposal version, confirmed grants, and deterministic contract derivation all match. Existing missing, tampered, forged, wrong-task, allocation-mismatch, and work-item-not-referenced checks remain fail-closed.

### RED evidence

`rtk npm test -- tests/panel/controlReadApi.test.ts` produced 3 expected failures and 14 passes:

- the second group sharing an identical globally deduplicated derived record returned `423` instead of `200`;
- a null checkpoint artifact-array element returned `200` instead of `423`;
- a null outbox artifact-array element returned `200` instead of `423`.

The invalid handoff/recovery and non-null malformed checkpoint/outbox table rows already returned `423`, confirming those existing validation paths.

### GREEN and final verification

- Focused GREEN: `rtk npm test -- tests/panel/controlReadApi.test.ts` — 1 file passed, 17 tests passed.
- Final Panel/security/parity: `rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/metricsApi.test.ts tests/panel/security.test.ts tests/panel/webParity.test.ts` — 4 files passed, 47 tests passed.
- `rtk npm run typecheck` — passed (`tsc --noEmit -p tsconfig.json`).
- `rtk npm --workspace web run check` — 9 files passed, 34 tests passed.
- Final root suite: `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test` — 159 files passed, 1 skipped; 1,351 tests passed, 3 skipped; exit 0 in 93.01 seconds.
- `rtk git diff --check` — passed.

### Files and self-review

- `src/panel/controlViews.ts`
- `tests/panel/controlReadApi.test.ts`

The change does not relax snapshot ownership or any semantic/hash verification. It removes only the invalid assumption that a globally deduplicated derived row's first-writer provenance is exclusive authority. Every collection element now reaches strict artifact validation, while absent/null optional scalar fields retain their prior behavior. No Task 6 behavior was added. The pre-existing `docs/handoff/handoff.md` modification and untracked `node_modules` remain untouched and excluded from staging. No new concern was found beyond the legacy run-writer handoff already recorded in fix round 1.
