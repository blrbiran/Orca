# Task 3 Implementer Report

## Status

Implemented trusted allowlists, execution-profile hashing/routing and fail-closed capability probing/intersection, plus the shared admission/drain barrier and ControlService wiring. No live model was called; no merge, push, publish, cleanup, or worktree deletion was performed.

## RED evidence

1. Initial required focused run:

   `rtk npm test -- tests/control/profiles.test.ts tests/control/admissionGate.test.ts tests/panel/controlConfig.test.ts`

   Result: exit 1. All three suites failed to load because `src/control/profiles.ts` and `src/control/admissionGate.ts` did not exist (`3 failed`, `0 tests`), the intended missing-feature RED.

2. Self-review hardening RED:

   `rtk npm test -- tests/control/profiles.test.ts tests/panel/controlConfig.test.ts`

   Result: exit 1. `2 failed | 8 passed`: a forged profile hash was accepted by router construction and an unknown trusted-config field was accepted. Both failures were the intended trust-boundary mutations.

## GREEN and regression evidence

- Required focused/regression run:

  `rtk npm test -- tests/control/profiles.test.ts tests/control/admissionGate.test.ts tests/panel/controlConfig.test.ts tests/control/ccloopPort.test.ts tests/control/dispatch.test.ts`

  Result: exit 0, `5 passed`, `24 passed` tests.

- Typecheck:

  `rtk npm run typecheck`

  Result: exit 0 (`tsc --noEmit -p tsconfig.json`).

- Mandated full root suite, run once:

  `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

  Result: exit 0, `155 passed | 1 skipped` test files; `1270 passed | 3 skipped` tests. The skipped file was the existing conditional `tests/control/ccloopProtocol.integration.test.ts` suite.

## Files

- Added `src/control/profiles.ts`
- Added `src/control/admissionGate.ts`
- Added `src/panel/controlConfig.ts`
- Modified `src/control/executionPort.ts`
- Modified `src/control/service.ts`
- Modified `src/control/errors.ts` to classify every new code in the closed disjoint catalog
- Added `tests/control/profiles.test.ts`
- Added `tests/control/admissionGate.test.ts`
- Added `tests/panel/controlConfig.test.ts`

## Self-review

- Confirmed `profileHash` covers the parsed closed snapshot, including all resolved hashes, exact optional nulls, and schema-normalized set ordering.
- Confirmed router construction rejects duplicate IDs, forged hashes, invalid snapshots, wrong work kinds, stale hashes, and cross-router probe objects.
- Confirmed capability probing is strict-schema parsed, component-wise intersected, preserves proof only on exact descriptor equality, and becomes wholly unavailable on missing/malformed/failed probes.
- Confirmed Codex remains schema-locked to `phase-end` usage plus `soft` budget enforcement.
- Confirmed config output contains stable IDs and safe display fields only; executable, adapter, repository, plan, and evidence paths remain server-side.
- Confirmed startup path checks reject noncanonical paths, symlink components, plan escapes, duplicate IDs, unknown config fields, and unknown browser target IDs.
- Confirmed `beginDrain()` synchronously closes admission, waits for every already-admitted permit, is idempotent, and rejects later operations as `panel-draining`.
- Confirmed service claim/mutation paths hold the shared permit across capability reads and durable mutation completion, and the same gate is exposed for shutdown orchestration.
- Confirmed the pre-existing `docs/handoff/handoff.md` edit and `node_modules` were neither modified nor staged.

## Concerns

- A port that does not implement `probeProfileCapabilities` intentionally resolves to unavailable. This is the fail-closed contract; trusted adapter startup wiring must provide the full probe before Web-controlled claims can become eligible.
- The three ccloop protocol integration tests remained conditionally skipped by their existing environment gate; no skip was added or changed by Task 3.

## Fix round 1

### Status

Closed all four review findings. Profile-selected work now flows through the real scheduler claim/start/collect seams, persists its exact profile binding on the run, freshly probes before claim and start, and never falls back to the legacy port. The shared admission gate now guards the claim, reconcile/start, evidence, handoff, archive, checkpoint, projection, landing-record, and cleanup writer boundaries without being held across adapter calls or evidence reads. Router construction owns an independently validated, deeply frozen snapshot and captured port method table. Trusted repository/plan resolution revalidates every original path component and inode before each use.

### RED evidence

- Review reproduction:

  `rtk npm test -- tests/control/profiledService.test.ts tests/control/profiles.test.ts tests/panel/controlConfig.test.ts`

  Result: exit 1, `8 failed | 10 passed`. The missing profiled service methods caused six failures; caller port mutation changed router behavior; and a post-start ancestor symlink swap remained accepted.

### GREEN and regression evidence

- Final focused profile/admission/path and foundation regression run:

  `rtk npm test -- tests/control/profiledService.test.ts tests/control/profiles.test.ts tests/control/admissionGate.test.ts tests/panel/controlConfig.test.ts tests/control/dispatch.test.ts tests/control/ccloopPort.test.ts`

  Result: exit 0, `6 passed` files and `35 passed` tests. This final focused rerun includes the added hanging-handoff race regression and was followed in the same command by a clean typecheck.

- Control regression run:

  `rtk npm test -- tests/control tests/panel/controlConfig.test.ts`

  Result: the implementation regressions passed (`199 passed | 3 skipped`); four scheduler cases failed only because this diagnostic invocation omitted `ORCA_CCLOOP_BIN`. The required-environment rerun `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test -- tests/control/schedulerBridge.test.ts` passed `9/9`.

- Typecheck:

  `rtk npm run typecheck`

  Result: exit 0 (`tsc --noEmit -p tsconfig.json`).

- Mandated full root suite:

  `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

  Result: exit 0, `156 passed | 1 skipped` test files; `1280 passed | 3 skipped` tests.

### Files

- Profile identity/routing and persisted binding: `src/control/profiles.ts`, `src/control/types.ts`, `src/control/budget.ts`, `src/control/continuation.ts`, `src/control/service.ts`, `src/control/schedulerBridge.ts`
- Admission at asynchronous writer seams: `src/control/dispatch.ts`, `src/control/archive.ts`, `src/control/checkpoints.ts`, `src/control/projection.ts`, `src/control/cleanup.ts`
- Closed error classification and path witness revalidation: `src/control/errors.ts`, `src/panel/controlConfig.ts`
- Review regressions: `tests/control/profiledService.test.ts`, `tests/control/profiles.test.ts`, `tests/panel/controlConfig.test.ts`

### Self-review

- Verified stale hash, removed ID, and degraded fresh probes reject both claim and start before provider invocation; rejected claims create no run and rejected starts create no start intent or state transition.
- Verified the scheduler closure uses `claimProfiled`/`reconcileBudgetProfiled`/`startProfiled`, while legacy callers remain behind explicit legacy methods. Evidence collection, handoff, and continuation derive the port from the persisted run binding.
- Verified no admission permit spans profile probes, adapter accept/inspect/handoff/collect calls, or port evidence reads. Each later durable publication or ControlStore transaction must reacquire the shared gate, so a completed drain makes it fail with `panel-draining` before canonical mutation.
- Verified deterministic races cover hanging claim and reconcile probes, hanging start acceptance, hanging evidence reads after handoff/start, and exceptional claim/reconcile exits. The barrier completes while those external calls remain suspended.
- Verified router construction reparses and clones the snapshot, freezes the owned clone, and captures a frozen port facade; later caller mutations do not alter routing, hash verification, probe, or dispatch behavior.
- Verified repository and plan witnesses record every path component identity and revalidate no-follow lstat, canonical target, containment, and inode identity at resolve time, rejecting a file/ancestor replacement or symlink swap.
- Verified `control-path-changed` is in the closed, disjoint non-durable classification contract and the full classification suite passes.
- Verified `docs/handoff/handoff.md` and `node_modules` remain unstaged and untouched by this fix.

### Concerns

- The existing conditional `tests/control/ccloopProtocol.integration.test.ts` suite remains skipped (`3` tests); no skip was added or changed.
- No known Task 3 implementation concern remains.

## Fix round 2

### Status

Closed the remaining profile-routing and admission/I/O findings. Profiled runs now persist independent worker and handoff bindings; recovery, continuation, and handoff freshly resolve and probe the relevant persisted binding; strict admission requires token-bound proof; and the selected handoff port is used for both request and collection. Resume-bundle and duplicate-artifact I/O now stage/read outside admission and reacquire the gate only for canonical publication and durable registration. The router's immutable port facade retains each method's original receiver.

### RED evidence

- Review reproduction:

  `rtk npm test -- tests/control/profiledService.test.ts tests/control/profiles.test.ts tests/control/resumeBundle.test.ts tests/control/archive.test.ts`

  Result: exit 1, `4 failed` files with `7 failed | 25 passed` tests. The failures showed lost port receivers, recovery accepting after profile degradation, strict proof without `tokens`, task-profile reuse for handoff, worker-port handoff dispatch, and admission held across resume/archive I/O.

### GREEN and regression evidence

- Final focused profile/routing/publication/scheduler run:

  `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test -- tests/control/profiledService.test.ts tests/control/profiles.test.ts tests/control/resumeBundle.test.ts tests/control/archive.test.ts tests/control/schedulerBridge.test.ts`

  Result: exit 0, `5 passed` files and `41 passed` tests.

- Control regression diagnostic:

  `rtk npm test -- tests/control tests/schedulerBridge.test.ts`

  Result: all implementation tests passed (`204 passed | 3 skipped`); four scheduler cases failed only because this diagnostic invocation omitted `ORCA_CCLOOP_BIN`. The required-environment rerun `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test -- tests/control/schedulerBridge.test.ts` passed `9/9`.

- Typecheck and diff validation:

  `rtk npm run typecheck` and `rtk git diff --check`

  Result: exit 0 (`tsc --noEmit -p tsconfig.json`) and no whitespace errors.

- Mandated full root suite:

  `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

  Result: exit 0, `156 passed | 1 skipped` test files; `1287 passed | 3 skipped` tests.

### Files

- Persisted worker/handoff identity and routing: `src/control/types.ts`, `src/control/budget.ts`, `src/control/continuation.ts`, `src/control/service.ts`, `src/control/schedulerBridge.ts`
- Immutable receiver-safe port facade: `src/control/profiles.ts`
- Two-phase admitted publication: `src/control/resumeBundle.ts`, `src/control/archive.ts`
- Review regressions: `tests/control/profiledService.test.ts`, `tests/control/profiles.test.ts`, `tests/control/resumeBundle.test.ts`, `tests/control/archive.test.ts`

### Self-review

- Verified claim and reconcile require a task profile plus a distinct handoff-role selection, freshly probe both before mutation, persist both hashes, and reject stale, missing, degraded, or role-wrong profiles without provider invocation or a run write.
- Verified recovery probes the persisted task binding before inspect/re-accept; a stale hash, missing ID, unavailable probe, or wrong role cannot create a second provider call or mutate the durable start state.
- Verified strict mode accepts only an exact matching bounded proof whose work dimensions include `tokens`; empty and wrong-dimension descriptors fail closed.
- Verified handoff requires and probes the persisted handoff binding and passes its port through request and evidence collection; a malformed profiled run cannot fall back to the legacy port.
- Verified resume artifacts are fully read and staged before admission, while canonical directories and the final rename occur only inside a newly admitted writer. If drain wins, the staging tree is removed and no source directory is published.
- Verified duplicate artifact hashing uses an `O_NOFOLLOW` handle outside admission, records file identity before and after hashing, and rechecks that identity inside the admitted registration boundary. An `EEXIST` publication race returns to outside-admission observation rather than hashing while holding a permit.
- Verified admission permits are not held across profile probes, adapter calls, evidence reads, archive hashing, or resume staging; every later durable writer reacquires the shared gate and is rejected before mutation after drain.
- Verified the router captures bound methods into a frozen facade, so caller method replacement cannot alter dispatch while receiver-dependent/private-state methods remain functional.
- Verified `docs/handoff/handoff.md` and `node_modules` remain unstaged and untouched by this fix.

### Concerns

- The existing conditional `tests/control/ccloopProtocol.integration.test.ts` suite remains skipped (`3` tests); no skip was added or changed.
- No known Task 3 fix-round concern remains.

## Fix round 3

### Status

Closed the remaining duplicate-artifact registration escape. Duplicate observation now validates and records the no-follow identity of the artifact ID directory and its canonical direct containment under the artifact root before hashing. The admitted registration boundary synchronously revalidates that directory witness and the data-file witness before committing any artifact row, while content hashing remains outside admission.

### RED evidence

- Archive regression reproduction:

  `rtk npm test -- tests/control/archive.test.ts`

  Result: exit 1, `1 failed` file with `2 failed | 6 passed` tests. Both the pre-existing symlinked ID directory and the post-hash directory swap were rejected only after `{ id: ... }` had already been durably registered.

### GREEN and regression evidence

- Immediate archive GREEN:

  `rtk npm test -- tests/control/archive.test.ts`

  Result: exit 0, `1 passed` file and `8 passed` tests.

- Focused Task 3 regression and typecheck:

  `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test -- tests/control/profiledService.test.ts tests/control/profiles.test.ts tests/control/resumeBundle.test.ts tests/control/archive.test.ts tests/control/schedulerBridge.test.ts`

  Result: exit 0, `5 passed` files and `43 passed` tests. `rtk npm run typecheck` also exited 0 (`tsc --noEmit -p tsconfig.json`).

- Mandated full root suite:

  `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

  Result: exit 0, `156 passed | 1 skipped` test files; `1289 passed | 3 skipped` tests.

### Files

- Parent-directory witness and admitted revalidation: `src/control/archive.ts`
- Symlink and swap regressions: `tests/control/archive.test.ts`

### Self-review

- Verified a pre-existing symlink at `artifacts/<artifactId>` is rejected before hashing or registration, with no artifact row left behind.
- Verified a valid duplicate directory replaced by a symlink to the same underlying file after hashing fails the admitted parent-directory check even though the file inode still matches, with no artifact row left behind.
- Verified the directory check uses no-follow metadata, requires a real directory, resolves canonically to the exact direct child of the canonical artifact root, and compares the full recorded identity before registration.
- Verified the final directory and file rechecks plus SQLite registration execute synchronously inside the admitted callback; no asynchronous read or hash is held under the permit.
- Verified the existing hanging duplicate-hash/drain regression remains green, so drain still does not wait on content reads and no post-drain row is committed.
- Verified `docs/handoff/handoff.md` and `node_modules` remain unstaged and untouched by this fix.

### Concerns

- The existing conditional `tests/control/ccloopProtocol.integration.test.ts` suite remains skipped (`3` tests); no skip was added or changed.
- No known Task 3 fix-round concern remains.
