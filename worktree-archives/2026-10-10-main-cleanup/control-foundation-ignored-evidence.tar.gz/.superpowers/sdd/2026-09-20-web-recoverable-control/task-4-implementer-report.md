# Task 4 Implementer Report: Immutable Plan Import and Archival

## Outcome

Implemented immutable, content-addressed Web plan import and deterministic execution-snapshot preparation. Import resolves only trusted repository/plan IDs through Task 3's use-time path revalidation, validates the existing scheduler plan plus the closed ccloop V1 contract shape, normalizes canonical sets, and atomically publishes the complete draft or nothing. No mutable plan or contract path is retained as execution authority.

## Files

- `src/control/planImport.ts` — command-ledger import, deterministic defaults and estimate preflight, atomic group/proposal/task/estimate/wake publication.
- `src/control/executionSnapshot.ts` — deterministic execution snapshot and closed derived-contract wrapper builder for Task 6.
- `src/scheduler/planFile.ts` — optional Web metadata on the backward-compatible scheduler plan, no-follow UTF-8 source reads, closed ccloop V1 contract validation, canonical source adapter.
- `src/control/queries.ts` — verified archived plan/contract and proposal/estimate reads.
- `src/control/snapshot.ts` — transactional content-addressed canonical record writes and fail-closed reads.
- `tests/control/planImport.test.ts` — import normalization, archival, replay, rejection, terminal preflight, rollback, real SIGKILL, and recovery coverage.
- `tests/control/executionSnapshot.test.ts` — deterministic snapshot and wrapper-hashed derived-contract coverage.

## RED evidence

Command:

`rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts tests/control/snapshot.test.ts tests/scheduler/planFile.test.ts`

Result before implementation: failed as expected because the new plan-import and execution-snapshot modules/APIs did not exist. The two new suites were RED; the two existing suites remained GREEN with 14 existing tests passing.

## GREEN evidence

Command:

`rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts tests/control/snapshot.test.ts tests/scheduler/planFile.test.ts && rtk npm run typecheck`

Final result: 4 test files passed, 29 tests passed; TypeScript `tsc --noEmit -p tsconfig.json` passed.

Coverage includes:

- canonical task/dependency ordering, duplicate and dangling-dependency rejection;
- closed ccloop V1 contract validation and original contract byte/hash archival;
- exact component-wise default/reserve accounting;
- queued, capability-blocked, and input-too-large estimator preflight states;
- same-command replay after source and trusted-default changes;
- missing or damaged content-addressed authority failing as `recovery-blocked`;
- transaction fault injection and real SIGKILL immediately before and after commit;
- command revision/projection sequence 1 on successful import;
- deterministic execution snapshots and derived contract hashes over the required closed wrapper record.

## Full-suite verification

Command:

`rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

Result: 158 test files passed, 1 skipped; 1,304 tests passed, 3 skipped; exit 0 in 86.64 seconds.

Additional verification:

- `rtk git diff --check` passed.
- The pre-existing `docs/handoff/handoff.md` modification and untracked `node_modules` were preserved and excluded from Task 4 staging.

## Self-review

- Import replay lookup occurs before dynamic defaults, trusted source resolution, source reads, or capability observation, so response-loss replay remains bound to the original durable result even if those inputs change.
- All import rows, command result, revision 1, projection 1, and eligible scheduler wake share the command transaction. Real process-kill tests demonstrate complete absence before commit and durable replay after commit.
- Plan and contract authority is canonical JSON stored by hash in SQLite. Every read re-canonicalizes and re-hashes; missing, malformed, noncanonical, or mismatched records fail closed.
- Arithmetic that can overflow uses `BigInt` intermediates and rejects results outside the JavaScript safe-integer range. Reserve rounding is exact `ceil(base*20/100)` per dimension.
- Derived contract generation rereads only archived canonical bytes, validates their original hash and closed schema, replaces exactly the mapped budget-policy fields, and hashes the required wrapper containing proposal version and both confirmed grants.
- No new error code was introduced; all failures use the existing closed disjoint catalog.

## Concerns / handoff notes

No blocking schema conflict exists. The scheduler plan remains backward compatible because Web-only metadata is optional for legacy callers and required only by the Web source adapter. Task 5/6 callers must supply `estimatorObservation` from a fresh, declaration-intersected Task 3 probe and persist the prepared derived-contract wrapper bytes atomically during confirmation; this task intentionally does not implement those later mutations.

## Fix round 1

### Outcome

Closed the four reviewed authority gaps without extending into Task 5 or Task 6:

- added a production-facing async import entry whose raw command replay/conflict lookup precedes capability I/O, while the transactional import path performs the required post-probe replay/CAS recheck;
- made execution-snapshot preparation reread verified archived plan/proposal authority, require exact task membership and matching identities, and conserve every task, handoff, goal/review, estimate, and reserve component with `BigInt` arithmetic;
- bound trusted source resolution to descriptor reads with `O_NOFOLLOW`, descriptor `fstat`, device/inode witness matching, and ancestor/direct-containment revalidation before and after reading bytes;
- closed archived plan, contract, proposal, and estimate readers over strict schemas, canonical JSON, hashes, and cross-record identities, with all corruption classified as `recovery-blocked`.

### RED evidence

Command:

`rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts`

Result before the fixes: 15 tests failed and 13 passed. The failures demonstrated the missing async entry, capability I/O on replay, acceptance of a swapped source inode, acceptance of malformed/noncanonical authority, unconstrained snapshot task membership, and missing allocation conservation/identity checks.

### GREEN evidence

Command:

`rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts tests/control/snapshot.test.ts tests/scheduler/planFile.test.ts tests/panel/controlConfig.test.ts tests/control/commandLedger.test.ts && rtk npm run typecheck && rtk git diff --check`

Result: 6 test files passed, 81 tests passed; TypeScript `tsc --noEmit -p tsconfig.json` passed; diff check passed.

Coverage added for zero-probe durable replay and conflict, lost-response retry, a concurrent same-command commit while the probe is in flight, terminal real-probe failure, trusted-path inode swap rejection with no import rows, strict/canonical authority corruption, exact task-set membership, allocation over-limit, safe-integer overflow, and group/plan/proposal identity mismatch.

### Full-suite verification

Command:

`rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

Result: 158 test files passed, 1 skipped; 1,317 tests passed, 3 skipped; exit 0 in 84.28 seconds.

### Files changed

- `src/control/commandLedger.ts`
- `src/control/executionSnapshot.ts`
- `src/control/planImport.ts`
- `src/control/queries.ts`
- `src/panel/controlConfig.ts`
- `src/scheduler/planFile.ts`
- `tests/control/executionSnapshot.test.ts`
- `tests/control/planImport.test.ts`

### Self-review

- Durable replay and same-ID conflict resolution perform no profile/router probe; a cache miss probes exactly once, then re-enters the transactional command path that rechecks command identity before any effects.
- Source bytes become authority only after the opened descriptor matches the trusted startup witness and the allowlisted containment chain is still intact. The mutable path is never persisted as execution authority.
- Snapshot construction derives task identities and contract bytes from verified archived authority and independently rereads the persisted confirmed proposal. All allocation components participate in component-wise conservation with exact `BigInt` sums before safe-integer conversion.
- Every authority reader rejects extra/missing fields, noncanonical order or bytes, bad hashes, and mismatched record identities as the existing closed `recovery-blocked` error; no new error code was added.
- The separately ledgered Minor concern about the public `normalizeControlPlan` boundary was intentionally left unchanged per the fix-round ruling.
- `docs/handoff/handoff.md` and `node_modules` were preserved and excluded from staging. No blockers or remaining Task 4 concerns were found.

## Fix round 2

### Outcome

Closed the remaining two scoped authority gaps:

- execution-snapshot preparation now strictly reads every persisted estimate record, derives the authoritative nonterminal commitment set (`queued`, `running`, and `start-unknown`), and requires caller estimate rows to match that set and every grant amount exactly before component-wise `BigInt` conservation; terminal estimates remain historical evidence and contribute no commitment, per the conservation ledger;
- async import still checks durable replay before defaults/profile/probe I/O, but a catalogued preparation or rejected probe failure is now handed back to `applyWebCommand`, which rechecks raw identity/CAS and persists the typed 4xx outcome. Unexpected and transient failures still escape with the transaction rolled back and no command row.

### RED evidence

Command:

`rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts`

Result before implementation: 7 tests failed and 31 passed. The estimate tests showed that omitted, substituted, understated, and wrong-ID persisted commitments were accepted. The async tests showed missing/changed profiles and an in-flight durable probe rejection escaping instead of entering the command ledger.

### GREEN evidence

Command:

`rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts tests/control/snapshot.test.ts tests/scheduler/planFile.test.ts tests/panel/controlConfig.test.ts tests/control/commandLedger.test.ts && rtk npm run typecheck && rtk git diff --check`

Result: 6 test files passed, 91 tests passed; TypeScript `tsc --noEmit -p tsconfig.json` passed; diff check passed.

Coverage includes omitted, substituted, understated, duplicate, wrong-ID, over-limit, and safe-integer-overflow estimate commitments; missing and hash-changed profile failures persisted as durable 409 results; replay after defaults/config restoration performed no resolve/probe I/O; concurrent same-ID commit won while a failing probe was in flight; and unexpected/transient probe failures created no command or group row.

### Full-suite verification

Command:

`rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

Final result after the last production change: 158 test files passed, 1 skipped; 1,327 tests passed, 3 skipped; exit 0 in 85.21 seconds.

### Files changed

- `src/control/executionSnapshot.ts`
- `src/control/planImport.ts`
- `tests/control/executionSnapshot.test.ts`
- `tests/control/planImport.test.ts`

### Self-review

- Estimate authority is not taken from the caller: every stored record is parsed by the closed reader, nonterminal commitments are selected from verified state, and exact ID/cardinality/amount matching precedes the limit check. Exact matching means each persisted commitment enters the `BigInt` sum once and only once.
- The immutable execution snapshot still excludes mutable estimate/run state as required; estimate rows are used only for confirmation-time conservation and are filtered out of snapshot allocations.
- The async failure handoff deliberately throws the original failure inside the ledger expansion savepoint. Durable classified `ControlError`s become immutable typed outcomes; non-durable/transient `ControlError`s and unexpected errors rethrow after rollback.
- A command committed while a probe is in flight is replayed before the captured failure is evaluated, preventing duplicate effects and preserving the original durable result.
- `docs/handoff/handoff.md` and `node_modules` were preserved and excluded from staging. No Task 5 work was introduced and no blockers remain.

## Fix round 3

### Outcome

Corrected the shared command-ledger validation order. `applyWebCommand` now performs, in order: raw command replay/conflict lookup, group `expectedRevision` CAS, dynamic expansion, then endpoint/domain application. A stale new command therefore persists an immutable `revision-conflict` without invoking defaults, profile resolution, probes, or endpoint callbacks, and its effective-payload and authority-command identity columns remain `null` because no expansion occurred.

The change preserves absent-group import at revision 0, same-command replay before CAS, and the existing global shutdown path with revision 0 and nullable result revisions.

### RED evidence

Command:

`rtk npm test -- tests/control/commandLedger.test.ts tests/control/planImport.test.ts`

Result before implementation: 2 tests failed and 60 passed. Both failures received durable `profile-changed` where the spec requires `revision-conflict`: one direct stale ledger command and one import whose failing capability probe lost a race to a different committed import.

### GREEN evidence

Command:

`rtk npm test -- tests/control/commandLedger.test.ts tests/control/planImport.test.ts && rtk npm run typecheck && rtk git diff --check`

Result: 2 test files passed, 62 tests passed; TypeScript `tsc --noEmit -p tsconfig.json` passed; diff check passed.

Coverage proves a stale command performs zero expansions/applications, stores null effective/authority identity fields, and durably replays after later revision changes; an identical in-flight command still replays its winner; a different in-flight command observes the advanced revision before its captured probe failure; and the resulting revision conflict replays before changed defaults or profile I/O.

### Full-suite verification

Command:

`rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

Result: 158 test files passed, 1 skipped; 1,329 tests passed, 3 skipped; exit 0 in 86.37 seconds.

### Files changed

- `src/control/commandLedger.ts`
- `tests/control/commandLedger.test.ts`
- `tests/control/planImport.test.ts`

### Self-review

- Raw command identity remains first: an identical durable command replays and a same-ID/different-raw command conflicts before current revision is considered.
- Revision CAS now precedes all effective-command construction. Because the identity variables initialize to `null` and are assigned only after successful expansion, stale rows cannot fabricate trusted defaults or hashes.
- The absent-group current revision remains 0, so a fresh import with `expectedRevision: 0` still expands and commits normally. Valid shutdown commands remain global, use `expectedRevision: 0`, and preserve null command/projection revisions.
- Durable and non-durable expansion/application classification is otherwise unchanged; only the required precedence moved.
- `docs/handoff/handoff.md` and `node_modules` were preserved and excluded from staging. No Task 5 work was introduced and no blockers remain.

## Fix round 4

### Outcome

Closed the remaining async validation-order gap: `importControlPlanAsync` now calls `preflightWebCommand` before dynamic defaults, profile resolution, capability probing, or source resolution/reads. Preflight uses the store's `BEGIN IMMEDIATE` transaction to check existing raw command identity first, then current revision. It replays the original result, rejects same-ID/different-raw requests, or commits a new stale command's `revision-conflict` atomically. A current miss returns `null` without writing or reserving anything.

`applyWebCommand` retains its final transactional identity/CAS checks after preparation. Both paths share the command-row persistence helper; pre-expansion conflicts leave effective-payload and authority-command JSON/hash fields null. Commit: `b84ae62` — `fix(control): preflight async import revisions before I/O`.

### RED evidence

Command: `rtk npm test -- tests/control/commandLedger.test.ts tests/control/planImport.test.ts`

Result before implementation: 8 tests failed, 57 passed. The new initially-stale async import regression observed a defaults callback invocation; the ledger preflight, same-ID conflict, and global checks failed because the preflight API did not exist. The focused test command required normal sandbox escalation so Vitest could write its generated configuration in this designated worktree; the actual RED result came from the running tests.

### GREEN evidence

- `rtk npm test -- tests/control/commandLedger.test.ts tests/control/planImport.test.ts`: 2 files passed, 66 tests passed.
- `rtk npm run typecheck`: passed (`tsc --noEmit -p tsconfig.json`).
- `rtk git diff --check`: passed.

Coverage now proves initially stale async imports call zero defaults/resolve/probe/source callbacks; their durable conflict replays after the revision and defaults change; same-ID/different-raw conflicts win before CAS; current absent/existing/global commands preflight with zero database writes; a preflight conflict rolls back if its transaction cannot commit; a successful in-flight probe still loses to an advanced revision before source I/O; existing failing-probe and same-ID in-flight races remain covered; and global shutdown retains revision 0, null result versions, and one command namespace across epochs.

### Full-suite verification

Command: `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`

Result: 158 test files passed, 1 skipped; 1,333 tests passed, 3 skipped; exit 0 in 87.12 seconds.

### Files changed and concerns

- `src/control/commandLedger.ts`
- `src/control/planImport.ts`
- `tests/control/commandLedger.test.ts`
- `tests/control/planImport.test.ts`

No blocking concerns remain in this scoped fix. The deferred `normalizeControlPlan` Minor is untouched. `docs/handoff/handoff.md` and `node_modules` were preserved and excluded from the commit. No Task 5 work was introduced.
