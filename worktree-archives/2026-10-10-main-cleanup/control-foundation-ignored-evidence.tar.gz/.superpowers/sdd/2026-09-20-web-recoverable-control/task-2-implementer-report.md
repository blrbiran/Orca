# Task 2 implementer report

## Status

PASS — Task 2 is implemented and committed as `e05fc971da98eb0e25c29fc99deb83a0d13d110a` (`feat(control): persist web command lifecycle`).

The pre-existing modified `docs/handoff/handoff.md` and untracked `node_modules` were neither altered for this task nor staged.

## TDD evidence

### RED

Command:

```text
rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts
```

The first sandboxed attempt stopped before test discovery because Vite could not create its temporary config file in the assigned worktree (`EPERM`). After allowing the required worktree write, the feature RED was observed:

```text
Test Files  4 failed (4)
Tests       2 failed | 17 passed (19)
Failed suites: missing ../../src/control/commandLedger.js and ../../src/control/projectionJournal.js
Existing-suite failure: readVersions is not a function
Migration-suite failure: legacySchema was not yet available
```

A later focused RED was also captured for global ledger scope:

```text
rtk npm test -- tests/control/commandLedger.test.ts -t "keeps one global command namespace"
1 failed | 8 skipped
Expected command-id-conflict; received conflict expanded
```

This proved the prior per-epoch global key did not enforce one global command namespace. The key was then made process-epoch independent.

### Focused GREEN and typecheck

Command:

```text
rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts && rtk npm run typecheck
```

Result:

```text
Test Files  4 passed (4)
Tests       32 passed (32)
tsc --noEmit -p tsconfig.json: exit 0
```

### Mandatory full root suite

Command:

```text
rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test
```

Result:

```text
exit code 0
Test Files  151 passed | 1 skipped (152)
Tests       1225 passed | 3 skipped (1228)
Duration    98.00s
```

The skipped ccloop protocol integration tests were pre-existing. No live model was called.

## Files changed

- `src/control/commandLedger.ts` — canonical raw/effective/authority identities, durable status/body replay, stale revision persistence, group/global scope, CAS/projection integration, and lookup.
- `src/control/projectionJournal.ts` — transaction-deduplicated per-group projection sequences, global change sequence, retention/gap reads, and overflow guards.
- `src/control/migrations.ts` — schema version 2, atomic schema-1 migration, Web command columns, projection metadata/journal, and durable proposal/estimate/snapshot/stop/recovery/wake/request/join tables.
- `src/control/store.ts` — schema-1 acceptance and transactional migration, plus projection transaction lifecycle.
- `src/control/commands.ts` — legacy `applyCommand` compatibility with explicit-column inserts and projection recording.
- `src/control/queries.ts` — projection-aware group saves and `readVersions`.
- `tests/control/commandLedger.test.ts` — default replay, identity conflict ordering, stale/4xx replay, hash/body persistence, global scope, and overflow.
- `tests/control/projectionJournal.test.ts` — authority/projection separation, per-transaction deduplication, multi-group global sequence, retention gaps, and overflow rollback.
- `tests/control/commands.test.ts` — legacy revision/projection regression assertions.
- `tests/control/store.test.ts` — schema-1 migration and durable table coverage.

## Self-review

- Confirmed existing-command raw identity is checked before dynamic default expansion and before stale-revision evaluation.
- Confirmed replays do not rerun expansion or application callbacks and preserve original status/body.
- Confirmed legacy commands still replay with their former payload-hash/result representation; Web rows coexist in the expanded table.
- Confirmed command authority and UI projection versions are separate; observations through `saveGroup` do not increment authority.
- Confirmed a transaction increments global `changeSeq` once and each affected group `projectionSeq` once, including repeated calls and duplicate IDs.
- Confirmed safe-integer exhaustion rolls back command, group, and journal state.
- Confirmed schema 1 migrates in a single SQLite transaction while unknown future versions remain read-only rejected.
- Confirmed staged/committed paths matched the ten-file Task 2 allowlist; `git diff --cached --check` was clean before commit.

## Concerns

No known functional blocker. Node emitted its existing experimental SQLite warning during tests. Projection journal retention is deliberately bounded at 64 global changes; callers receive `resetRequired` when their sequence predates that retained window.

## Fix round 1

Status: PASS — review findings fixed and committed as `adb468d9cdc60cd50f8cf2d0d431faee8dd21995` (`fix(control): project durable command transitions`).

### RED

Command:

```text
rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/checkpoints.test.ts
```

Result before production changes:

```text
Test Files  3 failed (3)
Tests       5 failed | 22 passed (27)
```

The failures demonstrated that accepted and unknown start transitions did not advance projection state, post-acceptance work repair did not advance projection state, a thrown `group-budget-unavailable` escaped without a durable result, and a protocol-invalid success body was persisted instead of rejected.

### Focused GREEN

Command:

```text
rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/checkpoints.test.ts
```

Result:

```text
Test Files  3 passed (3)
Tests       27 passed (27)
```

### Task 2 regression and typecheck

Command:

```text
rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts tests/control/dispatch.test.ts tests/control/checkpoints.test.ts tests/control/budget.test.ts tests/control/continuation.test.ts && rtk npm run typecheck
```

Result:

```text
Test Files  8 passed (8)
Tests       70 passed (70)
tsc --noEmit -p tsconfig.json: exit 0
```

### Mandatory full root suite

Command:

```text
rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test
```

Result:

```text
exit code 0
Test Files  151 passed | 1 skipped (152)
Tests       1231 passed | 3 skipped (1234)
Duration    88.29s
```

No live model was called.

### Files changed

- `src/control/commandLedger.ts` — validates durable 2xx/4xx bodies, checks success identity and final versions, rolls failed application work back to a savepoint, durably maps expected domain `ControlError`s, preserves unexpected-error rollback, and validates replay/lookup bodies.
- `src/control/queries.ts` — adds a projection-aware, no-op-sensitive centralized work save.
- `src/control/budget.ts` — makes run saves projection-aware and no-op-sensitive and routes claim work state through the centralized work save.
- `src/control/checkpoints.ts` — routes checkpoint and late-acceptance work transitions through the centralized work save.
- `src/control/continuation.ts` — routes continuation work state through the centralized work save.
- `src/control/schedulerBridge.ts` — routes reconciliation contract changes through the centralized work save.
- `tests/control/commandLedger.test.ts` — covers thrown-domain durability/replay, unexpected rollback, and invalid success, failure, and stored lookup bodies.
- `tests/control/projectionJournal.test.ts` — covers claim, starting, accepted, and unknown run/work invalidation with per-transaction deduplication.
- `tests/control/checkpoints.test.ts` — covers exactly-once late-acceptance projection repair, including an idempotent second repair.

### Self-review

- Audited all existing direct `runs` and `work_items` mutations: every insert is already paired with a group/work projection in its transaction, while every mutable serialized run/work update now passes through a centralized projection-aware save.
- Confirmed one transaction can call run, work, and group saves without advancing a group more than once; distinct start transactions advance independently.
- Confirmed byte-identical run/work retries do not create false projection changes.
- Confirmed expected typed failures roll back partial callback writes before committing the immutable error result; unexpected errors roll back the entire command and leave no ledger row.
- Confirmed only validated closed protocol bodies are canonicalized or returned from persistence, with durable failures required to be non-retryable.
- Confirmed authority revision, projection sequence, and global change sequence remain distinct and retain atomic safe-integer overflow behavior.
- Confirmed the staged diff contained only the nine fix files. The pre-existing modified `docs/handoff/handoff.md` and untracked `node_modules` remain unstaged and unchanged by this work.

### Concerns

No known functional blocker. Node continues to emit its existing experimental SQLite warning during tests. The durable `ControlError` mapping is intentionally limited to the currently specified client/domain catalog; unrecognized `ControlError`s still throw and roll back as internal failures.

## Fix round 2

Status: PASS — the remaining review finding is fixed and committed as `16f6bec0d050fbc379fc942dbc6f788fe9bb913f` (`fix(control): persist classified command failures`).

### RED

Primary command:

```text
rtk npm test -- tests/control/commandLedger.test.ts
```

Result before production changes:

```text
Test Files  1 failed (1)
Tests       5 failed | 17 passed (22)
```

The failures showed that `control-invalid-stop`, `duplicate-task-id`, `graph-dangling-dependency`, and `graph-cycle` escaped instead of becoming durable typed outcomes, and that expected `profile-changed` failure during expansion escaped before ledger persistence.

A second RED captured global expansion-result nullability:

```text
rtk npm test -- tests/control/commandLedger.test.ts -t "persists global expansion failures"
Test Files  1 failed (1)
Tests       1 failed | 22 skipped (23)
Failure: control-command-result-invalid
```

### Focused GREEN and typecheck

Command:

```text
rtk npm test -- tests/control/commandLedger.test.ts && rtk npm run typecheck
```

Result:

```text
Test Files  1 passed (1)
Tests       23 passed (23)
tsc --noEmit -p tsconfig.json: exit 0
```

### Task 2 regression and typecheck

Command:

```text
rtk npm test -- tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts tests/control/dispatch.test.ts tests/control/checkpoints.test.ts tests/control/budget.test.ts tests/control/continuation.test.ts && rtk npm run typecheck
```

Result:

```text
Test Files  8 passed (8)
Tests       81 passed (81)
tsc --noEmit -p tsconfig.json: exit 0
```

### Mandatory full root suite

Command:

```text
rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test
```

Result:

```text
exit code 0
Test Files  151 passed | 1 skipped (152)
Tests       1242 passed | 3 skipped (1245)
Duration    86.24s
```

No live model was called.

### Files changed

- `src/control/errors.ts` — introduces the exported, exact V1 durable command-error status catalog. Catalog absence is the explicit internal/unexpected classification; no suffix inference remains.
- `src/control/commandLedger.ts` — converts catalogued failures from both expansion and application under separate savepoints, preserves raw-identity-first lookup, stores null effective/authority fields when expansion cannot complete, and preserves group/global revision nullability.
- `tests/control/commandLedger.test.ts` — table-drives 400/404/409/422/423 families, all three graph/import validation errors, expansion replay and null effective identity, global expansion revision nullability, and unexpected expansion rollback/rerun.

### Self-review

- Confirmed exact raw command lookup and conflict checking still precede all expansion/default resolution.
- Confirmed successful expansion still precedes stale-revision evaluation, preserving the established command ordering.
- Confirmed expected expansion and application errors roll back their savepoint-local writes, then commit one immutable closed error body; replay performs neither callback again.
- Confirmed an expansion failure records only raw identity plus status/body/current revision. Effective payload and executable authority JSON/hashes remain null instead of being synthesized.
- Confirmed global failures use `commandRevision: null`; group failures use the current indexed group revision.
- Confirmed only exact catalog entries are durable. Ordinary errors, unlisted internal `ControlError`s, invalid expanded commands, transient peer failures, and protocol-invalid outcomes still roll back without a ledger row.
- Confirmed the staged diff contained only the three round-2 files. The pre-existing modified `docs/handoff/handoff.md` and untracked `node_modules` remain unstaged and unchanged by this work.

### Concerns

No known functional blocker. Node continues to emit its existing experimental SQLite warning during tests. Future Web command implementations must add any newly specified client/domain code to the exported status catalog; omission intentionally fails closed as an internal rollback instead of silently persisting an unclassified error.

## Fix round 3

Status: PASS — exhaustive error classification is implemented and committed as `8b5dd7c68a10b2da272e93d72679afde6a966b9e` (`fix(control): exhaust command error classification`).

### RED

Command:

```text
rtk npm test -- tests/control/errorClassification.test.ts tests/control/commandLedger.test.ts
```

Result before production changes:

```text
Test Files  2 failed (2)
Tests       3 failed | 23 passed (26)
```

The failures showed that `budget-overflow` and `numeric-overflow` escaped instead of becoming durable/replayable 422 outcomes, and that there was no exported non-durable classification against which literal source and audited V1 codes could be checked.

### Focused GREEN and typecheck

Command:

```text
rtk npm test -- tests/control/errorClassification.test.ts tests/control/commandLedger.test.ts && rtk npm run typecheck
```

Result:

```text
Test Files  2 passed (2)
Tests       28 passed (28)
tsc --noEmit -p tsconfig.json: exit 0
```

### Task 2 regression and typecheck

Command:

```text
rtk npm test -- tests/control/errorClassification.test.ts tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts tests/control/dispatch.test.ts tests/control/checkpoints.test.ts tests/control/budget.test.ts tests/control/continuation.test.ts && rtk npm run typecheck
```

Result:

```text
Test Files  9 passed (9)
Tests       86 passed (86)
tsc --noEmit -p tsconfig.json: exit 0
```

### Mandatory full root suite

Command:

```text
rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test
```

Result:

```text
exit code 0
Test Files  152 passed | 1 skipped (153)
Tests       1247 passed | 3 skipped (1250)
Duration    87.09s
```

No live model was called.

### Files changed

- `src/control/errors.ts` — adds durable 422 classifications for `budget-overflow` and `numeric-overflow`, completes the explicit durable map, adds the disjoint internal/transient map, and exports the audited V1 Web error-code literal union.
- `tests/control/errorClassification.test.ts` — recursively scans every control source file for literal `ControlError` codes and requires each source and audited V1 code to appear in exactly one classification; also enforces unique, stable V1 ordering.
- `tests/control/commandLedger.test.ts` — proves both overflow codes persist and replay without rerunning application, while representative explicitly internal and transient `ControlError`s roll back and rerun.

### Self-review

- Audited every literal `new ControlError("...")` under `src/control` and every V1 typed command/background code named by the Web recoverable-control spec.
- Confirmed the durable and non-durable maps are disjoint and their values are constrained by literal status/classification unions.
- Confirmed the source scanner makes a newly added or changed literal `ControlError` fail tests until it is explicitly classified.
- Confirmed `v1WebErrorCodes` is a typed, sorted, duplicate-free authoritative set; an added V1 code cannot typecheck unless it belongs to one classification.
- Confirmed `budget-overflow` and `numeric-overflow` are immutable 422 outcomes with `retryable: false`, replay the original body, and run application once.
- Confirmed ordinary errors, `control-sequence-overflow` (internal), and `control-peer-timeout` (transient) roll back partial writes, create no command row, and rerun on the same command ID.
- Confirmed `recovery-blocked` is classified as the spec-required durable 423 recovery lock rather than 422.
- Confirmed the staged diff contained only the three round-3 files. The pre-existing modified `docs/handoff/handoff.md` and untracked `node_modules` remain unstaged and unchanged by this work.

### Concerns

No known functional blocker. Node continues to emit its existing experimental SQLite warning during tests. Dynamic error strings such as adapter exit-code suffixes are deliberately not durable V1 command outcomes; they remain internal/transient and are not literal-code scan targets.

## Fix round 4

Status: PASS — committed as `c708011e902dbacb5981ae9ff9ed98bce3ed1837` (`fix(control): close classified error construction`). This round replaces the literal-source-scan guarantee from round 3 with an enforced TypeScript construction contract.

### RED

Commands:

```text
rtk npm test -- tests/control/errorClassification.test.ts tests/control/commandLedger.test.ts tests/control/ccloopPort.test.ts
rtk npm run typecheck
```

The initial sandboxed test attempt stopped at Vite temporary-config creation with EPERM in the assigned worktree. The authorized escalated retry reached the intended RED:

```text
Test Files  2 failed | 1 passed (3)
Tests       3 failed | 39 passed (42)
```

Both helper-mediated ccloop codes were absent from the non-durable map (`undefined`, expected `internal`). The adapter exit test received dynamic code `control-peer-exit-2:remote-refusal` instead of fixed code `control-peer-exit` with separate diagnostic detail. Typecheck exited 2: all three negative construction assertions reported unused `@ts-expect-error`, and constructor-parameter/code-property equality assertions rejected the old open `string` contract.

### Focused GREEN

The same focused command passed all 42 tests in 3 files. `rtk npm run typecheck` exited 0, including the positive closed-union assertions and negative tests for an unclassified literal, a helper parameter of type `string`, and a dynamic template string.

### Task 2 regression and typecheck

Commands:

```text
rtk npm test -- tests/control/errorClassification.test.ts tests/control/commandLedger.test.ts tests/control/projectionJournal.test.ts tests/control/commands.test.ts tests/control/store.test.ts tests/control/dispatch.test.ts tests/control/checkpoints.test.ts tests/control/budget.test.ts tests/control/continuation.test.ts tests/control/ccloopPort.test.ts
rtk npm run typecheck
```

Result: 10 files passed, 100 tests passed; typecheck exited 0.

### Mandatory full root suite

Command:

```text
rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test
```

Result:

```text
exit code 0
Test Files  152 passed | 1 skipped (153)
Tests       1257 passed | 3 skipped (1260)
Duration    86.85s
```

The three skipped ccloop protocol integration tests are pre-existing. No live model was called.

### Files changed

- `src/control/errors.ts` — closes the constructor and readonly code property over exported `KnownControlErrorCode`; derives that union exclusively from the two catalogs; prevents any shared key with a compile-time `Partial<Record<durable keys, never>>` constraint; exports the classified non-durable subset; classifies the two startup configuration failures as internal and fixed peer exit as transient; keeps dynamic diagnostics in optional detail.
- `src/control/ccloopPort.ts` — constrains the path-validation helper to `NonDurableControlErrorCode`; wraps all external child exit codes and stderr under fixed `control-peer-exit` with separate detail.
- `tests/control/errorClassification.test.ts` — replaces regex scanning with positive/negative compiler contract checks and exhaustive runtime catalog partition/status checks; explicitly covers both missed helper codes.
- `tests/control/commandLedger.test.ts` — checks rollback, absent ledger rows, and same-ID retry for five internal/transient codes in both expansion and application; preserves durable domain-error replay tests.
- `tests/control/ccloopPort.test.ts` — validates fixed exit classification and retained external diagnostics through the real fake-ccloop process.

### Self-review

- Audited every `ControlError` reference/construction under `src/control`, including direct literals, helper parameters, the single dynamic adapter exit expression, and rethrows. The only variable constructor was `regularAbsolute` and it now takes the classified non-durable subset. All direct constructors typecheck against the closed union.
- The union has no open `string` or template-literal escape route. Adding a code to neither map fails construction; adding it to both maps fails the map declaration itself. No constructor/helper type assertion was added to bypass that invariant.
- External child-process numeric/string exit values and stderr only enter diagnostic detail. They cannot select a durable domain code or manufacture an unclassified `ControlError` code.
- Existing rethrows in storage/savepoints, archive, cleanup, and resume paths preserve the original error: classified `ControlError` values retain their code; ordinary filesystem/process errors remain ordinary internal exceptions. The ledger still persists only expected classified domain failures and rolls back non-durable/ordinary errors.
- Confirmed both missed startup configuration codes remain internal failures, while peer exit is explicitly transient; neither gets an immutable command result. The rollback tests verify partial writes are removed and the same command ID executes again for both callback phases.
- Confirmed existing domain statuses, command protocol bodies, schema, revisions, projections, and dispatch behavior were not changed. Only peer-exit code/message normalization changed as required: `control-peer-exit-2:remote-refusal` becomes code `control-peer-exit`, detail `2:remote-refusal`, message `control-peer-exit:2:remote-refusal`.
- `git diff --cached --check` passed. The committed diff contained exactly the five files above. The pre-existing `docs/handoff/handoff.md` change and untracked `node_modules` were preserved and unstaged. This ignored report is retained as local evidence.

### Concerns

No known functional blocker. The compile-time contract requires running the root typecheck (Vitest alone transpiles TypeScript and does not enforce negative type assertions). Node still emits its existing experimental SQLite warning. Any external consumer that inspected the former dynamic peer-exit code must use fixed `control-peer-exit` and diagnostic detail; no such in-repository consumer remains.
