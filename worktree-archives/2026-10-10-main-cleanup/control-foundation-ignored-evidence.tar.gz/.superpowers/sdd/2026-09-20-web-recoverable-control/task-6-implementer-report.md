# Task 6 implementer report

## Outcome

Implemented draft defaults, frozen estimator preflight and immutable request/contract/output records, durable accounted estimator claim and completion hooks, atomic proposal edits, atomic confirmation, live set-limit, and the five scoped Web mutation routes. HTTP handlers publish command-ledger results and never invoke ExecutionPort. Ordinary Web draft claims remain forbidden. Scheduler contract resolution can consume the archived derived contract without rereading mutable source bytes.

Commit: `24029f4` — `feat(control): confirm accounted web proposals`.

## Controller rulings applied

- Task 6 owns durable estimator request/wake/accounted claim-settlement hooks; Task 7 owns actual provider delivery and the proof/provider-start/session-attempt handshake. No provider is invoked by these hooks or HTTP mutations.
- Minimal `planImport.ts` and `queries.ts` changes share estimator authority and keep canonical reads coherent.
- Structurally valid duplicate proposal targets pass the closed raw/effective schema and are rejected by the command ledger as durable `422 duplicate-proposal-target`. Unknown fields and malformed operations remain schema failures.
- Execution snapshot ceiling/reserve remain immutable confirmation-time audit values. Later live ceiling/reserve changes are checked against independent current conservation; task/review grants, provenance, profiles, plan/proposal identity, and derived contracts remain exact.
- Existing usage transactions perform the minimal Web-aware ledger/proposal-reserve synchronization through `budget.ts`; provider marker/proof admission remains outside this task.
- The existing Express parser uses a control-only POST verification hook to reject duplicate object keys and noncanonical scalars before information is lost. JSON parsing errors use the closed 400 envelope. Non-control parsing semantics are unchanged.

## Implementation details

- `complex1mDefaults(5)` produces base `(17,750,000; 85,500,000; 17; 17)`, reserve `(3,550,000; 17,100,000; 4; 4)`, and limit `(21,300,000; 102,600,000; 21; 21)`, in tokens/activeMs/attempts/sessions order. Aggregation, residuals, ceiling arithmetic, and proposal/estimate increments use BigInt with checked safe-number conversion. Import shares the fixed grants with the estimator module.
- Estimator request bytes bind the archived plan, exact profile/hash, effective creation-time capabilities, instructions, response schema, tokenizer parameters, framing overhead, and output maximum. Input size is exactly serialized tokens plus framing, with output added for both context-window and grant admission. Capability and input-too-large outcomes persist terminal estimates without wakes/runs/calls. Eligible estimates reserve the fixed grant and deterministic wake atomically.
- Claim rechecks frozen-profile capabilities, preserves the frozen request/hash, and creates a closed estimator run, one session reservation, immutable dispatch envelope, and deterministic claim identity. Capability degradation releases the unused commitment without creating a run. Replayed claims return the original run. The shared admission gate can bracket probe and claim commit.
- Completion validates the entire structured output and exact task set, stores an immutable receipt/output record, releases only the settled known remainder, and changes projection rather than command revision. A trusted scheduler can commit its verified terminal state through `commitTerminal` inside the same transaction. Invalid settlement data rolls back that callback, output, reserve, and lifecycle writes together. The callback is never exposed as an HTTP payload.
- Proposal operations are atomic, preserve sparse per-field provenance, validate explicit model references/values and default restoration, reject duplicate targets and no-ops, and check proposal version before domain state. Combined grant/limit changes compute one final residual; no operation order or implicit limit growth affects authority. Editing pre-start ready invalidates the snapshot reference and returns the group to draft.
- Confirmation checks current usage, unknown state, outstanding commitments, every selected profile hash, worker-only context policy, model provenance, and handoff execution eligibility inside the transaction. It persists immutable derived wrappers and execution snapshot together with confirmed grants and the command result. A publication exception rolls back all derived records and state. Goal-review reserve/remaining fields track the editable and confirmed allocation.
- `set-limit` changes only live ceiling/reserve, recomputes outstanding commitment totals, rejects impossible decreases and no-ops, and preserves frozen grant authority. Confirmed reads independently validate current ledger conservation while maintaining exact frozen task/review identity.
- Mutation routes use a stable persisted `operator-<uuid>` principal, closed envelopes, and the persisted original command status/body for both first response and replay. Import is 201; eligible estimate is 202; proposal/confirm/set-limit and terminal estimate are 200; command lookup preserves the original response inside its wrapper.

## RED evidence

All commands ran from `/Users/biran/.codex/worktrees/control-foundation-0919/Orca` and were prefixed with `rtk`.

1. `rtk npm test -- tests/control/estimator.test.ts tests/control/proposal.test.ts tests/control/confirmation.test.ts`: after the permitted sandbox rerun, 3 suites failed because `estimator.ts` and `webService.ts` were missing, matching the planned first RED. The initial sandbox invocation could not create Vite's temporary config (`EPERM`); no production behavior was inferred from that infrastructure failure.
2. The same three-file command after additional estimator lifecycle/limit tests: 4 failed, 5 passed. Missing `claimEstimate` caused three failures; mutable set-limit caused `recovery-blocked:execution-snapshot-identity` in the strict read path.
3. `rtk npm test -- tests/control/proposal.test.ts`: 1 failed, 1 passed; mutation route returned 404 instead of 202.
4. `rtk npm test -- tests/control/confirmation.test.ts`: 2 failed, 4 passed; accounted usage left Web ledger stale and ordinary draft claim returned target-version-conflict instead of the required group-state rejection.
5. `rtk npm test -- tests/control/estimator.test.ts tests/control/proposal.test.ts`: 1 failed, 9 passed; contradictory remaining grant incorrectly settled and released capacity.
6. `rtk npm test -- tests/control/proposal.test.ts`: 1 failed, 2 passed; malformed control JSON returned 500 instead of the closed 400 envelope.
7. `rtk npm test -- tests/control/confirmation.test.ts`: 1 failed, 6 passed; archived scheduler contract reader was missing.
8. `rtk npm test -- tests/control/estimator.test.ts tests/control/proposal.test.ts`: 2 failed, 10 passed; unchanged explicit-soft profile incorrectly required proof at claim, and group state incorrectly took precedence over stale proposal version.
9. `rtk npm test -- tests/control/confirmation.test.ts`: 1 failed, 7 passed; edited review grant left `reviewRemaining.tokens` at 1,000,000 instead of 500,000.
10. `rtk npm test -- tests/control/estimator.test.ts`: 1 failed, 8 passed; missing same-transaction terminal callback returned run-stop-unconfirmed instead of rolling back a contradictory settlement as recovery-blocked.

## GREEN evidence

- Initial three-file GREEN: 3 files, 4 tests passed.
- Estimator/proposal/confirmation plus Panel reads: 4 files, 26 tests passed.
- Proposal/routes plus import/protocol compatibility: 3 files, 41 tests passed.
- Usage/confirmation/estimator/budget compatibility: 4 files, 29 tests passed.
- Expanded estimator/proposal/confirmation/protocol/import/snapshot/error classification: 7 files, 74 tests passed.
- Final Task 6-only regressions before the last callback addition: 3 files, 20 tests passed.
- Final required focused acceptance command: `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test -- tests/control/estimator.test.ts tests/control/proposal.test.ts tests/control/confirmation.test.ts tests/panel/controlReadApi.test.ts tests/control/budget.test.ts tests/control/schedulerBridge.test.ts` — 6 files, 61 tests passed, exit 0, 25.39 seconds. An earlier invocation without the explicit environment failed four scheduler integration cases because the sibling default ccloop binary did not exist; the pinned-build run passes.
- `rtk npm run typecheck` — passed after the final production changes.
- `rtk npm --workspace web run check` — final repeat passed: 9 files, 34 tests, exit 0 in 2.01 seconds.
- First full root suite: `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test` — 162 files passed, 1 skipped; 1,370 tests passed, 3 skipped; exit 0 in 91.66 seconds. This preceded the final goal-review/commitment and callback fixes.
- Final full root suite: `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test` — 162 files passed, 1 skipped; 1,372 tests passed, 3 skipped; exit 0 in 93.45 seconds after all production changes.
- `rtk git diff --check` — passed.

## Files

Created:

- `src/control/estimator.ts`
- `src/control/webService.ts`
- `tests/control/estimator.test.ts`
- `tests/control/proposal.test.ts`
- `tests/control/confirmation.test.ts`
- `tests/control/fixtures/web.ts`

Modified:

- `src/control/budget.ts`
- `src/control/executionSnapshot.ts`
- `src/control/planImport.ts`
- `src/control/queries.ts`
- `src/control/schedulerBridge.ts`
- `src/control/usage.ts`
- `src/control/webProtocol.ts`
- `src/panel/controlApi.ts`
- `src/panel/controlViews.ts`
- `src/panel/server.ts`
- `tests/control/webProtocol.test.ts`

The pre-existing `docs/handoff/handoff.md` change and untracked `node_modules` are preserved and excluded from staging. This report is retained under the repository's ignored `.superpowers` evidence directory.

## Self-review and handoff concerns

- No merge, push, publish, cleanup, live-model chain, or subagent dispatch was performed.
- Task 7 must deliver `scheduler_wakes`, consume the `estimate-contract:<groupId>:<estimateId>` immutable binding, consume `estimate:<groupId>:<estimateId>` claim metadata/envelope, and implement the durable provider proof/marker/attempt/session admission boundary before invoking an adapter. `completeEstimate` must receive scheduler-verified terminal state and known usage; the optional synchronous callback exists to commit that state atomically with completion.
- The run claim deliberately initializes provider attempt ordinal zero and reserves a session without charging it as used. These are pre-provider hooks, not a substitute for Task 7's durable provider-start truth table.
- Legacy ordinary/continuation writers still require the Task 7 closed authority integration described by Task 5. This task does not synthesize ambiguous historical fields or migrate uncertain rows; strict reads remain fail-closed.
- Panel lifecycle construction still needs the later planned integration to supply `WebControlService` and the shared admission gate. The implemented mutation routes activate only when the service is injected; no hidden provider dispatch fallback is introduced.
- No Task 6 blocker remains. The final commit contains exactly 17 Task 6 files; post-commit status contains only the preserved `docs/handoff/handoff.md` modification and untracked `node_modules`.
