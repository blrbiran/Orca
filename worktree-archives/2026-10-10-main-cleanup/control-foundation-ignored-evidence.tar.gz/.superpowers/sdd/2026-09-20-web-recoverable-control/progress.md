# SDD ledger — plan: docs/superpowers/plans/2026-09-20-web-recoverable-control.md

Spec: `docs/superpowers/specs/2026-09-19-web-recoverable-control-design.md`
Plan baseline: `cc653ad` (`docs(control): specify web recoverable control`)
Execution branch/tree: `codex/control-foundation-0919` at `/Users/biran/.codex/worktrees/control-foundation-0919/Orca`

## Task status

- [x] Task 1: Canonical protocol values and closed schemas
- [x] Task 2: Durable command ledger, revisions, and projection journal
- [x] Task 3: Trusted allowlists, profile routing, and admission gate
- [x] Task 4: Immutable plan import and archival
- [x] Task 5: Canonical read models and invalidation API
- [ ] Task 6: Draft defaults, estimator, proposal editing, and confirmation
- [ ] Task 7: Durable start, proof recovery, and context-watermark control
- [ ] Task 8: Pause, handoff-stop, shutdown, continuation, and recovery commands
- [ ] Task 9: Thin Web control client and recoverable browser state
- [ ] Task 10: End-to-end acceptance, fault evidence, and non-live consumer smoke

## Baseline

- Spec SHA-256: `279acec04eacb5c20373faab8e4a4f9c6a691a31c273694ec66e6e40cc7f3a00`.
- Plan SHA-256 at execution start: `9ad16a9e672de48647b4c21564067bda3b944d9f703263f75d3de865763841bb`.
- `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`: 148 files passed, 1 skipped; 1192 tests passed, 3 skipped; total 1195; exit 0.
- The worktree already contained a modified `docs/handoff/handoff.md` and untracked `node_modules`; task commits must not absorb either.

Ruling: Root regression commands will set `ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js` because this isolated tree has no sibling ccloop checkout — this preserves the already-verified real consumer boundary — if wrong, regressions could exercise the wrong consumer artifact and require rerunning against a corrected path.

Ruling: This plan's `.superpowers/sdd/2026-09-20-web-recoverable-control/` workspace will be retained after clean review because the user explicitly required preserving all evidence — this overrides the skill's default cleanup step — if wrong, the cost is retained local scratch/evidence rather than loss of product data.

## Preflight consistency scan

### Per-task internal consistency

| Task | Tests versus implementation/files | Result |
|---|---|---|
| 1 | Canonical/hash/schema tests name the two new modules plus the two declared shared type/schema files. | Consistent; closed schemas feed all later tasks. |
| 2 | Ledger/journal/revision tests match the migration, store, command, and query surfaces listed. | Consistent; legacy `applyCommand` is explicitly preserved. |
| 3 | Profile/gate/config tests match router, admission, trusted config, port, and service changes. | Consistent; browser-path rejection is part of the trusted boundary. |
| 4 | Import/snapshot tests match immutable archive, plan parser, queries, and snapshot changes. | Consistent; crash tests are an explicit additional step. |
| 5 | Real-HTTP read tests and parity tests match new Panel view/API/error files and Web DTO mirror. | Consistent; mutation routes are deliberately deferred to Task 6 onward. |
| 6 | Estimator/proposal/confirmation tests match Web service, snapshot, budget, scheduler, and mutation-route changes. | Consistent; exact complex-1m values and derived limits are stated. |
| 7 | Dispatch/proof/context tests match the new dispatch/context modules and existing recovery/service/API seams. | Consistent; strict and soft behavior remain distinct. |
| 8 | Stop/continuation/lifecycle tests match stop/lifecycle modules and existing handoff/recovery/server/API seams. | Consistent; shutdown and recovery-before-listen are explicit. |
| 9 | Reducer/component tests match the new browser API/state/components and existing app/type integration. | Consistent; browser authority is explicitly prohibited. |
| 10 | API/recovery/fault/mutation/consumer tests match named verification scripts and evidence files. | Consistent; all §9.3/§9.4 classes are repeated explicitly rather than deferred by reference. |

### Cross-task shared-file and shared-interface scan

| Tasks | Producer → consumer / shared surface | Result |
|---|---|---|
| 1 → 2 | Canonical hashes and command schemas → ledger identities and persisted payloads. | Consistent. |
| 1 → 3 | Profile snapshot/hash schemas → profile resolver/router. | Consistent. |
| 1 → 4 | Plan/snapshot schemas → immutable import/archive. | Consistent. |
| 1 → 5 | Read DTO schemas → Panel views and Web DTO mirror. | Consistent. |
| 1 → 6 | Mutation/result/budget schemas → estimator and proposal commands. | Consistent. |
| 1 → 7 | Proof/context/start schemas → dispatch and context state machines. | Consistent. |
| 1 → 8 | Stop/continuation/global command schemas → lifecycle orchestration. | Consistent. |
| 1 → 9 | Closed DTOs → browser API/state/components. | Consistent. |
| 1 → 10 | Protocol fixtures → full acceptance and mutation assertions. | Consistent. |
| 2 → 3 | Durable store/command transaction primitives → profile/gate-mediated mutations. | Consistent. |
| 2 → 4 | Command replay, revisions, migrations → atomic idempotent import. | Consistent. |
| 2 → 5 | Queries and projection journal → canonical read/invalidation API. | Consistent. |
| 2 → 6 | Command ledger and wakes → estimates, edits, confirmation, limits. | Consistent. |
| 2 → 7 | Durable wakes and revisions → start/claim/proof recovery. | Consistent. |
| 2 → 8 | Transactions, global scope, journals → stop/continuation/shutdown. | Consistent. |
| 2 → 9 | Epoch/changeSeq/projectionSeq → browser cache invalidation. | Consistent. |
| 2 → 10 | Replay/fault primitives → lost-response, restart, concurrency evidence. | Consistent. |
| 3 → 4 | Allowlists/profile resolution → import validation and initial proposal. | Consistent. |
| 3 → 5 | Safe profile/config projections → config/read endpoints. | Consistent. |
| 3 → 6 | Frozen capabilities/defaults → estimator request and confirmation. | Consistent. |
| 3 → 7 | Router probes and admission gate → pre-command/pre-claim dispatch. | Consistent. |
| 3 → 8 | Admission gate/barrier → shutdown lifecycle and mutation rejection. | Consistent. |
| 3 → 9 | Safe config/profile DTOs → UI display only. | Consistent. |
| 3 → 10 | Deterministic profiles/port → non-live real-Panel and ccloop smoke. | Consistent. |
| 4 → 5 | Archived plan/contracts/snapshot queries → group/read views. | Consistent. |
| 4 → 6 | Default proposal and snapshot builder → editing/estimate/confirmation. | Consistent. |
| 4 → 7 | Immutable execution snapshot → durable start envelope. | Consistent. |
| 4 → 10 | Atomic import/archive → restart and crash acceptance. | Consistent. |
| 5 → 6 | `controlApi.ts` read router/error map → mutation route extension. | Consistent; sequential ownership avoids file conflict. |
| 5 → 7 | `controlApi.ts` and canonical views → start/recovery route extension. | Consistent; Task 7 consumes Task 5/6 state. |
| 5 → 8 | `controlApi.ts` → stop/continuation/lifecycle route extension. | Consistent; stronger stop semantics remain service-side. |
| 5 → 9 | HTTP DTOs/routes → browser wrappers and state reducer. | Consistent. |
| 5 → 10 | Authenticated real HTTP surface → acceptance tests. | Consistent. |
| 6 → 7 | Confirmed execution snapshot/derived contracts → dispatch eligibility and accounting. | Consistent. |
| 6 → 8 | Budgeted command service → stop/continuation accounting. | Consistent. |
| 6 → 9 | Proposal/estimate/confirm routes → budget editor UI. | Consistent. |
| 6 → 10 | Estimator and confirmation transactions → fault/mutation coverage. | Consistent. |
| 7 → 8 | Runs, proof recovery, context requests → handoff joins and continuation. | Consistent. |
| 7 → 9 | Run/proof/context read states → UI controls and recovery views. | Consistent. |
| 7 → 10 | Start/proof/context seams → hostile fault and consumer smoke. | Consistent. |
| 8 → 9 | Stop/continuation/shutdown routes and states → Web controls. | Consistent. |
| 8 → 10 | Atomic stop/lifecycle operations → restart/fault acceptance. | Consistent. |
| 9 → 10 | Browser reducer/components → Web acceptance and parity checks. | Consistent. |

No plan-mandated empty assertions or verbatim production-logic duplication was found in the preflight scan.

## Task review log

Task 1: review at `8eeba0f` — spec noncompliant / needs fixes: verb-coupled raw/effective command payload schemas; Codex phase-end+soft refinement; dispatch/proof preimage invariants; read allocation/result revision invariants.

Task 1: minor (deferred): `canonicalJson.ts` validates array keys but not array element property descriptors, so accessor-backed elements may execute during canonicalization; final whole-branch reviewer must triage.

Task 1: fix round 1/5 (3 addressed, 1 open — browser command success permits exactly one null revision; commits `8eeba0f..a11a296`).

Task 1: fix round 2/5 (1 addressed, 0 open — command success revision nullability; commits `a11a296..21b989c`).

Task 1: complete (commits `cc653ad..21b989c`, review clean).

Task 1: full regression after reviewed code — `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`: 149 files passed, 1 skipped; 1211 tests passed, 3 skipped; total 1214; exit 0.

Task 2: review at `e05fc97` — spec noncompliant / needs fixes: all UI-visible run/work writes must journal projection changes; thrown domain 4xx outcomes must persist/replay; stored result bodies must validate against closed success/error schemas.

Ruling: Expand Task 2 beyond its enumerated files to the smallest set of existing run/work persistence paths needed to make projection invalidation complete before Task 5 consumes it — the spec's canonical browser refresh contract is binding and later repair would leave a load-bearing gap — if wrong, the cost is earlier cross-cutting edits and a broader Task 2 regression surface.

Task 2: fix round 1/5 (2 addressed, 1 open — durable domain-error mapping is incomplete and excludes expected graph/import errors plus expansion failures; commits `e05fc97..adb468d`).

Task 2: fix round 2/5 (0 addressed, 1 open — explicit catalog still omits `budget-overflow` and specified `numeric-overflow`; commits `adb468d..16f6bec`).

Task 2: fix round 3/5 (0 addressed, 1 open — direct-literal scanner misses helper-mediated `control-binary-invalid` and `control-adapter-config-invalid`; commits `16f6bec..8b5dd7c`).

Task 2: fix round 4/5 (1 addressed, 0 open — closed disjoint compile-time `ControlError` construction and fixed external peer-exit code; commits `8b5dd7c..c708011`).

Task 2: complete (commits `21b989c..c708011`, review clean).

Task 2: final full regression after reviewed code — `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`: 152 files passed, 1 skipped; 1257 tests passed, 3 skipped; total 1260; exit 0.

Task 3: review at `04b920f` — spec noncompliant / needs fixes: router/probe/hash not enforced on actual claim/start paths; admission barrier misses downstream writers and is held across adapter I/O; router retains caller-mutable profiles; cached allowlist paths are not revalidated against post-start symlink swaps.

Ruling: Wire profile selection and admission through real claim/start/persistence seams in Task 3, including the smallest scheduler-bridge changes, rather than deferring them to Tasks 7/8 — Task 3 explicitly produces the shared enforcement boundary and later tasks must not inherit a bypass — if wrong, the cost is earlier integration work and a broader Task 3 review surface.

Task 3: fix round 1/5 (2 addressed, 2 open plus 1 new Important — recovery accept lacks fresh probe; strict proof token dimension and separate handoff profile are unenforced; resume-bundle publish and archive duplicate hashing violate admission/I/O separation; captured port methods lose receiver; commits `04b920f..1695de4`).

Task 3: fix round 2/5 (profile/recovery/handoff/receiver findings addressed; 1 new Important open — duplicate artifact registration can follow a symlinked artifact-id directory and commit before later rejection; commits `1695de4..77d9efd`).

Ruling: Resume-bundle canonical publication may hold admission across its final no-follow metadata validation and atomic rename — those operations are the writer critical section explicitly required to be gated; only adapter/network/evidence-content reads and staging must remain outside — if wrong, a pathological filesystem metadata stall could delay shutdown and would require a different synchronous/worker isolation mechanism.

Task 3: fix round 3/5 (1 addressed, 0 open — duplicate artifact parent symlink/swap validation; commits `77d9efd..3153673`).

Task 3: complete (commits `c708011..3153673`, review clean).

Task 3: final full regression after reviewed code — `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`: 156 files passed, 1 skipped; 1289 tests passed, 3 skipped; total 1292; exit 0.

Task 4: review at `d2627f9` — spec noncompliant / needs fixes: async probe is outside replay-before-probe orchestration; execution-snapshot preparation can omit imported tasks or exceed group limit; plan read is not bound to the trusted inode witness; archived contract/proposal/estimate reads cast valid JSON without closed validation.

Task 4: minor (deferred): exported `normalizeControlPlan` relies on its current scheduler adapter for closed contract schema and `objective.taskId` binding; final whole-branch reviewer must triage if it remains a reusable public boundary.

Ruling: Add the async replay-before-probe import orchestrator and harden snapshot/path/read authority in Task 4 rather than deferring safety to Tasks 5/6 — later routes and confirmation consume these exact boundaries — if wrong, the cost is a wider Task 4 API and additional integration work before HTTP wiring.

Task 4: fix round 1/5 (3 addressed, 1 open plus 1 new Important — persisted estimate commitments can be omitted/understated in snapshot conservation; async profile-changed rejection occurs before durable command recording; commits `d2627f9..0eb3de0`).

Task 4: fix round 2/5 (1 addressed, 1 open — captured durable preparation failure is persisted before expectedRevision CAS, so an in-flight concurrent group revision change can incorrectly win over required `revision-conflict`; commits `0eb3de0..e661682`).

Task 4: fix round 3/5 (ledger internal ordering addressed, 1 open — async import still performs defaults/profile/probe before entering ledger preflight for a command already stale at call time; commits `e661682..dbb32d7`).

Task 4: fix round 4/5 (1 addressed, 0 open — atomic no-I/O async command preflight before defaults/profile/probe/source access; commits `dbb32d7..b84ae62`).

Task 4: complete (commits `3153673..b84ae62`, review clean; 1 deferred Minor).

Task 4: final full regression after reviewed code — `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`: 158 files passed, 1 skipped; 1333 tests passed, 3 skipped; total 1336; exit 0.

Task 5: review at `6c2a3db` — spec noncompliant / needs fixes: confirmed allocations/derived-contract records are not fully verified; run DTOs synthesize invalid/missing authority; stopped groups invent pause without canonical intent; control Host/error context is incomplete; evidence projection drops malformed/omits handoff and recovery references.

Ruling: Read views must fail closed on missing, malformed, or cross-record-inconsistent canonical authority instead of synthesizing UI defaults — this applies to run, stop, derived-contract, and evidence records — if wrong, the cost is stricter compatibility for legacy/corrupt persisted rows that must be recovered or migrated before Web display.

Task 5: fix round 1/5 (4 addressed, 1 open plus 1 new Important — null elements in evidence collections are silently dropped; globally content-addressed derived contracts are incorrectly treated as exclusively owned by the first group; commits `6c2a3db..e8c1ded`).

Task 5: fix round 2/5 (2 addressed, 0 open — strict collection evidence validation and globally shared derived-contract authority; commits `e8c1ded..15ffcff`).

Task 5: complete (commits `b84ae62..15ffcff`, review clean).

Task 5: final full regression after reviewed code — `rtk env ORCA_CCLOOP_BIN=/tmp/ccloop-codex-0919/dist/cli.js npm test`: 159 files passed, 1 skipped; 1351 tests passed, 3 skipped; total 1354; Web check 34/34; exit 0.

Ruling: Task 6 implements estimator durable request/wake/accounted claim-settlement hooks and immutable output, while Task 7 owns actual provider delivery/proof/start handshake; HTTP mutations never call ExecutionPort — if wrong, the cost is an estimator path that is durable and testable but not externally delivered until the immediately following dispatch task.

Ruling: Permit the smallest Task 6 changes to `planImport.ts` and `queries.ts` needed to reuse frozen estimator authority and keep canonical read validation coherent — if wrong, the cost is a slightly broader diff rather than duplicated estimator freeze/read logic.

Ruling: Proposal-operation duplicate targets are a durable `422 duplicate-proposal-target` domain outcome, so closed payload schemas validate shape/order but WebControlService owns duplicate-target rejection after command-ledger admission — if wrong, malformed duplicates would move from pre-ledger `400` to durable domain `422`, contrary to the previous schema behavior but aligned with the spec's explicit precedence.

Ruling: After confirmation, `set-limit` and estimator settlement may change the current ceiling/explicit reserve without rewriting the immutable confirmation snapshot; read validation keeps task/review grants, provenance, profiles, plan/proposal identity, and derived contracts exact, but checks current limit/reserve against the live conservation ledger separately — if wrong, the UI could accept mutable accounting that should instead require a new snapshot version.
