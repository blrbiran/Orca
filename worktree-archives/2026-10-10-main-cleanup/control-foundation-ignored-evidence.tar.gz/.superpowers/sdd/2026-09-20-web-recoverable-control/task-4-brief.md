### Task 4: Immutable plan import and archival

**Files:**
- Create: `src/control/planImport.ts`
- Create: `src/control/executionSnapshot.ts`
- Create: `tests/control/planImport.test.ts`
- Create: `tests/control/executionSnapshot.test.ts`
- Modify: `src/scheduler/planFile.ts`
- Modify: `src/control/queries.ts`
- Modify: `src/control/snapshot.ts`

**Interfaces:**
- Consumes: Tasks 1–3 canonical records, command ledger, allowlists, profiles, and existing plan/contract validation.
- Produces: `normalizeControlPlan()`, `importControlPlan()`, content-addressed plan/original-contract records, default proposal version 1, and execution-snapshot/derived-contract builders used by Task 6.

- [ ] **Step 1: Write failing atomic import/hash tests**

```ts
it("keeps imported authority unchanged after the source plan is edited", () => {
  const imported = importControlPlan(h.deps, importCommand("g"));
  writeFileSync(h.planPath, differentPlanBytes);
  expect(readArchivedPlan(h.store, "g").planHash).toBe(imported.planHash);
  expect(readArchivedPlan(h.store, "g").canonicalJson).toBe(originalCanonicalJson);
});
```

Cover complete-or-absent transaction, plan/task sort order, duplicate IDs/dependencies, original contract hashes, non-allowlisted IDs, missing/hash-mismatched recovery records, response loss, and changed server estimator default replay.

- [ ] **Step 2: Run focused tests and verify RED**

Run: `rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts tests/control/snapshot.test.ts tests/scheduler/planFile.test.ts`

Expected: FAIL on missing import APIs.

- [ ] **Step 3: Implement immutable import**

```ts
export function normalizeControlPlan(source: AllowlistedPlanSource): ControlPlanV1;
export function importControlPlan(deps: ImportDeps, command: ImportCommand): CommandSuccessV1;
export function buildExecutionSnapshot(input: ConfirmedProposal): ExecutionSnapshotV1;
```

Import group, graph, task contracts, defaults, plan provenance, content-addressed records, and initial estimate work item/terminal preflight state in one transaction. Never retain a mutable source path as execution authority.

- [ ] **Step 4: Add crash-before/after-commit assertions**

Use the existing crash-worker pattern to prove an interrupted import is absent or fully replayable, and a damaged canonical record blocks recovery without inventing state.

- [ ] **Step 5: Verify GREEN and commit**

Run: `rtk npm test -- tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts tests/control/snapshot.test.ts tests/scheduler/planFile.test.ts && rtk npm run typecheck`

```bash
rtk git add src/control/planImport.ts src/control/executionSnapshot.ts src/scheduler/planFile.ts src/control/queries.ts src/control/snapshot.ts tests/control/planImport.test.ts tests/control/executionSnapshot.test.ts
rtk git commit -m "feat(control): import immutable web plans"
```

---

