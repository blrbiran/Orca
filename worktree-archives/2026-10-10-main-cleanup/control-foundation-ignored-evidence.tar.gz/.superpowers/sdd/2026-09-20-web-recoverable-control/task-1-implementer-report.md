# Task 1 implementer report

## Status

DONE

Commit: `8eeba0f feat(control): define web control protocol`

## Implementation

- Added `canonicalBytes(value)` and `sha256Canonical(value)` with RFC 8785 property ordering, UTF-8 output, safe-integer-only numbers, and rejection of negative zero, non-finite/fractional/unsafe numbers, lone surrogates, sparse/extended arrays, accessors, non-plain objects, unsupported values, and cycles.
- Added exact canonical UTC millisecond timestamp validation and the closed common command envelope.
- Kept the foundation `WorkKind` unchanged and introduced a separate `WebWorkKind` union.
- Added closed Zod schemas and inferred TypeScript exports for Web work kinds, trusted execution-profile snapshots, proof/dispatch/estimate records, immutable control plans and execution snapshots, estimator requests/results, command preimages, every mutation payload, read DTOs, error/success/lookup bodies, and their nested records.
- Added canonical sorted-set and duplicate rejection for IDs, hashes, amount dimensions, plans/tasks/dependencies, profile artifacts/secrets, read-model arrays, evidence, blockers, and command result sets. Arrays whose order is semantically significant (success conditions, assumptions, resume selections, and pending runs) preserve order while rejecting only the duplicates required by the spec.
- Added cross-field validation for explicit-null profile fields, context tokenizer capability, task output ceilings, exact-tokenizer artifacts, request-bound dimensions, dispatch profile slots, estimate output state, field provenance, and exact execution-snapshot allocation membership.
- Kept Codex represented in the test fixture as `usageObservation: "phase-end"` plus `budgetEnforcement: "soft"`; no strict Codex claim was introduced.

## TDD evidence

### Initial RED

Command:

```text
rtk npm test -- tests/control/canonicalJson.test.ts tests/control/webProtocol.test.ts
```

The first sandboxed invocation was blocked before discovery because Vitest could not create its temporary config bundle (`EPERM` in the assigned worktree). The identical command was rerun with worktree write permission and produced the intended RED:

```text
FAIL  tests/control/canonicalJson.test.ts
Error: Failed to load url ../../src/control/canonicalJson.js

FAIL  tests/control/webProtocol.test.ts
Error: Failed to load url ../../src/control/webProtocol.js

Test Files  2 failed (2)
Tests       no tests
```

### Self-review regression RED 1

Command:

```text
rtk npm test -- tests/control/webProtocol.test.ts
```

Relevant output after adding the omitted-payload assertion:

```text
FAIL  Web control protocol > keeps command envelopes closed
expected true to be false
Tests  1 failed | 7 passed (8)
```

This exposed Zod's treatment of a missing `z.unknown()` field. The payload field now uses a required custom validator and rejects both omission and `undefined`.

### Self-review regression RED 2

Command:

```text
rtk npm test -- tests/control/webProtocol.test.ts
```

Relevant output after adding the reserve-provenance assertion:

```text
FAIL  Web control protocol > validates a complete, canonically ordered execution snapshot
expected true to be false
Tests  1 failed | 7 passed (8)
```

The execution/read allocation schemas now require `system` provenance for reserve/estimate accounting and forbid it for editable task/goal-review fields.

### Final GREEN and typecheck

Exact command:

```text
rtk npm test -- tests/control/canonicalJson.test.ts tests/control/webProtocol.test.ts && rtk npm run typecheck
```

Relevant output:

```text
✓ tests/control/canonicalJson.test.ts (8 tests)
✓ tests/control/webProtocol.test.ts (8 tests)
Test Files  2 passed (2)
Tests       16 passed (16)
> tsc --noEmit -p tsconfig.json
```

Both commands exited 0.

## Files changed

- `src/control/canonicalJson.ts` (created)
- `src/control/webProtocol.ts` (created)
- `src/control/types.ts`
- `src/control/schema.ts`
- `tests/control/canonicalJson.test.ts` (created)
- `tests/control/webProtocol.test.ts` (created)

## Self-review

- `rtk git diff --cached --check` passed before commit.
- The reviewed index contained exactly the six planned Task 1 files.
- `rtk git show --check --stat --oneline HEAD` passed after commit.
- Verified that the legacy foundation `WorkKind` spelling and behavior remain unchanged.
- Verified that all protocol objects are `.strict()` and nullable authority fields must be present as explicit `null`.
- Verified canonical sorting uses JavaScript UTF-16 code-unit order, while canonical bytes are UTF-8.
- Verified the committed golden hash is the complete independently computed 64-hex SHA-256 literal.
- Verified the pre-existing `docs/handoff/handoff.md` modification and untracked `node_modules` remain unstaged and absent from the commit.

## Concerns

None. Duplicate raw JSON object keys must necessarily be rejected by the eventual raw HTTP JSON parsing boundary before values reach `canonicalBytes`; duplicate set members are rejected by the schemas added here.

## Fix round 1

Commit: `a11a296 fix(control): close web protocol invariants`

### Implementation

- Replaced the unrestricted authority-command payload record with verb-discriminated, closed raw and effective command unions. Group/task/global targets are coupled to their verbs; import and recovery targets are also checked against payload identity.
- Kept raw dynamic omissions observable while requiring all effective defaults: import profile ID/hash/mode, handoff deadline, proposal `proposedGroupLimit: null`, and every proposal operation's `estimateId: null` when it is not model-derived.
- Restricted Codex profile snapshots to the verified `usageObservation: "phase-end"` and `budgetEnforcement: "soft"` combination.
- Required estimate dispatch envelopes to carry an all-zero handoff grant, and required work/handoff envelopes to carry a positive claim ordinal.
- Required non-null proof attempt limits to equal one and non-null session limits to be zero or one.
- Added group-view allocation checks for task/estimate membership, canonical owner IDs, and valid owner/bucket pairings.
- Required browser command successes to have non-null command/projection revisions and shutdown success to have both values null.

### RED

Exact command:

```text
rtk npm test -- tests/control/webProtocol.test.ts
```

Relevant output:

```text
FAIL  Web control protocol > couples command verbs to closed raw payloads and explicit effective defaults
TypeError: Cannot read properties of undefined (reading 'parse')

FAIL  Web control protocol > accepts an explicit Codex phase-end plus soft profile snapshot
expected true to be false

FAIL  Web control protocol > enforces dispatch phase grants and proof attempt/session maxima
expected true to be false

FAIL  Web control protocol > enforces canonical group allocation ownership and command revision nullability
expected true to be false

Test Files  1 failed (1)
Tests       4 failed | 7 passed (11)
```

The four failures corresponded exactly to the four review findings: missing raw/effective command schemas and three groups of previously accepted invalid values.

### Focused GREEN

Exact command:

```text
rtk npm test -- tests/control/webProtocol.test.ts
```

Relevant output:

```text
✓ tests/control/webProtocol.test.ts (11 tests)
Test Files  1 passed (1)
Tests       11 passed (11)
```

### Required Task 1 verification

Exact command:

```text
rtk npm test -- tests/control/canonicalJson.test.ts tests/control/webProtocol.test.ts && rtk npm run typecheck
```

Relevant output:

```text
✓ tests/control/canonicalJson.test.ts (8 tests)
✓ tests/control/webProtocol.test.ts (11 tests)
Test Files  2 passed (2)
Tests       19 passed (19)
> tsc --noEmit -p tsconfig.json
```

Both commands exited 0.

### Files changed

- `src/control/webProtocol.ts`
- `tests/control/webProtocol.test.ts`

### Self-review

- Reviewed only the four requested Important findings; the separately ledgered Minor array-accessor issue was not changed.
- Verified the effective authority schema cannot accept omitted/null-unexpanded proposal defaults or path/command-bearing payload keys.
- Verified Codex remains phase-end plus soft; other adapters retain the closed capability vocabulary.
- Verified phase constraints are applied to canonical dispatch/proof preimages rather than only downstream runtime checks.
- Verified allocation membership and owner IDs are resolved against the enclosing group DTO.
- `rtk git diff --cached --check` passed, and the reviewed index contained exactly the two fix-round files.
- `rtk git show --check --stat --oneline HEAD` passed after commit.
- The pre-existing `docs/handoff/handoff.md` modification and untracked `node_modules` remained unstaged and absent from the commit.

### Concerns

None.

## Fix round 2

Commit: `21b989c fix(control): enforce command success revisions`

### Implementation

- Replaced the aggregate “both revisions are null” comparison with independent nullability checks for `commandRevision` and `projectionSeq`.
- Browser command successes now require each field to be non-null.
- Shutdown success now requires each field to be null.
- Added all four one-null regression permutations: command-null/projection-present and command-present/projection-null for both browser and shutdown results.

### RED

Exact command:

```text
rtk npm test -- tests/control/webProtocol.test.ts
```

Relevant output:

```text
FAIL  Web control protocol > enforces canonical group allocation ownership and command revision nullability
expected true to be false
tests/control/webProtocol.test.ts:434:98
Test Files  1 failed (1)
Tests       1 failed | 10 passed (11)
```

The failure was the browser `commandRevision: null` / non-null `projectionSeq` permutation identified by scoped re-review.

### GREEN and required Task 1 verification

Exact command:

```text
rtk npm test -- tests/control/canonicalJson.test.ts tests/control/webProtocol.test.ts && rtk npm run typecheck
```

Relevant output:

```text
✓ tests/control/canonicalJson.test.ts (8 tests)
✓ tests/control/webProtocol.test.ts (11 tests)
Test Files  2 passed (2)
Tests       19 passed (19)
> tsc --noEmit -p tsconfig.json
```

Both commands exited 0.

### Files changed

- `src/control/webProtocol.ts`
- `tests/control/webProtocol.test.ts`

### Self-review

- Confirmed each revision field is now checked independently; no one-null combination can pass for either browser or shutdown success.
- Kept the fix limited to the single scoped finding and did not address the separately ledgered Minor array-accessor issue.
- `rtk git diff --check` and `rtk git diff --cached --check` passed.
- The reviewed index contained exactly the two fix-round files.
- `rtk git show --check --stat --oneline HEAD` passed after commit.
- The pre-existing `docs/handoff/handoff.md` modification and untracked `node_modules` remained unstaged and absent from the commit.

### Concerns

None.
