### Task 5: Canonical read models and invalidation API

**Files:**
- Create: `src/panel/controlViews.ts`
- Create: `src/panel/controlApi.ts`
- Create: `src/panel/controlErrors.ts`
- Create: `tests/panel/controlReadApi.test.ts`
- Modify: `src/panel/api.ts`
- Modify: `tests/panel/security.test.ts`
- Modify: `tests/panel/webParity.test.ts`
- Create: `web/src/controlTypes.ts`

**Interfaces:**
- Consumes: Tasks 1–4 read records, profiles, versions, and existing Panel token middleware.
- Produces: authenticated `config`, `summary`, `groups`, full-group, command lookup, recovery, and evidence endpoints plus server/Web shape parity.

- [ ] **Step 1: Write failing real-HTTP read tests**

```ts
it("returns a complete reset after an epoch mismatch or retained-journal gap", async () => {
  const body = await authedGet<ControlSummaryV1>(panel, "/api/control/summary?sinceChangeSeq=0");
  expect(body).toMatchObject({ schema: "orca-control-summary-v1", resetRequired: true });
  expect(body.groups).toEqual([...body.groups].sort((a, b) => a.groupId.localeCompare(b.groupId)));
});
```

Cover canonical query spelling, malformed/negative/overflow `sinceChangeSeq`, full vs incremental summary, confirmed profile/snapshot reload, estimate output display, paused stop state, evidence manifest, exact typed errors, auth, and forged immediate-kill 404.

- [ ] **Step 2: Run focused tests and verify RED**

Run: `rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/security.test.ts tests/panel/webParity.test.ts`

Expected: FAIL because routes/views/types are absent.

- [ ] **Step 3: Implement closed views and read routes**

Register `/api/control/*` behind the existing token/Host protections. Build DTOs only from canonical store state, sort every set as specified, expose hashes/references rather than executable paths, and map errors through the V1 envelope without altering existing decision/review APIs.

- [ ] **Step 4: Verify GREEN, parity, and typecheck**

Run: `rtk npm test -- tests/panel/controlReadApi.test.ts tests/panel/security.test.ts tests/panel/webParity.test.ts && rtk npm run typecheck && rtk npm --workspace web run check`

Expected: all pass.

- [ ] **Step 5: Commit Task 5**

```bash
rtk git add src/panel/controlViews.ts src/panel/controlApi.ts src/panel/controlErrors.ts src/panel/api.ts web/src/controlTypes.ts tests/panel/controlReadApi.test.ts tests/panel/security.test.ts tests/panel/webParity.test.ts
rtk git commit -m "feat(panel): expose canonical control reads"
```

---

