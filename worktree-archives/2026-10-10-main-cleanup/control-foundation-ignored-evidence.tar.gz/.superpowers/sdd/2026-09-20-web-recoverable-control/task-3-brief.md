### Task 3: Trusted allowlists, profile routing, and admission gate

**Files:**
- Create: `src/control/profiles.ts`
- Create: `src/control/admissionGate.ts`
- Create: `src/panel/controlConfig.ts`
- Create: `tests/control/profiles.test.ts`
- Create: `tests/control/admissionGate.test.ts`
- Create: `tests/panel/controlConfig.test.ts`
- Modify: `src/control/executionPort.ts`
- Modify: `src/control/service.ts`

**Interfaces:**
- Consumes: Task 1 profile snapshot/hash schemas and existing `ExecutionPort` primitives.
- Produces: `ExecutionProfileRouter`, capability intersection/probe results, allowlisted repo/plan/profile resolution, and a shared admission gate/barrier used by claims, mutations, and shutdown.

- [ ] **Step 1: Write failing profile and gate tests**

```ts
it("changes profileHash when any resolved execution byte changes", () => {
  const a = resolveProfile(fixture({ adapterImplementationHash: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" }));
  const b = resolveProfile(fixture({ adapterImplementationHash: "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb" }));
  expect(a.profileHash).not.toBe(b.profileHash);
});

it("makes a claim either visible before shutdown or inadmissible after it", async () => {
  const release = gate.enter();
  const drain = gate.beginDrain();
  release();
  await drain.beforeWriterTransaction;
  expect(() => gate.enter()).toThrowError("panel-draining");
});
```

Cover capability order/intersection, proof descriptor equality, unknown context window, context tokenizer/output limits, stable-ID path resolution, symlink/path escape rejection, and no browser-supplied executable/path.

- [ ] **Step 2: Run focused tests and verify RED**

Run: `rtk npm test -- tests/control/profiles.test.ts tests/control/admissionGate.test.ts tests/panel/controlConfig.test.ts`

Expected: FAIL because router/gate/config modules are absent.

- [ ] **Step 3: Implement trusted configuration and router**

```ts
export interface ExecutionProfileRouter {
  resolve(workKind: WebWorkKind, profileId: string, expectedHash: string): FrozenProfile;
  probe(profile: FrozenProfile): Promise<ObservedProfile>;
}
export interface AdmissionGate {
  enter(): () => void;
  beginDrain(): { beforeWriterTransaction: Promise<void> };
  readonly draining: boolean;
}
```

Hash the complete closed resolved profile; expose only safe display fields. Capability failure always degrades to unavailable. Keep `ControlService` execution primitives, and introduce profile-selected calls without embedding HTTP semantics in it.

- [ ] **Step 4: Verify GREEN and foundation port regressions**

Run: `rtk npm test -- tests/control/profiles.test.ts tests/control/admissionGate.test.ts tests/panel/controlConfig.test.ts tests/control/ccloopPort.test.ts tests/control/dispatch.test.ts && rtk npm run typecheck`

Expected: all pass.

- [ ] **Step 5: Commit Task 3**

```bash
rtk git add src/control/profiles.ts src/control/admissionGate.ts src/panel/controlConfig.ts src/control/executionPort.ts src/control/service.ts tests/control/profiles.test.ts tests/control/admissionGate.test.ts tests/panel/controlConfig.test.ts
rtk git commit -m "feat(control): route trusted execution profiles"
```

---

