### Task 1: Canonical protocol values and closed schemas

**Files:**
- Create: `src/control/canonicalJson.ts`
- Create: `src/control/webProtocol.ts`
- Create: `tests/control/canonicalJson.test.ts`
- Create: `tests/control/webProtocol.test.ts`
- Modify: `src/control/types.ts`
- Modify: `src/control/schema.ts`

**Interfaces:**
- Consumes: existing `Amount`, `ControlError`, Zod validation patterns.
- Produces: `canonicalBytes(value)`, `sha256Canonical(value)`, `canonicalTimestampSchema`, `ControlPlanV1`, `ExecutionProfileSnapshotV1`, `ExecutionSnapshotV1`, command envelopes/results, read DTOs, and mutation payload schemas used by every later task.

- [ ] **Step 1: Write canonicalization golden-vector tests**

```ts
it("hashes safe-integer RFC 8785 values and rejects ambiguous JSON", () => {
  expect(canonicalBytes({ z: 1, a: "x" }).toString("utf8")).toBe('{"a":"x","z":1}');
  expect(sha256Canonical({ z: 1, a: "x" })).toBe("8d6a75ac86d8b51bb56acfbb96108ed81474aa3504c317f77c0c576bde387cd3");
  for (const bad of [-0, 1.5, Number.MAX_SAFE_INTEGER + 1, Number.NaN]) {
    expect(() => canonicalBytes({ bad })).toThrowError("control-non-canonical-json");
  }
});
```

Use a complete independently computed 64-hex literal in the committed test, plus vectors for UTF-16 property ordering, explicit nulls, duplicate-set rejection, and canonical UTC milliseconds.

- [ ] **Step 2: Run the focused tests and verify RED**

Run: `rtk npm test -- tests/control/canonicalJson.test.ts tests/control/webProtocol.test.ts`

Expected: FAIL because both modules are absent.

- [ ] **Step 3: Implement the canonical boundary and closed schemas**

```ts
export function canonicalBytes(value: unknown): Buffer;
export function sha256Canonical(value: unknown): string;
export const canonicalTimestampSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
export const commandEnvelopeSchema = z.object({
  commandId: idSchema,
  expectedRevision: safeInteger,
  payload: z.unknown(),
}).strict();
```

Implement the exact schemas and sorted-set rules from spec §§3.1–4.1 and §5.4. Keep legacy foundation `WorkKind` separate from the Web V1 union so existing callers do not change behavior.

- [ ] **Step 4: Verify focused GREEN and typecheck**

Run: `rtk npm test -- tests/control/canonicalJson.test.ts tests/control/webProtocol.test.ts && rtk npm run typecheck`

Expected: all focused tests pass; typecheck exits 0.

- [ ] **Step 5: Commit Task 1**

```bash
rtk git add src/control/canonicalJson.ts src/control/webProtocol.ts src/control/types.ts src/control/schema.ts tests/control/canonicalJson.test.ts tests/control/webProtocol.test.ts
rtk git commit -m "feat(control): define web control protocol"
```

---

