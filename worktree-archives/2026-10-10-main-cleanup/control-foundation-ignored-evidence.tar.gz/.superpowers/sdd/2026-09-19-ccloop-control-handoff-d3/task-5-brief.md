## Task 5: validated dirty-snapshot materialization for a new ccloop run

**Files:** Create in ccloop `src/control/materialize.ts`, `tests/control/materialize.test.ts`. Modify `src/workspace/worktreeManager.ts`, `src/controller/runLoop.ts`, `src/control/worker.ts`. Create in Orca `src/control/resumeBundle.ts`, `tests/control/resumeBundle.test.ts`; modify Orca `src/control/snapshot.ts` to export its validated `SnapshotV1` schema/type rather than duplicating the archive format.

**Interfaces:** Orca `exportResumeBundle(store,{predecessorRunId,newSourceDir}): Promise<InputCheckpointV1>`; ccloop `materializeFirstWorkspace(repoPath,runDir,attempt,input): Promise<{worktreePath:string}>`.

The artifact format consumed by ccloop is fixed rather than inferred:

```ts
export interface SnapshotV1 {
  version: 1;
  head: string;
  bundle: ArtifactRef;
  index: Array<{path:string;mode:string;oid:string;stage:number;ref:ArtifactRef|null}>;
  tree: Array<{path:string;kind:"file"|"directory"|"symlink";mode:number;ref?:ArtifactRef;target?:string}>;
  deleted: string[];
  missing: string[];
}
```

- [ ] **Step 1: Add Orca failing export tests.** Export only a committed, recoverable checkpoint whose snapshot and all nested refs re-read successfully. Manifest files are regular 0600 files under `{newSourceDir}/input/{checkpointId}/`; export refuses partial snapshot, bad hash, missing artifact, unsettled predecessor and destination symlink.
- [ ] **Step 2: Add ccloop failing materialization tests.** Build a snapshot with staged, unstaged, untracked, deleted, binary, executable, symlink and index stages 1/2/3. The first continuation attempt must reproduce Git HEAD, index bytes, worktree bytes, modes and symlink targets; `git status --porcelain=v2` must match the source fixture after path normalization.
- [ ] **Step 3: Add hostile bundle tests.** Reject `../` and absolute file names, duplicate artifactId with conflicting hash, missing blob, extra unmanifested input, symlink/FIFO artifact, bad checkpointHash, wrong predecessor and source snapshot changing during read.
- [ ] **Step 4: Run the two files in their respective repositories and confirm RED.**
- [ ] **Step 5: Implement Orca export as copy-and-verify, not path lending.** Read bytes through `readArtifact`, create a manifest containing every recursively referenced snapshot/checkpoint artifact, fsync files and directory, then re-read the exported directory and hash every file before returning `InputCheckpointV1`.
- [ ] **Step 6: Implement ccloop materialization.** Validate all bytes first; fetch the bundle's objects into the target repo without moving its branch; create the new run's attempt-1 worktree at snapshot HEAD; reconstruct index stages with `git update-index --index-info`; reconstruct tree entries without following symlinks; verify the completed worktree again before the adapter is constructed.
- [ ] **Step 7: Inject structured continuation context.** Write immutable `continuation-input.json` in the new run and append its absolute path to a copied contract's `context.relevantDocs`; append one exact constraint requiring the planner to treat `unfinished`, `pendingDecisions` and `awaitingHuman` as inputs. Do not mutate the predecessor contract or reset its run state.
- [ ] **Step 8: Green-run and mutations H17 (skip nested artifact hash), H18 (normalize `..` instead of reject), H19 (drop index stages), H20 (create attempt from target HEAD rather than snapshot), H21 (omit structured continuation input).**
- [ ] **Step 9: Commit ccloop and Orca Task 5 files separately with `feat(control): materialize committed continuation snapshots` and `feat(control): export immutable continuation bundles`.**

