## Task 4: named handoff, deadline stop, final candidate, and quiet proof

**Files:** Create in ccloop `src/control/{handoff,stopProof}.ts`, `tests/control/{handoff,stopProof}.test.ts`, `tests/fixtures/process-tree.mjs`. Modify `src/controller/runLoop.ts` to distinguish an external handoff abort from timeout; extend `src/control/{worker,collect,command}.ts`.

**Interfaces:** `requestHandoff(envelope,request): Promise<HandoffAckV1>`; `buildHandoffPacket(...)`; `proveStopped(record): Promise<StopProof|null>`.

```ts
export interface HandoffPacketV1 {
  protocol: 1;
  identity: Identity;
  request: HandoffRequestV1 | null; // null only for a natural terminal run
  runState: RunState;
  completed: string[];
  unfinished: string[];
  pendingDecisions: string[];
  awaitingHuman: string[];
  validationCommands: string[];
  rawLogs: ArtifactRef[];
  usageHighWater: number;
  unresolvedRequestIds: string[];
  artifacts: ArtifactRef[];
}
```

- [ ] **Step 1: Write failing request tests.** Same `requestId`/payload is idempotent; changed reason/deadline conflicts; wrong run/generation refuses; request is fsynced before ack; once latched, no new attempt or phase begins.
- [ ] **Step 2: Write a phase/deadline test.** A cooperative request waits for the next phase boundary and spends no new attempt. At deadline the active adapter abort signal fires, Codex phase kills its registered process group, and the packet is `partial` if a complete narrative cannot be built.
- [ ] **Step 3: Write real process-tree tests.** The fixture forks a child and late grandchild in the registered pgid. PID leader exit alone must keep `stopProof:null`; proof appears only after worker seal exists, owner/lease is released, every registered `(pgid,startedAt)` is probed quiet, and a second probe after the grace interval is also quiet. Unknown `ps`/kill permission also yields null.
- [ ] **Step 4: Write packet tests.** Packet derives facts from contract, run state, attempt artifacts and events; no LLM call. Blocked state supplies awaitingHuman/decision text, validation commands and raw log refs are explicit, missing artifacts are listed, and both `complete/partial/failed` result paths retain raw refs. A natural terminal run also emits a packet with `request:null`, so D3 never has to guess facts from generic artifact names.
- [ ] **Step 5: Run both files and confirm RED.**
- [ ] **Step 6: Implement a watcher inside the worker.** It reads the immutable request record, sets the boundary stop slot immediately, and arms a deadline abort. External abort is persisted as handoff interruption, not misclassified as phase timeout, budget exhaustion or success.
- [ ] **Step 7: Finalize in order:** stop new phases → settle/abort current phase → write final usage event for work → build and fsync packet/candidate → write explicit handoff cumulative observation, including zero → seal worker → release ccloop owner/lease → let a later inspect/collect produce stop proof. Extend the wire `Candidate` with required `handoff:ArtifactRef`, pointing to the packet; do not write `isolated:true` from inside the still-running worker.
- [ ] **Step 8: Green-run and mutations H12 (ack before request fsync), H13 (ignore generation), H14 (treat leader exit as quiet), H15 (omit second quiet probe), H16 (map deadline to successful complete).**
- [ ] **Step 9: Commit Task 4 as `feat(control): persist handoff and prove execution quiet`.**

