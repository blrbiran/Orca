# Task 6 execution brief

- Implement only the Orca production ccloop port, handoff transaction, and continuation inheritance from the approved plan.
- Production remains explicit: no ambient PATH/config fallback; `productionExecutionPort()` continues to reject without options.
- Handoff intent is durable before RPC. Evidence, usage, Orca snapshot, stop proof, checkpoint commit, and projections precede reserve release.
- Continuation creates a new generation-1 run and reserves exactly predecessor grant minus cumulative usage without changing historical group usage.
- Export and verify the immutable resume bundle before start dispatch. Preserve source ownership on every failure.
- Codex remains soft-budget only. No merge, push, cleanup, or real `~/.orca` writes.

