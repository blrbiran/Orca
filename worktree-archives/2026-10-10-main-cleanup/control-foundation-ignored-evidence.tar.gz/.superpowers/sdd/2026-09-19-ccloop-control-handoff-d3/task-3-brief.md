## Task 3: supervised Codex execution, ordered usage evidence, and collection

**Files:** Create in ccloop `src/control/{worker,usage,evidence,collect}.ts`, `tests/control/{worker,usage,collect}.test.ts`. Modify `src/controller/runLoop.ts`, `src/runtime/types.ts`, `src/runtime/codex/runCodexPhase.ts` only to add optional observation/registration hooks; legacy callers omit them. Extend `src/control/command.ts` for `collect` and `read-evidence`.

**Interfaces:**

```ts
export interface RunControlHooks {
  stopRequested?: StopRequestSignal;
  phaseSignal?: AbortSignal;
  onPhaseSettled?: (observation: {
    phase:"plan"|"execute"|"verify";
    attempt:number;
    elapsedMs:number;
    tokenUsage:number|null;
    usageEvidence:UsageEvidence|undefined;
  }) => Promise<void>;
  onProcessRegistered?: (process:{pid:number;pgid:number;startedAt:string;phase:string}) => Promise<void>;
}
```

`runLoop(contract,runDir,adapter,hooks?)` passes hooks into `runLoopFromState`; no hook changes existing decisions. `appendUsageObservation(...)` emits run-global consecutive `eventSeq` and per-bucket cumulative `Amount|null`. `collectExecution(envelope,afterSeq)` returns only events with `eventSeq>afterSeq`, plus current candidate/terminal.

- [ ] **Step 1: Write failing hook tests around every `applyPhaseUsage` call site.** Success, timeout, abort, adapter throw and missing usage must each call the observer once for the phase actually entered. The hook receives raw `tokenUsage:null` when absent; it must not receive the internal budget snapshot's synthetic zero.
- [ ] **Step 2: Write failing usage tests.** Feed Codex thread-total observations `15,35,60`; expect cumulative work tokens `15,35,60`, not `15,50,110`. Duplicate evidence produces the same event, conflicting evidence at the same seq refuses, an absent usage emits `cumulative:null`, and an explicit final zero remains an `Amount` rather than null.
- [ ] **Step 3: Write collection/evidence tests.** `afterSeq` filters without renumbering; evidence content hash is rechecked on each read; traversal, symlink, FIFO and >16 MiB control response refuse. Diagnostics never enter JSON stdout.
- [ ] **Step 4: Run the three files and confirm RED.**
- [ ] **Step 5: Implement hooks surgically.** Keep ccloop's existing soft `RunState.budgetSnapshot` behavior for legacy compatibility, but build protocol usage only from raw observations. Register each Codex detached phase group before writing stdin; observation write failure aborts the phase and preserves its raw evidence.
- [ ] **Step 6: Emit session/attempt/time consistently.** Work cumulative has `sessions:1` after the worker begins, `attempts` equal to attempts actually entered, and saturating is forbidden—overflow is a named protocol error. Mechanical handoff consumption is written later to the handoff bucket.
- [ ] **Step 7: Green-run and mutations H08 (replace null usage with zero), H09 (sum thread totals as deltas), H10 (skip process registration), H11 (renumber afterSeq results).**
- [ ] **Step 8: Commit Task 3 as `feat(control): supervise runs and publish ordered usage`.**

