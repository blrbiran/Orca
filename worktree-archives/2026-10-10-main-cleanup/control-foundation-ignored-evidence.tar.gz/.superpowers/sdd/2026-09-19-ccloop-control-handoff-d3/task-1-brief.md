## Task 1: ccloop public schemas, CLI boundary, and private control layout

**Files:** Create in ccloop `src/control/{protocol,paths,command}.ts`, `tests/control/{protocol,command}.test.ts`, `docs/control-protocol-v1.md`. Modify `src/cli.ts` only to dispatch the new command before legacy flag parsing.

**Interfaces:** `parseControlRequest(method,raw): ControlRequestV1`; `runControlCommand(argv,stdin,deps?): Promise<{code:number;stdout:string;stderr:string}>`; `controlRoot(envelope): string` returns `{sourceDir}/control`; `canonicalHash(value): string` recursively sorts object keys and preserves array order.

- [ ] **Step 1: Add failing strict-schema tests.** Cover unknown keys, unsafe integers, invalid hash/ID, relative adapter config, non-absolute or symlinked sourceDir, input bundle outside `{sourceDir}/input`, and a positive round trip for every method.

```ts
const envelope = startEnvelopeFixture();
expect(parseControlRequest("accept", envelope)).toEqual(envelope);
expect(() => parseControlRequest("accept", {...envelope, protocol: 2})).toThrow("control-protocol-unsupported");
expect(() => parseControlRequest("accept", {...envelope, extra: true})).toThrow("control-request-invalid");
```

- [ ] **Step 2: Run `rtk proxy npx vitest run tests/control/protocol.test.ts tests/control/command.test.ts`; save log/rc and confirm RED because modules do not exist.**
- [ ] **Step 3: Implement the exact wire schemas above and CLI dispatch.** `main()` must route `argv[0]==="control"` before the legacy `run/resume/sweep` parser. stdout is written only after the handler returns a schema-valid value; caught protocol errors map to exit 2, all other errors to 1.
- [ ] **Step 4: Implement private paths.** Create sourceDir/control and children with 0700, files with 0600, `O_NOFOLLOW` on reads, atomic temp+fsync+rename+directory fsync on replacement. Reject symlink ancestors and any path whose `realpath` escapes sourceDir. Never chmod existing user paths.
- [ ] **Step 5: Green-run the two test files, then deletion mutations H01 (remove `.strict()`), H02 (allow bundle escape), H03 (print diagnostics to stdout). Each must fail a behavior assertion.**
- [ ] **Step 6: Document every request/response, exit code, durability boundary and declared Codex capability in `docs/control-protocol-v1.md`; do not claim handoff/restore complete until Tasks 4–5 pass.**
- [ ] **Step 7: Commit only Task 1 ccloop files with `feat(control): define versioned public control protocol`.**

