## Task 2: durable accepted identity and fail-closed worker launch

**Files:** Create in ccloop `src/control/{store,accept,workerLauncher}.ts`, `tests/control/{accept,workerLaunch}.test.ts`, `tests/fixtures/control-worker.mjs`. Extend `src/control/command.ts` for `accept` and `inspect`.

**Interfaces:** `acceptStart(input,adapterBinding): Promise<ExecutionStatusV1>`; `inspectStart(input): Promise<ExecutionStatusV1>`; `readAccepted(sourceDir): Promise<AcceptedRecordV1>`; `launchWorker(record,deps?): Promise<void>`.

```ts
export interface AcceptedRecordV1 {
  protocol: 1;
  envelopeHash: string;
  executionId: string;
  configHash: string;
  generation: number;
  acceptedAt: string;
  launch: "intended" | "claimed" | "sealed" | "unknown";
  worker: {pid:number;startedAt:string;nonce:string} | null;
}
```

- [ ] **Step 1: Write failing real-process tests.** The fixture increments an agent-launch file only after exclusively claiming the accepted record. Test: same accept twice launches once; same identity/different payload returns `control-envelope-conflict`; response drop after worker claim is recovered by inspect; crash after `launch:"intended"` but before a worker receipt returns unknown and never spawns a replacement.
- [ ] **Step 2: Add PID-reuse and config drift cases.** A live PID with mismatched UTC start identity is not the worker; changed adapter-config bytes after accepted do not alter the stored canonical config, and a request whose `claim.configHash` differs refuses before worker creation.
- [ ] **Step 3: Run the two files and confirm RED.**
- [ ] **Step 4: Persist accepted before spawn.** Copy the validated adapter config into `control/config.json`, fsync it, write `accepted.json` with `launch:"intended"`, then spawn a detached worker with only absolute paths, executionId and random nonce. The worker must atomically claim the same record before constructing any adapter.
- [ ] **Step 5: Make ambiguous launch fail closed.** If the launcher dies after spawn is attempted but before a matching worker receipt, write/retain `launch:"unknown"`; inspect reports unknown and does not call spawn. A human/recovery design is required before that execution can be superseded; this plan does not guess from a timeout.
- [ ] **Step 6: Green-run, then mutations H04 (spawn before accepted fsync), H05 (ignore envelope hash on replay), H06 (treat intended/unknown as absent), H07 (compare PID without start identity).**
- [ ] **Step 7: Commit Task 2 as `feat(control): persist accepted execution identity`.**

