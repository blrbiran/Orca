## Task 3: 统一领取与真实消耗结算

**Files:** Create `src/control/{budget,usage}.ts`; `tests/control/budget.test.ts`, `tests/control/usage.test.ts`。

**Interfaces:** `claimWork(store,input:ClaimInput):Claim`；`recordUsage(store,event:UsageEvent):{applied:boolean;highWater:number}`；`releaseRunReserve(store,runId,proof:StopProof):void` 仅供 Task 6 事务内调用。`assertCapabilities(mode,capabilities):void` 放 `budget.ts`，固定错误码。

- [ ] **Step 1: 用真实 store 构造 g1（100）、review reserve 10、T1 work 60+handoff 10、T2 work 25+handoff 5；领取 T1 后 T2 拒绝。** 另进程争抢同 workItem 仅一方成功（M02），同 command 重投返回同 runId。

```ts
const c1 = claimWork(store, t1Claim);
expect(getGroup(store,"g1").reserved.tokens).toBe(80);
expect(() => claimWork(store,t2Claim)).toThrow("group-budget-unavailable");
recordUsage(store,{runId:c1.runId,generation:c1.generation,eventSeq:1,bucket:"work",
  cumulative:{tokens:40,activeMs:20,attempts:1,sessions:1},source:usageRef});
expect(getGroup(store,"g1").used.tokens).toBe(40);
expect(getGroup(store,"g1").reserved.tokens).toBe(40);
```

测试内 t1Claim/t2Claim 是填满公共类型的字面量；usageRef 来自临时文件 hash（Task 5 之后接真实归档），不使用无来源零。用 helper `seedBudgetCase(store)` 返回 `{t1Claim,t2Claim,usageRef}`，定义在 `tests/control/fixtures/store.ts` 并完整创建上述组与两项工作。

补判据表，使用 `it.each`，不得只测一类工作：

| 输入／动作 | 断言 |
|---|---|
| task/decompose/reconcile/goal-review/memory 停组后领取 | 全部拒绝且 executor 调用数 0 |
| 预留交接的 active run 收 handoff usage | 停组仍结算；不能另造无关联 handoff run |
| strict+realtime+soft；strict+bounded 无 bound evidence | capability 拒绝，reserved 不变 |
| soft work 实耗 120 > grant 60 | used=120，work reserve=0，breach 留痕；handoff/review reserve 不偷用；后续领取拒绝 |
| seq1 重复相同／重复改内容 | 分别 no-op／usage-event-conflict |
| seq3 先于 seq2 | 存 pending，highWater 停在1，结算不跳过缺口；seq2 到后按序重放 |
| bucket cumulative 从40降30 | usage-regression，仍保留40和预留 |
| null／坏 usage | 待核对，预留不释放；显式0+原始证据才是0 |
| 两个 run 各 activeMs=60000 | 总实耗120000，不按墙钟60000算 |
| 同 attempt handoff | attempts 不增加；确需新会话先预留 sessions |
| 工作额度不足但 handoff 尚足 | 不转移 handoff 给 work |

- [ ] **Step 2: 分别 RED 跑 budget/usage。**
- [ ] **Step 3: 同一个 BEGIN IMMEDIATE 内校验所有权、组停止、依赖、版本、能力、分量预算、deadline，再写 run 与 reservation。** claim 生成不可复用随机 runId；同 command 返回已存值。记录 ledger 保留 per-run grant、两桶 cumulative、remainingReserve、reviewReserve、budgetVersion；组 used/reserved 是这些项的事务聚合。

```ts
const delta = subtract(nextCumulative, previousCumulative);
const released = componentMin(delta, bucketRemainingReserve);
group.used = add(group.used, delta);
group.reserved = subtract(group.reserved, released);
bucketRemainingReserve = subtract(bucketRemainingReserve, released);
```

`add/subtract/componentMin` 在 budget.ts 定义并逐分量检查 safe integer；负 delta 拒绝。超额不裁 used；如果用量突破 strict 声明也保存 breach、锁存停止，而不是回滚事实。group-review 从已有复核 reserve **转账**到 run，不重复增加 reserved；无可用复核余额保持 review。handoff workItem 必须 parentRunId，借用父 run 的 handoff 桶；该引用扩展 WorkInput 为 discriminated union，其他 kind 禁止 parentRunId。

每次记录事件时核对 generation，拒旧写；恢复时接收旧 run 原身份的最终证据走 recovery 专用核对，不能把新 generation 写进旧事件。attempt/session 使用累计计数而非每条事件+1，防重投虚扣。handoff workItem 是父run下独立归因项，claimWork 对它返回父run身份、绑定其hand-off桶，不创建第二个并发执行；因此预算索引按run+bucket，同时保存该桶的workItemId。若交接确需独立执行会话由后续ccloop协议落实，不能在此调用旧runner冒充。

- [ ] **Step 4: GREEN；M07 删停止检查、M08 删预算分量检查、M09 unknown 改0并释放、M10 去掉 eventSeq 去重、M11 去掉累计单调检查、M12 取消分桶、M13 group review reserve 二次预留。每个变异必须由行为断言打红。**
- [ ] **Step 5: 提交 `feat(control): claim all work against one budget ledger`。**

