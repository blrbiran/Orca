## Task 1: 私有 stateDir 与可回滚的 SQLite 存储

**Files:** Create `src/control/{types,schema,errors,paths,store,migrations}.ts`; `tests/control/store.test.ts`; `tests/control/fixtures/store.ts`. Modify `.gitignore`。

**Interfaces:** `openControlStore({stateDir: string, recovery?: boolean}): Promise<ControlStore>`；`ControlStore` 暴露 `db: DatabaseSync`、同步 `transaction<T>(fn:()=>T):T`、`close():void`。所有后续数据函数接受该实例；事务回调禁止 Promise。测试 fixture `openTestStore(): Promise<{store:ControlStore;root:string;dispose():Promise<void>}>` 只创建临时根并注册清理。

- [ ] **Step 1: 写持久化／回滚／路径隔离判据。** 每条测试 `try/finally` 调 dispose；另进程测试使用退出码和真实 DB，不 mock transaction。

```ts
const h = await openTestStore();
try {
  expect(() => h.store.transaction(() => {
    h.store.db.prepare("INSERT INTO meta(key,value) VALUES (?,?)").run("probe", "one");
    throw new Error("abort");
  })).toThrow("abort");
  expect(h.store.db.prepare("SELECT value FROM meta WHERE key=?").get("probe")).toBeUndefined();
  expect((await stat(h.root)).mode & 0o777).toBe(0o700);
} finally { await h.dispose(); }
```

补文件 0600、已有模式不改、stateDir 指向 symlink 拒绝、坏 schemaVersion 不修改、第二 writer 被拒（并有第一 writer 正向成功）、崩溃 rollback 后重开无半行。

- [ ] **Step 2: `rtk proxy npx vitest run tests/control/store.test.ts`，确认未实现红；完整日志留存。**
- [ ] **Step 3: 建表和事务。** 初版 schema v1 用以下表；JSON 列保存经 schema 校验的对象，账本运算仍取事务内最新记录，不依赖内存 cache。

```sql
CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT;
CREATE TABLE groups(id TEXT PRIMARY KEY, revision INTEGER NOT NULL, graph_version INTEGER NOT NULL, body TEXT NOT NULL) STRICT;
CREATE TABLE work_items(group_id TEXT NOT NULL REFERENCES groups(id), id TEXT NOT NULL, target_version INTEGER NOT NULL, body TEXT NOT NULL, PRIMARY KEY(group_id,id)) STRICT;
CREATE TABLE commands(group_id TEXT NOT NULL, id TEXT NOT NULL, payload_hash TEXT NOT NULL, result TEXT NOT NULL, PRIMARY KEY(group_id,id)) STRICT;
CREATE TABLE runs(id TEXT PRIMARY KEY, group_id TEXT NOT NULL REFERENCES groups(id), work_item_id TEXT NOT NULL, generation INTEGER NOT NULL, active INTEGER NOT NULL CHECK(active IN (0,1)), body TEXT NOT NULL) STRICT;
CREATE UNIQUE INDEX one_active_work ON runs(group_id,work_item_id) WHERE active=1;
CREATE TABLE usage_events(run_id TEXT NOT NULL REFERENCES runs(id), seq INTEGER NOT NULL, payload_hash TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(run_id,seq)) STRICT;
CREATE TABLE artifacts(id TEXT PRIMARY KEY, hash TEXT NOT NULL, body TEXT NOT NULL) STRICT;
CREATE TABLE checkpoints(id TEXT PRIMARY KEY, run_id TEXT NOT NULL REFERENCES runs(id), hash TEXT NOT NULL, body TEXT NOT NULL) STRICT;
CREATE TABLE outbox(id TEXT PRIMARY KEY, kind TEXT NOT NULL, body TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0) STRICT;
```

用专属 service lock（mkdir + 随机 owner nonce + PID/start identity）限制单写；第二普通 writer 不通过删除 stale lock 夺权。`recovery:true` 只有确认原**服务进程**身份已消失、host/path 一致后，才能在单独 recovery-lock 下重读 nonce、隔离旧 service-lock 记录并取得新的服务锁；PID 检测不明、活进程或 nonce 改变均拒绝。此时全局 dispatchBlocked=true，只允许核对与记证据；ccloop run 的 active/owner/预留保持不动。Task8 核对各执行停止/隔离后逐项恢复派发资格，租约超时本身不是 takeover 证据。DB 先以 `open('wx',0600)` 预建再打开；初版用 `journal_mode=DELETE`，SQLite journal 位于0700目录并核对0600；`foreign_keys=ON`、`synchronous=FULL`、`busy_timeout=5000`。事务 `BEGIN IMMEDIATE/COMMIT/ROLLBACK`，finally 不能吞原错误。Node 版本检查先于动态 import，错误名 `control-node-unsupported`。

- [ ] **Step 4: 绿跑并删变异 M01（删 ROLLBACK）、M02（删 one_active_work）、M03（绕 stateDir symlink 检查）。M02 在 Task 3 领取判据补跑。**
- [ ] **Step 5: 提交本 Task 明确文件，主题 `feat(control): persist private versioned control state`。**

