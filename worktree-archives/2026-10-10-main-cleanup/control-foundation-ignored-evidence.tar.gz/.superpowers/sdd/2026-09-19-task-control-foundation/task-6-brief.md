## Task 6: 一致提交、投影重建与可重试清理

**Files:** Create `src/control/{checkpoints,projection,cleanup}.ts`; `tests/control/checkpoints.test.ts`, `tests/control/cleanup.test.ts`。

**Interfaces:** `commitCandidate(store,candidate:Candidate):Promise<{checkpointId:string;hash:string}>`；`publishPending(store,deps?:{writeProjection:(path:string,bytes:Buffer)=>Promise<void>}):Promise<void>`；`cleanupCommittedRun(store,runId:string,sourceDir:string):Promise<{removed:boolean}>`；`readCommittedCheckpoint(store,runId):Promise<Candidate>`。不得使用单个布尔 `isSafe` 绕全部前提。

- [ ] **Step 1: 写故障边界测试（真实 files+DB，每个 crash 重开 store）。** 测试 helper `makeCandidate(store,claim,result):Promise<Candidate>` 由 Task 5 的真实临时源、archiveRun、已记录 usage 构造，不能凭空 hash。故障钩子仅经依赖注入：`afterArchive/afterTransaction/beforeProjection/beforeCleanup`，生产无环境变量后门。

```ts
const committed = await commitCandidate(store,candidate);
const beforePublish = getGroup(store,candidate.groupId);
await expect(publishPending(store,{writeProjection:async () => {
  throw new Error("projection-write-failed");
}})).rejects.toThrow("projection-write-failed");
expect((await readCommittedCheckpoint(store,candidate.runId)).checkpointId).toBe(committed.checkpointId);
expect(getGroup(store,candidate.groupId).used).toEqual(beforePublish.used);
await publishPending(store);
expect(getGroup(store,candidate.groupId).used).toEqual(beforePublish.used);
```

注入只替换投影写入函数，不另开 writer，默认使用生产 fs 实现。`beforePublish` 在结算完成后读取，判据测实际调用前后不重复结算。

必须测试：仅候选无DB引用不可恢复；DB引用坏 hash 阻塞；usage 高水位有 gap、未结算请求、无 stop proof 时不释放余额；完整归档但验收未过不可 done；投影失败重建不退账；清理失败任务不重新执行；多 checkpoint 不覆盖前一份；late candidate 不覆盖新版本。

- [ ] **Step 2: RED checkpoints/cleanup。**
- [ ] **Step 3: 按 §13.4 固定顺序实现。**

```ts
await verifyCandidateArtifacts(store, candidate);
const reference = await persistImmutableCheckpoint(store, candidate);
store.transaction(() => {
  assertCurrentIdentity(store, candidate);
  assertUsageThrough(store, candidate.runId, candidate.usageHighWater);
  recordCheckpointReference(store, candidate, reference);
  enqueueProjection(store, candidate, reference);
  if (candidate.stopProof && candidate.unresolvedRequestIds.length === 0) {
    releaseRunReserve(store, candidate.runId, candidate.stopProof);
  }
});
await publishPending(store);
```

这些内部 helper 均在 checkpoints.ts 定义，消费者只依赖公开接口。`verifyCandidateArtifacts` 独立重验文件内容及 manifest；`persistImmutableCheckpoint` 用独占创建、fsync、父目录fsync；transaction 同时保存 evidence、run 结果、workItem 引用、budgetVersion、projection outbox。usage 只通过 Task3 唯一路径结算；候选不携带可覆盖 used 的任意数值。

无停止确认时可提交 partial **证据**，但 active 与预留不释放、recoverable=false；只有 complete+快照完整+停止确认+预算高水位结算+无 pending 请求才 recoverable。task done 还须原 required checks/landing 证据，不能据 ccloop succeeded；组无 goal-review 成功永远 review。

投影 outbox id 固定 checkpointId，latest 只允许版本单调前进；checkpoint 投影失败不覆盖运行完成事实。Task/组 handoff 文本生成属于 D3，本计划只发布 JSON 读模型和事件。

清理在 transaction committed **且从归档重验通过**、停止明确后才允许；只删注册 sourceDir，验证 realpath 位于记录的 runsRoot 下且 basename==runId、不是 root／symlink、无复用身份。失败记 cleanup_pending，重复清理不再次执行。没有授权 token 的直接 `disposeWorkdir` 不进入 controlled 路径。仍被任务/组引用的归档本版不自动删除。

- [ ] **Step 4: GREEN；M25 先写 latest 后事务、M26 仅 candidate 即恢复、M27 无 proof 释放、M28 删除前不读归档、M29 清理失败重新派发、M30 跳 hash 验证、M31 late projection 覆盖新引用。**
- [ ] **Step 5: 提交 `feat(control): commit checkpoints before publishing and cleanup`。**

