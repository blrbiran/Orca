# SDD ledger — plan: docs/superpowers/plans/2026-09-19-task-control-foundation.md

Owner: Codex task 01a0b836; 2026-09-19; base b5863d37d75f330298124632011cff1e4b1f717d.
Execution: Native, user approved. No real models, integration, push or deletion.
Ruling: retain SDD evidence and read every verification log in full — explicit user/repository rules override skill cleanup/tail instructions — cost: retained disk space.
Pre-flight: 1→2/3/4/5/6/8 store transaction and private paths match; schema additions use JSON records.
Pre-flight: 2→3 group revisions are configuration revisions; usage uses budgetVersion, matching plan.
Pre-flight: 3→4/6 claim identity and per-bucket reserve match; release only within checkpoint transaction.
Pre-flight: 4→7/8 durable envelope/inspect identity match; production capability refusal stays mandatory.
Pre-flight: 5→6/8 artifact IDs/hashes are immutable; source removal cannot affect readback.
Pre-flight: 6→7/8 commit and disposal require archived evidence; scheduler landing needs persisted intent before mutation.
Pre-flight: 7→8 shared orchestration and recovery must preserve legacy behavior.
Task 1: in_progress (base b5863d3)
Task 2: todo
Task 3: todo
Task 4: todo
Task 5: todo
Task 6: todo
Task 7: todo
Task 8: todo
Task 1: Ruling: lazy native createRequire after Node version guard replaces dynamic import — installed Vite resolves node:sqlite as a package while the real Node child opens it successfully — cost: loader seam uses CommonJS require for a Node builtin only.
Task 1: Ruling: recover only when recorded PID is absent, even if PID could have been reused — conservative refusal is safer than treating a changed start timestamp as authority — cost: manual recovery may wait for unrelated reused PID to exit.
Task 1: M01/M01b/M03b fail on actual persistence/acceptance assertions; M03 first mutation only changed rejection code, strengthened to following symlinks and observed an unauthorized open. Full logs read; clone diff and cached diff zero. M02 scheduled Task 3.
Task 1: complete (commits b5863d3..57f2d93, tests: node_modules/.bin/vitest run tests/control/store.test.ts →    Duration  964ms (transform 40ms, setup 0ms, collect 42ms, tests 723ms, environment 0ms, prepare 55ms))
Task 2: in_progress (base 57f2d93). Ruling: graph edit while any group run is active persists proposed intent and latches stop, then returns a named rejection outside the transaction — throwing inside would roll back the required intent; shared graph version affects all active identities — cost: conservative stop of unrelated group tasks.
Task 2: fixture correction: dangling-dependency case accidentally also duplicated taskId; assigned T2 to isolate the intended failure without changing production checks.
Task 2: complete (commits 57f2d93..e808a55, tests: node_modules/.bin/vitest run tests/control/commands.test.ts →    Duration  761ms (transform 58ms, setup 0ms, collect 79ms, tests 454ms, environment 0ms, prepare 51ms))
Task 3: in_progress (base e808a55). Ruling: append-only auxiliary work may register during an active task without changing graphVersion; modifications remain stopped/proposed — handoff/reconciliation must register after the parent exists and do not revise its approved graph — cost: auxiliary dependencies are one-way onto the frozen graph.
Task 3: Ruling: a null cumulative event advances sequence but marks its bucket unknown; only a later explicit cumulative observation clears that flag — sequence receipt and usage knowledge are different facts — cost: peer must supply cumulative totals covering the unknown interval.
Task 3: M02/M07–M13/M07b/M08b each observed red; original bytes equal clone before mutation, tracked/cached diffs zero after restoration; logs read in full. Process claim criterion also passes.
Task 3: complete (commits e808a55..1ff7855, tests: node_modules/.bin/vitest run tests/control/budget.test.ts tests/control/usage.test.ts →    Duration  1.37s (transform 92ms, setup 0ms, collect 167ms, tests 1.36s, environment 0ms, prepare 118ms))
Task 4: in_progress (base 1ff7855). Ruling: persist the complete start envelope atomically with claimed→starting, after claim allocation and before accept — reconciliation contract hash is not available at initial claim; claimed itself is durable before this stage — cost: recovery of never-started claims needs service contract materialization rather than outbox-only replay.
Task 4: complete (commits 1ff7855..a2a5a44, tests: node_modules/.bin/vitest run tests/control/dispatch.test.ts →    Duration  1.25s (transform 70ms, setup 0ms, collect 96ms, tests 911ms, environment 0ms, prepare 45ms))
Task 5: in_progress (base a2a5a44). Ruling: optional ArchiveDependencies inject beforePublish/afterCopy/syncFile at IO boundaries only — required ENOSPC/change/fsync-order criteria need deterministic triggers without production environment backdoors — cost: small internal API surface.
Task 5: complete (commits a2a5a44..59ac473, tests: node_modules/.bin/vitest run tests/control/archive.test.ts tests/control/snapshot.test.ts →    Duration  3.53s (transform 92ms, setup 0ms, collect 214ms, tests 5.32s, environment 0ms, prepare 90ms))
Task 6: in_progress (base 59ac473). Ruling: commitCandidate persists and enqueues; caller separately drains publishPending — plan test expects pending projection after commit whereas inline algorithm immediately drains it; separating durable commit from fallible UI projection satisfies §13.4 and permits retry — cost: service must call publishPending, covered by recovery.
Task 6: complete (commits 59ac473..ce28828, tests: node_modules/.bin/vitest run tests/control/checkpoints.test.ts tests/control/cleanup.test.ts →    Duration  7.12s (transform 121ms, setup 0ms, collect 264ms, tests 9.17s, environment 0ms, prepare 140ms))

Task 7: Ruling: RoundExecution adds preflight and land hooks plus explicit legacy/controlled mode — the original three methods cannot surround Git mutations with durable landing intent or reject unsupported peers before checkout; legacy budget alone may return undefined, controlled refuses it — cost if wrong: an extra internal interface revision.
Task 7: budget substep RED 2/2 (100000 vs 7 and zero accepted), GREEN 8/8 including existing reconcile tests; preflight RED missing runPreparedRound.

Task 7: Ruling: Add optional prepared work (contract, canonical target/source paths, base) to immutable StartEnvelope and readEvidence(ref) to ExecutionPort — the original hash-only request cannot prepare a real run, and ArtifactRef alone cannot archive raw peer bytes; controlled preflight requires evidence retrieval — cost if wrong: ccloop D3 must implement this versioned seam.
Task 7: Ruling: claimWork accepts internally prepared reconcile WorkInput within its existing transaction — separate putWork + claim would leave registration half committed; auxiliary registration preserves current graph identity — cost if wrong: internal claim API needs refactoring.
Task 7: scheduler regression first failed solely missing sibling ccloop path; rerun ORCA_CCLOOP_BIN=/Users/biran/code/skills/loop/ccloop/dist/cli.js passed 52 files / 170 tests; both logs read in full.

Task 7: Ruling: targetRepo is an explicit service binding; projectKey remains an opaque project identity — comparing projectKey to a filesystem path contradicts the approved github.com/example/repo fixture — cost if wrong: project registry must supply the service binding.
Task 7: concurrent full-graph RED exposed transient nlink=2 in artifact publication; replaced hard-link staging with atomic publication of a fsynced directory. Full-graph + archive GREEN 11/11. Refusal RED: budget and stopped left T2 running, now route claim rejection through ordinary escalation/disposal to commit blocked evidence.

Task 7: control + scheduler GREEN 61 files / 237 tests, typecheck exit 0. M32–M36 each exit 1; full raw logs read. M32 illegal legacy launch fails missing unapproved config; M33 100000 vs 7; M34 run not settled; M35 capability preflight not invoked; M36 merge callback count 3 vs 1. Mutation clone restored with empty git diff and cached diff after each; retained at /tmp/orca-control-mutations-0919-task7.
Task 7: complete (commits ce28828..f2d3677, tests: node_modules/.bin/vitest run tests/control/schedulerBridge.test.ts →    Duration  22.09s (transform 299ms, setup 0ms, collect 354ms, tests 21.53s, environment 0ms, prepare 57ms))

Task 8: six SIGKILL markers observed in RED and GREEN; initial recovery + read-model GREEN 7/7. Boundary RED reproduced ownerToken leakage, reused-source deletion, partial checkpoint unable to advance; fixes use Candidate field schema, persisted source dev/ino/birthtime, and content-derived checkpoint IDs. Malformed capability RED confirmed string false granted execution; now strict runtime capability schema.
Task 8: Ruling: recovery never manufactures a missing prepared dispatch intent — after-claim remains blocked with original identity and full reserve, accepted runs reconcile normally — cost if wrong: explicit operator recovery is needed for a pre-dispatch crash.
Task 8: Ruling: recovery preserves sources unless a durable cleanup outbox already authorizes removal — preserves keepWorkdirs/keepBecause choices across restart — cost if wrong: some safe-to-delete source trees remain for human cleanup.

Task 8: Ruling: opening a database with active runs blocks dispatch even after a clean service close — a new owner must reconcile peers; the prior cross-process test now checks this guard and then separately exercises the durable uniqueness guard — cost if wrong: a clean restart requires reconciliation that was previously implicit.
Task 8: filesystem/Git integration suites use 30-second per-test timeouts after a 5-second timeout under concurrent full verification; assertions and crash markers unchanged.

Task 8: control GREEN 12 files / 85 tests; M37–M44 RED behavior assertions, restored diffs empty. Revised archive/checkpoint/cleanup branches rechecked by M19/M22/M24/M27/M28/M30; all exit 1, full logs read and source bytes restored. M22 exercises dangling-symlink preservation and fails ENOENT when incorrectly followed (runtime behavior, not import/type failure). Full verify running with explicit local ccloop dist.

Task 8: full verify RC0, all raw output read in contiguous chunks; 263542 bytes, SHA256 878c7678e2d8bcb5367b0ea121005291040c84177d10ff4d977bb955723e2ed9. Main 141/1160, control 12/85, scheduler 51/167, chain 13/213, chain-env main 141/1160, Web build, panel PASS0–14, Web 9/34. No skips/todos. Real ~/.orca absent.
Task 8: complete (commits f2d3677..9f6e3cc, tests: node_modules/.bin/vitest run tests/control/recovery.test.ts tests/control/endToEnd.test.ts →    Duration  15.88s (transform 135ms, setup 0ms, collect 211ms, tests 21.84s, environment 0ms, prepare 101ms))

Final review: fresh gpt-6-astra xhigh, /root/final_control_review; 8 Important, 0 Critical, 0 Minor; all eight accepted into one fix pass. Review head 9f6e3cc, reproduction tree /private/var/folders/nb/068k_scs4gzgclcp66f9hys40000gn/T/orca-final-review-73r_nr7c retained.
Final fix pass: all eight accepted Important findings fixed. RED 12 negative regressions and one positive control; GREEN 13/13. M45–M53 each exit 1 on actual behavior, all logs read in full; restored tracked/cached diffs empty. Three declaration errors found by typecheck fixed in the same pass; failed logs retained.
F1: Preserve the producer final usageHighWater; incomplete tails retain ownership/reserve until reconciled. M45.
F2: Both budget buckets begin unknown; settlement also requires durable explicit observations, including explicit zero. M46 (three negatives and one positive control).
F3: Write/fsync private staging then atomically publish checkpoint; quarantine torn uncommitted legacy bytes; committed/different valid IDs remain immutable. M47.
F4: Serialize projection drains per owning store and recheck the committed checkpoint identity. M48.
F5: Claim reuse requires target/graph/config identity; a new approved version gets a fresh reservation and versioned command ID. M49.
F6: Repair business acceptance independently of already-settled accounting; exclude live orchestration/recovery overlap. M50 (dispose/recovery), M53.
F7: Goal-review claims obey total used+reserved limit even after a soft overshoot and human unstop. M51.
F8: Controlled preflight maps work-item dependencies into task IDs. M52.
Ruling: production ccloop request caps/isolation/handoff, D3 materialization, cross-host transfer, Web and prompts remain the approved next slices; refusal stays explicit — cost: production controlled dispatch remains unavailable until that protocol exists.
Ruling: do not automatically take over a stale legacy repository lock without ownership proof — cost: an operator must resolve the lock; delayed acceptance after resolution is now repaired by F6.
Ruling: reviewer did not establish a concrete authority/hash bypass from ancestor-symlink retargeting in private directories; retain as unverified hardening scope — cost: private filesystem ancestry must remain under service control.
Ruling: no universal startup/power-loss coverage claim beyond exercised fault boundaries — cost: other untested interruption windows remain unverified.
Deferred Minor findings: none. No second review.
Final verify: RC0, 284702 bytes, SHA256 4d3d9cd16f544447b29774818c865d941c645c50e60d7fa3d4838f6b7ccef359; full output read 0..279923 in contiguous <=24000-character chunks. Main 142/1173 twice; control 13/98; scheduler 51/167; chain 13/213; Web build, panel PASS0–14, Web 9/34. No suite skipped/todo. Existing seven ledger downgrades remain accepted exit-2 path.
Final fix pass: complete at 09e990f56a2784bc8814999d5a495ccbccc1b8b4. Final handoff appended only in development worktree; main, ccloop, ccmem and original Codex development tree preserved. Finishing choice: keep branch/worktree; no merge/push/deletion.
