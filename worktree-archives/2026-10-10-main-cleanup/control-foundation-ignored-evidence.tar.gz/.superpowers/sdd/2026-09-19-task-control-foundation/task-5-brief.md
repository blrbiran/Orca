## Task 5: 独立证据归档与完整脏快照

**Files:** Create `src/control/{archive,snapshot}.ts`; `tests/control/archive.test.ts`; `tests/control/snapshot.test.ts`。

**Interfaces:** `archiveRun(store,input:{runId:string;sourceDir:string;repoDir:string;stopProof:StopProof|null}):Promise<{artifacts:ArtifactRef[];snapshot:ArtifactRef|null;missing:string[]}>`；`readArtifact(store,ref:ArtifactRef):Promise<Buffer>`；`verifySnapshot(store,ref:ArtifactRef):Promise<void>`。archiveRun 不提交 checkpoint、不中止进程、不清理源目录。

- [ ] **Step 1: 用临时 Git repo 构造 HEAD 文件、不同的 staged/unstaged 内容、untracked 二进制、删除项、可执行位和 symlink。归档后移走原 sourceDir，独立从 archive 读取并验证每类字节。** 不能只比 manifest 存在。

```ts
const result = await archiveRun(store,{runId:"r1",sourceDir,repoDir,stopProof});
expect(result.missing).toEqual([]);
await rename(sourceDir, sourceDir + "-retained-for-test");
await verifySnapshot(store,result.snapshot!);
for (const ref of result.artifacts) {
  const bytes = await readArtifact(store,ref);
  expect(createHash("sha256").update(bytes).digest("hex")).toBe(ref.hash);
}
```

另外：同 id 同 hash 可重试；同 id 不同 hash 拒绝；../ 与绝对路径、symlink 父目录逃逸拒绝；FIFO/socket 不阻塞（missing 按名登记、snapshot 不完整）；ENOSPC 留 source；静止证明缺失不能完整可恢复；复制中改变文件后最终 hash 不符判 partial。

- [ ] **Step 2: RED archive/snapshot。**
- [ ] **Step 3: 实现 staging→fsync→不可变发布→独立读回。** 输出在 stateDir `artifacts/<artifactId>/`，临时 staging 同文件系统；文件 close 前 sync，目录也 sync；最终路径 exclusive 发布，重试只比相同内容。不从原路径读作为归档验证。

快照 manifest v1 包含：HEAD、所有 refs 的独立 `git bundle`（含 detached HEAD）、`git ls-files --stage -z` 的完整 stage0–3 条目与各 blob 内容、working tree 完整字节／symlink target／模式／删除清单。所有恢复必需 Git 对象由 bundle+index blob 显式携带，不依赖 local clone hardlink 或源 object alternates。`git bundle verify` 在独立空仓核验。不复制可执行 hooks 或旧锁作为新执行配置。

仓内 `.git` 使用 Git 数据语义采集；其他工作文件包括 ignored/untracked，不能默认忽略 node_modules 就声称完整。特殊文件、嵌套 Git/submodule 或无法独立获取的 LFS 内容首版按名 missing、partial，留现场；不静默跳过。大文件流式 hash/copy；symlink 仅记录链接文本，永不跟随。stateDir 不得位于 sourceDir 内，防自包含递归；真实 `~/.orca` 不是归档默认路径。

归档的日志必须包括原始 ccloop 输出、usage、验证输出、输入契约和配置版本（机密凭据不由 Orca额外读取）；权限私有。Snapshot 的 mode 保存在 metadata，归档对象本身仍0600。

- [ ] **Step 4: GREEN；M19 去掉 fsync（通过注入记录顺序+crash测试），M20 清单漏 untracked，M21 index 与 worktree 合并一份，M22 跟随 symlink，M23 从源读作验证，M24 缺项仍 complete。**
- [ ] **Step 5: 提交 `feat(control): archive logs and dirty snapshots independently`。**

