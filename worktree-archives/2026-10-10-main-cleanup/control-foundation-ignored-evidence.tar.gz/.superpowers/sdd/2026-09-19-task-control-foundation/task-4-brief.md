## Task 4: 持久启动意图与执行所有权

**Files:** Create `src/control/{executionPort,dispatch,ownership}.ts`; `tests/control/dispatch.test.ts`; `tests/control/fixtures/fake-control-peer.mjs`。

**Interfaces:**

```ts
export interface StartEnvelope {
  protocol: 1; claim: Claim; contractHash: string;
  inputCheckpoint: {checkpointId:string;hash:string} | null;
}
export type ExecutionStatus =
  | {kind:"absent"}
  | {kind:"accepted";executionId:string;configHash:string}
  | {kind:"unknown"}
  | {kind:"stopped";proof:StopProof};
export interface ExecutionReport {
  events: UsageEvent[];
  candidate: Candidate | null;
  terminal: {
    outcome: "succeeded" | "blocked_waiting_human" | "exhausted" | "cancelled" | "failed";
    attemptSha: string | null; sourceDir: string; repoDir: string;
  } | null;
}
export interface ExecutionPort {
  capabilities(): Promise<Capabilities>;
  accept(input:StartEnvelope): Promise<ExecutionStatus>;
  inspect(input:StartEnvelope): Promise<ExecutionStatus>;
  collect(input:StartEnvelope, afterSeq:number): Promise<ExecutionReport>;
}
export function startClaim(store:ControlStore, port:ExecutionPort, input:StartEnvelope):Promise<RunView>;
export function reconcileStart(store:ControlStore, port:ExecutionPort, runId:string):Promise<RunView>;
```

`ExecutionPort` 是 Orca 侧消费合同，不是以 Orca 实现 agent 适配。production factory 首版固定 `control-protocol-unavailable`，没有自动退回 `runTask`、Claude 或其他 PATH executable。fake peer 只在 tests 中，具有自身独立 accept journal 和 launch counter，先 fsync accepted 再增长计数，用管道/子进程协议测断连；不是 production runtime。ClaimInput.capabilities 由服务查询已配置的 peer 后填入，不能由 Web 请求体声明 bounded；schema 拒绝客户端提供该字段。future peer 的能力证据要与 ccloop版本/adapter/configHash绑定，字符串非空只作协议形状校验，不是实际封顶的证明。

- [ ] **Step 1: 写 accepted 后断连测试。** 同 envelope 再调 start，inspect 返回原 executionId，fake launch counter=1；不同 configHash 拒绝。

```ts
await expect(startClaim(store, peer, envelope)).rejects.toThrow("start-outcome-unknown");
expect(getRun(store,envelope.claim.runId).state).toBe("unknown");
const recovered = await reconcileStart(store,peer,envelope.claim.runId);
expect(recovered.executionId).toBe("execution-1");
expect(await readFile(counterPath,"utf8")).toBe("1\n");
```

补：发送前 crash、accept 写盘后 crash、Orca accepted 写盘后 crash、inspect 无响应、旧进程仍活、PID reuse、旧 generation 提交、第二监督者与 clock 后退。所有不确定情况保存 active=1 和预留；必须经 peer 隔离旧执行并校验证据后才能接替。单纯 lease 到期、PID 不存在、父进程退出均不够。

- [ ] **Step 2: RED dispatch，观察计数仪器的正控（正常启动计数1）与必抓控（故意非幂等 fake 计数2）。**
- [ ] **Step 3: 实现两阶段本地操作。** claim 事务创建 outbox start intent；派发者 CAS claimed→starting 后才调用 accept；返回 accepted 持久保存 executionId/configHash 映射。发送结果不明记 unknown、先 inspect 原身份，永不生成另一个 runId 重试。inspect absent 只允许同 envelope 重送，依赖 durable accept 幂等；stop intent 已锁存时不重送尚未开始的工作。

服务锁保护唯一派发者，run ownerToken/generation 防本地过期写；ccloop 的 ownershipIsolation 能力负责实际 fencing。fresh generation 不销毁旧代次证据；接替只能在旧执行静止／隔离已确认后事务记录授权。缺任一能力的 adapter 在 claim 前拒绝。

`collect` 补齐执行中用量与终态接缝；有界长轮询由服务持有，浏览器断开不影响它。端口返回的 sourceDir/repoDir 必须位于预登记 run root，不能据任意返回路径读文件或清理。UsageEvent.source 指向先独立归档的原始协议证据，未经核验不能结算。底座先写测试 peer 的完整 collect 流，下一切片才把 ccloop 真实生产者接上；非终态或 collect 失败不合成 failed/zero，不释放预留。

- [ ] **Step 4: GREEN；M14 删持久 start intent、M15 unknown 时新建 run、M16 lease 超时直接释放、M17 删 generation 检查、M18 protocol 不支持时回退旧 runner。**
- [ ] **Step 5: 提交 `feat(control): reconcile durable starts without duplicate execution`。**

