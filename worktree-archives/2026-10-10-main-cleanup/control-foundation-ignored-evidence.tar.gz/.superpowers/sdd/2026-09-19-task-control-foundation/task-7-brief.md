## Task 7: scheduler 受控执行与冲突修复接线

**Files:** Create `src/control/{schedulerBridge,service}.ts`; Modify `src/scheduler/run.ts`, `src/scheduler/reconcile.ts`; Create `tests/control/schedulerBridge.test.ts`。

**Interfaces:** `ControlService` 是上述 commands/claim/start/usage/archive/commit/query 的组合，不重复业务判断。`makeControlledExecution(service,groupId):RoundExecution`；新 `RoundExecution` 定义在 `scheduler/run.ts`，由单轮共用 orchestration 接收：

```ts
export interface RoundExecution {
  execute(input:{plan:PlanFile;task:PlanTask;base:string;kind:"task"|"reconcile"}):Promise<TaskRun>;
  dispose(run:TaskRun, options:DisposeOptions):Promise<Disposal>;
  reconcileBudget(taskId:string):Promise<{maxAttempts:number;perAttemptTimeoutMs:number;totalRuntimeBudgetMs:number;tokenBudget:number}>;
}
```

TaskRun/DisposeOptions/Disposal/PlanFile/PlanTask 为现有导出。旧 CLI 的 legacy 实现保持原值；controlled execute 从已登记的 WorkInput 取 configHash 和 grant，调用 claim/start 的统一入口；不能让 caller 传任意 adapter 绕过。

`execute` 用同一个已领取 run 的 collect 流记录 usage、原始日志和候选；terminal 存在且身份／路径核验后才映射为 TaskRun。此时尚未 task done；harvest/landing 通过后再提交业务结果与清理。`reconcileBudget` 不是另做一次临时预算估算：它原子登记并领取 reconcile workItem，缓存其 Claim；execute 必须消费同一 Claim，不能第二次预留或换 runId。合成契约后把最终 contractHash 固定进 start envelope，第一次 accept 前写盘；失败保留可核对的 claim 状态。

- [ ] **Step 1: 用 fake peer 跑真实两任务冲突图。** T1/T2 的原预算高于当前剩余额度，reconcileBudget 只能给当前批准额度；预算不足时 launch counter 不增加，冲突 ref 和原始日志仍在且任务 blocked。停组后同样不启动 reconciliation。

```ts
const result = await synthesizeReconcileContract(a,b,contracts,runsDir,conflict,{
  maxAttempts:1,perAttemptTimeoutMs:500,totalRuntimeBudgetMs:500,tokenBudget:7
});
if ("escalate" in result) throw new Error(result.escalate);
const built = JSON.parse(await readFile(result.path,"utf8"));
expect(built.executionPolicy.tokenBudget).toBe(7);
expect(built.executionPolicy.totalRuntimeBudgetMs).toBe(500);
```

新增第六参数 `approvedBudget?:` 同上述返回类型，仅旧 legacy 可省略；受控调用处类型要求非可选。原 both-intents、union checks、非main landing 判据全部保留。拒绝0额度而不是为 schema 正整数要求伪造1。

- [ ] **Step 2: RED bridge；原 scheduler 判据先作为对照跑全文件。**
- [ ] **Step 3: 将 run.ts 两处执行及所有处置调用接到 RoundExecution，抽 `runPreparedRound` 供旧 runRound 和 controlled 服务共用。** 受控路径要求持久 groupId，并先检查真实 peer 能力；未支持新协议在任何 Git 改动、预算领取和 spawn 之前拒绝。旧 runRound 保留 CLI schema 和输出，不给它隐式创建 soft 组。

共享函数签名固定为 `runPreparedRound(round:Round,options:RunOptions,execution:RoundExecution):Promise<number>`，原 runRound 负责 loadRound 后构造 legacy execution；controlled 服务读取已批准 group/graph 构造 round，调用同一函数。preflight/repoLock/landing 仍由共用函数持有，不允许调用者绕过。

controlled reconciliation 先保存冲突证据、登记 kind=reconcile，领取额度后再 synthesize，contract 额度来自 claim.grant.work；其交接桶只在新控制 envelope 中传递。synthesized contract 的副作用失败，release 仅在可证明未 accept 的情况下处理，否则保留预留。不得直接用 `Math.max(sideA.tokenBudget,sideB.tokenBudget)` 为受控修复再造预算。

controlled landing 单独记录 intent（base/tip/run/artifact）；恢复查目标 ref 和已存在的 merge commit 再决定补记结果，不盲重 merge。repoLock 仍约束目标仓库；服务所有权不能替代它。Task 6 归档、结算、业务验收全部满足后 dispose，日志读接口只返回稳定 archive 引用。

- [ ] **Step 4: GREEN + 原 scheduler 全套；M32 controlled reconcile 直调 runTask、M33 预算改回双方max、M34 controlled dispose 直删、M35 省 capability preflight、M36 landing 恢复不查ref而重做。**
- [ ] **Step 5: 提交 `feat(control): route scheduler work through durable claims`。**

