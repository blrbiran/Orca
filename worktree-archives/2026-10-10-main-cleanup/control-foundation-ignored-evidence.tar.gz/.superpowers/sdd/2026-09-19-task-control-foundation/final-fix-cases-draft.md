# 审查修复判据草稿（等完整审查后统一执行）

- 对端 final high-water 3，本地只有1–2：两次恢复均 active、有剩余预留；seq3到达后累计记账一次才settled。
- 零用量事件、仅work观测、仅handoff观测：均不结算；两桶显式零可结算且used维持零。
- cp1发布被阻塞，同时commit cp2并请求发布：最终DB pointer、latest checkpointId及hash一致，没有丢失pending。
- 未提交检查点的发布中断：重试同candidate成功；已经提交的坏字节仍拒绝，不修复权威记录。
- work targetVersion升级：下一claim必须是新run、当前graph/target/config身份，预留预算增加；同版本重试不增加。
- 其余审查发现待完整报告补充。
