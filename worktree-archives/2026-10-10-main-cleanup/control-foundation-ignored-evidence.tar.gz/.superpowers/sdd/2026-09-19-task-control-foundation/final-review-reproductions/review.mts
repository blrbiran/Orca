import { readFile, writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { candidateCase } from "./tests/control/fixtures/candidate.ts";
import { archiveCase } from "./tests/control/fixtures/archive.ts";
import { crashCase } from "./tests/control/fixtures/crashCase.ts";
import { roundPeer } from "./tests/control/fixtures/roundPeer.ts";
import { caps,seedBudgetCase } from "./tests/control/fixtures/store.ts";
import { commitCandidate, readCommittedCheckpoint } from "./src/control/checkpoints.ts";
import { publishPending } from "./src/control/projection.ts";
import { readRun } from "./src/control/budget.ts";
import { putWork } from "./src/control/commands.ts";
import { readWork,getGroup } from "./src/control/queries.ts";
import { ControlService } from "./src/control/service.ts";
import { recoverControl } from "./src/control/recovery.ts";
import { archiveRun,writeArtifact } from "./src/control/archive.ts";
const output = (test:string,value:unknown)=>console.log(JSON.stringify({test,...value as any}));
{
 const h=await candidateCase();
 await commitCandidate(h.store,{...h.candidate,result:"partial",stopProof:null});
 let unblock:any,entered:any;
 const blocked=new Promise<void>(r=>unblock=r),ready=new Promise<void>(r=>entered=r);
 const one=publishPending(h.store,{writeProjection:async(path,bytes)=>{entered();await blocked;await writeFile(path,bytes);}});
 await ready;
 await commitCandidate(h.store,{...h.candidate,checkpointId:"cp2"});
 await publishPending(h.store);
 unblock();await one;
 const latest=JSON.parse(await readFile(join(h.store.stateDir,"projections",h.claim.runId,"latest.json"),"utf8"));
 output("projection",{database:readRun(h.store,h.claim.runId).checkpointId,latest:latest.checkpointId,pending:h.store.db.prepare("SELECT count(*) AS n FROM outbox WHERE kind='projection' AND delivered=0").get()?.n});h.store.close();
}
{
 const h=await candidateCase();
 const path=join(h.store.stateDir,"checkpoints",h.claim.runId);
 await mkdir(path,{recursive:true});await writeFile(join(path,"cp1.json"),JSON.stringify(h.candidate).slice(0,64));
 try{await commitCandidate(h.store,h.candidate);output("torn-checkpoint",{committed:true});}catch(e){output("torn-checkpoint",{error:(e as Error).message,state:readRun(h.store,h.claim.runId).state});}h.store.close();
}
{
 const h=await candidateCase();await commitCandidate(h.store,h.candidate);
 const w=readWork(h.store,"g1","T1"),{targetVersion,status,...input}=w;
 putWork(h.store,"g1",{...input,contract:{updated:true}},{commandId:"update",expectedRevision:3,by:"human"});
 const claim=await new ControlService(h.store,{capabilities:async()=>caps} as any).claim("g1","T1");
 output("new-target",{currentTarget:readWork(h.store,"g1","T1").targetVersion,claimTarget:claim.targetVersion,sameRun:claim.runId===h.claim.runId,state:readRun(h.store,claim.runId).state,reserved:getGroup(h.store,"g1").reserved.tokens});h.store.close();
}
{
 const h=await archiveCase();
 const source=await writeArtifact(h.store,"stop-proof",Buffer.from(JSON.stringify({executionId:"execution-1",generation:1,isolated:true})));
 const stopProof={...h.stopProof,source};const a=await archiveRun(h.store,{runId:h.claim.runId,sourceDir:h.sourceDir,repoDir:h.repoDir,stopProof});
 await commitCandidate(h.store,{...h.claim,checkpointId:"missing-usage",usageHighWater:0,result:"complete",artifacts:a.artifacts,snapshot:a.snapshot,missing:[],unresolvedRequestIds:[],stopProof,terminalOutcome:"succeeded"});
 output("missing-usage",{used:getGroup(h.store,"g1").used.tokens,reserved:getGroup(h.store,"g1").reserved.tokens,state:readRun(h.store,h.claim.runId).state,recoverable:readRun(h.store,h.claim.runId).recoverable,events:h.store.db.prepare("SELECT count(*) AS n FROM usage_events").get()?.n});h.store.close();
}
{
 const h=await crashCase("after-accept");const peer=roundPeer(join(h.root,"peer"));
 const gapPeer={...peer,collect:async(...args:any[])=>{const r=await (peer.collect as any)(...args);return {...r,candidate:{...r.candidate,usageHighWater:3}};}};
 const result=await recoverControl(h.store,gapPeer);
 output("peer-high-water",{result,localHighWater:readRun(h.store,h.info.runId).highWater,committedHighWater:(await readCommittedCheckpoint(h.store,h.info.runId)).usageHighWater,state:readRun(h.store,h.info.runId).state,reserved:getGroup(h.store,"g1").reserved.tokens});h.store.close();
}
