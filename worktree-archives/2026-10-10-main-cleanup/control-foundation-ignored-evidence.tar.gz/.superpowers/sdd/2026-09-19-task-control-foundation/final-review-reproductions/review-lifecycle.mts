import { join } from "node:path";
import { crashCase } from "./tests/control/fixtures/crashCase.ts";
import { roundPeer } from "./tests/control/fixtures/roundPeer.ts";
import { caps,amount,openTestStore,seedBudgetCase } from "./tests/control/fixtures/store.ts";
import { recoverControl } from "./src/control/recovery.ts";
import { ControlService } from "./src/control/service.ts";
import { collectControlled,makeControlledExecution,disposeControlled } from "./src/control/schedulerBridge.ts";
import { readRun,claimWork } from "./src/control/budget.ts";
import { readWork,getGroup } from "./src/control/queries.ts";
import { createGroup,putWork,setGroupStopped } from "./src/control/commands.ts";
import { recordUsage } from "./src/control/usage.ts";
import { landIntoW } from "./src/scheduler/land.ts";
import { acquireRepoLock } from "./src/scheduler/repoLock.ts";
const output=(test:string,value:any)=>console.log(JSON.stringify({test,...value}));
{
 const h=await crashCase("after-accept"),peer=roundPeer(join(h.root,"peer")),service=new ControlService(h.store,peer);
 const report=await collectControlled(service,h.info.runId),t=report.terminal!;
 const run={runId:h.info.runId,workdir:t.sourceDir,outcome:t.outcome,attemptSha:t.attemptSha};
 const lock=await acquireRepoLock(h.info.target);
 try {
   const recovered=await recoverControl(h.store,peer);
   const plan={targetRepo:h.info.target,workBranch:"orca/w",runsDir:join(h.root,"runs")} as any;
   await makeControlledExecution(service,"g1").land(plan,[run],run.attemptSha!,()=>landIntoW(plan,run));
   await disposeControlled(service,run,{keepWorkdirs:true});
   output("recovery-overlap",{recovered,runState:readRun(h.store,run.runId).state,workStatus:readWork(h.store,"g1","T1").status,accepted:h.store.db.prepare("SELECT delivered FROM outbox WHERE id=?").get("acceptance:"+run.runId)?.delivered});
 } finally {await lock.release();h.store.close();}
}
{
 const h=await openTestStore();const s=seedBudgetCase(h.store,"soft");const c=claimWork(h.store,s.t1Claim);
 recordUsage(h.store,{runId:c.runId,generation:1,eventSeq:1,bucket:"work",cumulative:amount(120,5,1,1),source:s.usageRef});
 putWork(h.store,"g1",{...s.w1,workItemId:"review",taskId:null,kind:"goal-review",grant:{work:amount(10,100,1,1),handoff:amount(0,0,0,0)}},{commandId:"review",expectedRevision:3,by:"human"});
 setGroupStopped(h.store,"g1",false,{commandId:"unstop",expectedRevision:4,by:"human"});
 const review=claimWork(h.store,{...s.t1Claim,workItemId:"review",commandId:"claim-review",expectedRevision:5});
 const g=getGroup(h.store,"g1");output("review-breach-claim",{claimed:review.runId,used:g.used.tokens,reserved:g.reserved.tokens,limit:g.limit.tokens});h.store.close();
}
{
 const h=await openTestStore();const s=seedBudgetCase(h.store);
 createGroup(h.store,{groupId:"distinct",projectKey:"project",goal:"goal",successConditions:["okay"],limit:amount(200),reviewReserve:amount(0,0,0,0),deadlineAt:null},{commandId:"create",expectedRevision:0,by:"human"});
 putWork(h.store,"distinct",{...s.w1,workItemId:"WI1"},{commandId:"w1",expectedRevision:1,by:"human"});
 putWork(h.store,"distinct",{...s.w2,workItemId:"WI2",dependsOn:["WI1"]},{commandId:"w2",expectedRevision:2,by:"human"});
 const service=new ControlService(h.store,{capabilities:async()=>caps,readEvidence:async()=>Buffer.from("")} as any,{targetRepo:h.root});
 try{await makeControlledExecution(service,"distinct").preflight({plan:{targetRepo:h.root,tasks:[{taskId:"T1",dependsOn:[]},{taskId:"T2",dependsOn:["T1"]}]},contracts:new Map([["T1",s.w1.contract],["T2",s.w2.contract]])} as any);output("distinct-ids",{passed:true});}catch(e){output("distinct-ids",{error:(e as Error).message});}h.store.close();
}
