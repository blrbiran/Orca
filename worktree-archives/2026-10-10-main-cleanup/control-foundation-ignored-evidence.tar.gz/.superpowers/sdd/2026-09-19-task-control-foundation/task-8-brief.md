## Task 8: 崩溃恢复、应用读模型与总体验收

**Files:** Create `src/control/recovery.ts`; `tests/control/recovery.test.ts`, `tests/control/endToEnd.test.ts`; `tests/control/fixtures/crash-worker.mjs`; `scripts/verify-control.mjs`; Modify `package.json`, `README.md`。

**Interfaces:** `recoverControl(store,port):Promise<{blockedRunIds:string[];replayedProjectionIds:string[]}>`；`listGroupArtifacts(store,groupId):ArtifactRef[]` 与 `listTaskArtifacts(store,groupId,taskId):ArtifactRef[]` 放 queries.ts。`readArtifact` 独立重新校验 hash。无 import-as-new-run 接口，无从扫描 latest 猜恢复点的路径。

- [ ] **Step 1: 建真实进程 crash matrix。** worker 每到故障点写同步 marker，父测试确认 marker 后 SIGKILL worker，重开数据库并调用 recovery；计数器和原始证据从磁盘核对。不要以 throw 模拟全部“掉电”。

```ts
for (const point of ["after-claim","after-accept","after-archive","after-transaction","before-projection","before-cleanup"]) {
  const sample = await crashCase(point);
  try {
    const first = await sample.recover();
    const second = await sample.recover();
    expect(second.used).toEqual(first.used);
    expect(second.launches).toBe(first.launches);
    expect(second.landingCount).toBe(first.landingCount);
    expect(second.referencedHashes).toEqual(first.referencedHashes);
  } finally { await sample.dispose(); }
}
```

`crashCase(point)` 在 fixtures/crash-worker 的 TS 驱动 helper 中定义，返回 recover/dispose；recover 返回实际 DB used、fake peer durable launch count、真实 Git merge 数和 archive hashes，不能由预期常量生成。after-claim 若未派发，恢复可以同 run 首次派发一次；断言 first/second 比的是恢复后的稳定值。

另外明确测试：复制 stateDir 到新 host identity 仅可只读核对，`control-host-mismatch` 拒绝启动；缺授权的备份不能执行；预算增加保留既有 used；无 goal review 时所有子任务 done 仍 group review；archive 源删后 task/group refs 都可读；未实现 production protocol 拒绝，fake 不能进生产 factory。

- [ ] **Step 2: RED recovery/endToEnd；确认每个 kill 点确实发生，不将未命中 marker 当成功。**
- [ ] **Step 3: 实现 recovery 的固定顺序。** 验证 service owner/host → 查每个 active run 的原 start envelope/accepted → 核对静止／隔离 → 幂等收 usage → 核对候选/DB引用 → 补未提交事务 → 重放投影 → 重试授权清理。任一未知保留 active 和预算并报告 blocked，不能开替代 run。

本机 host identity 使用 OS 稳定 machine identity 的 hash，另保存 canonical stateDir 与 service instance identity；复制到同机另一目录也拒绝启动，防同机副本复制授权。身份无法可靠读取则拒绝写模式，不能退化成 hostname。它不等于跨机 fencing。跨主机写入始终拒绝，直到后续显式 transfer 协议实现。复制备份本身不能换 identity。已有源端授权不明时只能读。

`scripts/verify-control.mjs` 与 verify-scheduler 同形，`spawnSync` 使用当前项目已安装 vitest（不网络安装），原始 stdout/stderr inherit，非零直接退出。`package.json` 新 `verify:control` 接入完整 verify；README 英文说明本切片仅底座、真实 ccloop protocol 尚不支持、无 Web 停止承诺，列稳定证据读取方式。

- [ ] **Step 4: GREEN；M37 backup 自动获新执行权、M38 recovery 重放重算 usage、M39 goal done 从子任务数推断、M40 原始文件缺失时回退另一 checkpoint。**
- [ ] **Step 5: 完整验收后提交 `test(control): verify restart accounting and evidence retention`。**

## 统一验证流程与变异登记

每 Task 使用独立证据目录 `.superpowers/sdd/2026-09-19-task-control-foundation/task-N/`，写 who/when/base/命令/RC/完整日志位置；本计划不预造结果。执行命令形式：

```sh
rtk proxy sh -c 'npx vitest run tests/control/budget.test.ts > /tmp/orca-control-budget.log 2>&1; result=$?; printf "%s\n" "$result" > /tmp/orca-control-budget.rc; exit "$result"'
rtk proxy cat /tmp/orca-control-budget.log /tmp/orca-control-budget.rc
rtk proxy npm run typecheck
```

完整最终验收：`rtk proxy npm run verify` 后台保存 log/rc，连续分块覆盖全部字节读回；当时 HEAD、node、测试 RUN 路径和状态都留证。不存在 skipped/todo。确认真实 ~/.orca 前后不存在，fake 登记进程全静止；保留实验树和证据，不广泛杀进程／清临时目录。

M01–M40 是最小变异清单，不是只允许40个分支；实施新增分支即补条目。每条在 `git clone --local` 副本中先证明 pristine 字节等于被测实现，单独删除目标行为，跑上表归属文件；必须因行为断言失败，不能拿语法/typecheck/import失败冒充红。还原后 diff 与 cached diff 原始文件各0字节，原判据与主树比字节相同。代码修订后相关变异重跑。

## 规格覆盖与自查

| 规格 | 本切片验收 | 后续真实闭环 |
|---|---|---|
| §4 身份、版本、单写、stateDir | Tasks1/2/4，持久命令与claim | Web 页面 Task切片3 |
| §5 图与变更影响 | Task2，复用图、阻止变更中的派发 | 自动拆分与纠正切片4 |
| §6、§13.1 预算语义 | Task3，所有维度、能力拒绝、保留未知 | ccloop 每请求上界／重试／交接执行 |
| §13.2 全组归账 | Tasks3/7，各 kind、冲突无免费额度、review reserve | 自动拆分/记忆/goal提示词切片4 |
| §13.3 启动身份与所有权 | Task4，durable accept 对端断连测试 | ccloop 实现公共协议与停止隔离证据 |
| §7、§13.4 一致提交 | Tasks5/6/8，断点／坏hash／预算不退 | D3 handoff、跨run物化与显式transfer |
| §13.5 证据保留 | Tasks5/6/8，源清理后独立读全证据 | Web task/group详情消费读模型 |
| §9 Web > CLI | 共用service/queries，无CLI专属执行器 | 下一Web切片实现操作页 |

- [x] 检查已完成的 Codex 五任务不是本计划任务；不需要整合该分支才能写/验 Orca 底座。
- [x] 每任务有文件、接口、RED/GREEN、实现算法或代码与点名变异；测试命令明确标为实施后命令。
- [x] 公共标识统一 groupId/workItemId/taskId/runId，budget work/handoff 分桶；ccloop executionId 另映射。
- [x] 逐项对照 R1–R5，消费端与真实 agent 生产者验收不混称，延后责任明确。
- [x] Review Focus 五项分别落入 Task2/3/4/5/6/8，包含正控与真实持久化断点。
- [x] 本计划只写文档，不把现有回归通过写成新底座已实现；实施完成前所有任务仍未勾选。

## 执行交接

建议 Native：这八项共享 ledger／ownership／checkpoint 接口，先由同一实施者保持一致，最终再做独立整支审查。用户此前 Native 选择明确覆盖已完成 Codex 切片；不据此擅自派新 subagent。本计划审阅通过并确认执行方式后再进入产品实施。整合/推送/清理仍由人操作。
