## Task 2: 组、任务图与命令幂等

**Files:** Create `src/control/{commands,graph,queries}.ts`; `tests/control/commands.test.ts`。

**Interfaces:** `createGroup(store,input:GroupInput,meta:CommandMeta):GroupView`；`putWork(store,groupId,input:WorkInput,meta):GroupView`；`setGroupStopped(store,groupId,stopped:boolean,meta):GroupView`；`setGroupLimit(store,groupId,limit:Amount,meta):GroupView`；`getGroup(store,groupId):GroupView`；`getRun(store,runId):RunView`。这些是内部应用 API，不允许任意 SQL 由 Web 提交。

- [ ] **Step 1: 写命令重放和冲突测试。** `createGroup` expectedRevision=0；成功 revision=1；初始预算 100 tokens、组验收 reserve=10。

```ts
const input: GroupInput = {
  groupId: "g1", projectKey: "github.com/example/repo", goal: "Ship a checked change",
  successConditions: ["required checks pass"],
  limit: {tokens:100,activeMs:10000,attempts:10,sessions:10},
  reviewReserve: {tokens:10,activeMs:1000,attempts:1,sessions:1}, deadlineAt:null
};
const meta = {commandId:"create-1",expectedRevision:0,by:"human"};
const first = createGroup(store,input,meta);
expect(createGroup(store,input,meta)).toEqual(first);
expect(() => createGroup(store,{...input,goal:"Different"},meta)).toThrow("command-id-conflict");
expect(first.reserved.tokens).toBe(10);
expect(() => setGroupStopped(store,"g1",true,{...meta,commandId:"stop-1"})).toThrow("revision-conflict");
```

另测重复 id、环、悬空依赖、不同 project 隔离、空目标、非整数／负／溢出额度、reviewReserve 超 limit、降低 limit 到已用+预留以下拒绝。图变更影响 active run 时保存 proposed 版本且锁存停止派发，直到静止确认才激活；本切片无 handoff 能力则按名 `graph-change-needs-handoff`，不能直接换 active 契约。

- [ ] **Step 2: 跑 commands 文件，确认 RED。**
- [ ] **Step 3: 实现共用幂等事务，重用 `buildGraph` 与写集规则。** command 的稳定序列化递归排序对象键、保持数组顺序，hash 包括 verb/group/by/expectedRevision/body；先查 command，再核 revision。因此真正重试旧 revision 可返回首次结果，换新 commandId 的陈旧修改拒绝。

```ts
return store.transaction(() => {
  const previous = store.db.prepare("SELECT payload_hash,result FROM commands WHERE group_id=? AND id=?").get(groupId, meta.commandId);
  if (previous) {
    if (previous.payload_hash !== payloadHash) throw new ControlError("command-id-conflict");
    return JSON.parse(String(previous.result));
  }
  const group = getGroup(store, groupId);
  if (group.revision !== meta.expectedRevision) throw new ControlError("revision-conflict");
  const result = mutate(group);
  store.db.prepare("INSERT INTO commands VALUES (?,?,?,?)").run(groupId,meta.commandId,payloadHash,JSON.stringify(result));
  return result;
});
```

上述片段置于 `applyCommand<T>(store,groupId,meta,payload,mutate):T`，`mutate` 是同步函数；createGroup 另用不存在视为 revision 0 的分支。每次状态成功修改 revision+1；usage 不改变用户配置 revision，另有 budgetVersion。

- [ ] **Step 4: GREEN + M04（删 payload hash 比较）、M05（删 revision 校验）、M06（组创建不预留复核）。**
- [ ] **Step 5: 提交 `feat(control): version groups and deduplicate commands`。**

