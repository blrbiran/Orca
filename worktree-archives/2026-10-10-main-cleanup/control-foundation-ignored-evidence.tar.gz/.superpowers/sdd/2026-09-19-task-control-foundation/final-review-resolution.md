# Final review and single fix pass

Fresh reviewer: /root/final_control_review, gpt-6-astra xhigh. Reviewed 75d65ec..9f6e3cc. 8 Important, 0 Critical, 0 Minor. All eight accepted and fixed; no second reviewer/re-review.

F1: Preserve the producer final usageHighWater; incomplete tails retain ownership/reserve until reconciled. M45.

F2: Both budget buckets begin unknown; settlement also requires durable explicit observations, including explicit zero. M46 (three negatives and one positive control).

F3: Write/fsync private staging then atomically publish checkpoint; quarantine torn uncommitted legacy bytes; committed/different valid IDs remain immutable. M47.

F4: Serialize projection drains per owning store and recheck the committed checkpoint identity. M48.

F5: Claim reuse requires target/graph/config identity; a new approved version gets a fresh reservation and versioned command ID. M49.

F6: Repair business acceptance independently of already-settled accounting; exclude live orchestration/recovery overlap. M50 (dispose/recovery), M53.

F7: Goal-review claims obey total used+reserved limit even after a soft overshoot and human unstop. M51.

F8: Controlled preflight maps work-item dependencies into task IDs. M52.

Regression RED: 12 failures plus one positive control; GREEN: all 13 passed. Full verification after declaration fixes: exit 0. M45–M53 each exit 1 on behavior assertions; each source restored with zero tracked/cached diff. Mutation selection skips are not suite skips. Failed typecheck logs retained separately.

Ruling: production ccloop request caps/isolation/handoff, D3 materialization, cross-host transfer, Web and prompts remain the approved next slices; refusal stays explicit — cost: production controlled dispatch remains unavailable until that protocol exists.

Ruling: do not automatically take over a stale legacy repository lock without ownership proof — cost: an operator must resolve the lock; delayed acceptance after resolution is now repaired by F6.

Ruling: reviewer did not establish a concrete authority/hash bypass from ancestor-symlink retargeting in private directories; retain as unverified hardening scope — cost: private filesystem ancestry must remain under service control.

Ruling: no universal startup/power-loss coverage claim beyond exercised fault boundaries — cost: other untested interruption windows remain unverified.

Deferred Minor findings: none. Reproduction sources and raw logs copied into final-review-reproductions; original temporary tree retained.
