## Task 3: Reproducible real-path before/after benchmark and final evidence

**Files:**
- Create: `tests/control/fixtures/controlPollPerformance.ts` — 有效规模数据与固定clock；仅fakeprofile/router/port，无真实provider。
- Create: `tests/bench/controlPollPerformance.ts` — 可由tsx运行的有界基准，无产品导出/依赖变化。
- Create: `.superpowers/sdd/2026-10-09-control-poll-performance/benchmark-report.md` 及独立 raw logs/manifest/result JSON。
- Create: `.superpowers/sdd/2026-10-09-control-poll-performance/final-review-input.md` — 给controller fresh终审的数据。

**Interfaces:**
- `ControlPollFixture` 明确含 `store: ControlStore`, `wakeDeps: Parameters<typeof createWebWakeHandlers>[0]`, `driverDeps: Pick<ExecutionDriverDeps, "store" | "admissionGate">`, `service: WebControlService`, `liveGroupIds: readonly string[]`, `archivedGroupIds: readonly string[]`, `canonicalRunIds: ReadonlyMap<string,string>`, `manifest(): { liveGroups: number; archivedGroups: number; tasks: number; dependencies: number; runs: number; pendingTargetWakes: number }`, `dispose(): Promise<void>`。
- `buildControlPollFixture(options: { liveGroups: number; archivedGroups: number; tasksPerGroup: number; now: number }): Promise<ControlPollFixture>`，返回store、fake deps、service、稳定group/task映射、`manifest()`、`dispose()`；借现有openTestStore/webFixture同一合法schema/deps构造方式，不靠绕过readvalidator创建廉价伪数据。固定group/taskID与clock，run随机ID按group/task/claimOrdinal规范化。
- `assertMeasurementCoverage(fixture: ControlPollFixture): void`；直接assert实际G=100/liveT=5000、DAG任务依赖规则、E来自sum(dependsOn.length)、每livegroup至少1currentrun、archivedG=100/pending3种wake=300及各负载非空。构造目标task0=[], task1=[task0], i>=2=[i-1,i-2]；把计算出的E写manifest。
- CLI `rtk proxy npx tsx tests/bench/controlPollPerformance.ts --output <absolute-report-dir> --warmup 10 --samples 30`；输出JSON包含全部负载的timing/counters/output/refusaldigest/运行环境/代码commit/dirtydiff，任何结果或count不等价退出nonzero。

- [ ] **Step 1: Build fixture and benchmark**. 真实入口负载固定为full/reset、alllivechanged incremental、empty incremental、onegroup detail、alllive detail、replenish、archived-onlypump、mixedpump；warmup/sample前重新构造或恢复操作负载同一初态，incremental先记真实cursor，再于一次store.transaction内为100livegroups各recordActivity，避免projectionJournalRetention=64裁掉旧cursor；调用前后断言resetRequired=false、changed group IDs恰100livegroups。empty incremental断言resetRequired=false且groups=[]；full/forced/retention reset分开明确断言resetRequired=true和完整结果。freshprojectionchange由真实recordActivity产生。scope manifests用于证明未通过空cursor/consume降低测量工作量。分别测无hook时长与一轮hookcounters；JSON分类统计只计目标rawbody，其它数据另列。
- [ ] **Step 2: Baseline and after in isolated clones**. controller保存的D9/M3完成beforecommit与aftercommit各`git clone --local`，beforeclone只拷同一新benchmark/fixture/counter工具（不拷产品patch），tsx直接imports该clone生产源码。测相同CLI、机器、Node/SQLite、构造/负载参数；串行使用同一固定repo/config/artifact绝对路径命名空间及同一初态库/证据（可快照恢复），不能各mkdtemp改变contract/config业务hash；不删业务hash来强行等价；每组logs整份保留，测量值附命令+commit。随机runid映射只用于digest，不删除refusal/detail/业务字段。若baseline现有API不能运行同一harness，先修harness，不能绕过真实入口。
- [ ] **Step 3: Evaluate gates**. Task1/2 countbounds达成、normalizedoutput/refusaldigest等价、mutation红证据齐全才继续。report填实测p50/p95/min/max与prepare/execute/rows/parse/handler/probe/accept counts，不预填百分比或0.13s外推；mixedpump的remainingOarchivedscan/每同步段parse写明。收益不足或热点转移如evidence重复扫描，报告真实边界不扩大此轮。
- [ ] **Step 4: Final verification and review input**. 重跑本轮全部命名测试、typecheck，并由controller按最新树安排requiredfullgate，验证命令完整重定向/读回，记录每项rc及测试skip；不对历史suite计数作未测引用。列ownedfiles、before/after、D9/M3冲突裁定、所有计数/变异/耗时raw日志、剩余风险供freshwholebranchreview。
- [ ] **Step 5: Commit owned benchmark/evidence** `test: measure control poll and archived wake workloads`。controller统一review与三仓handoff；本轮不自行push/merge/删除worktree，未被测/未通过项必须列明。

## Plan self-review

Spec §3→Task1，§4→Task2，§5规模/等价/计数/变异→Task1/2/3，§6→Task3+controller。接口在Task1定义，Task2/3只消费；unused/invalid/freshness/activity/race各有命名test和独立变异。任务为三个可独立拒绝的交付件；没有已实施或已通过的占位结论。
