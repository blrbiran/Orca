## Task 1: Batch view work/run snapshots and latest activity

**Files:**
- Create: `src/panel/groupReadSnapshot.ts` — store-bound statements、原始行与 request-local lazy decode。
- Modify: `src/panel/controlViews.ts` — categoryOf/taskCompletion/currentProgress/workViews/runViews/continuableRun、readGroupSummary/readControlSummary/readControlGroup/readRunEvidence。
- Modify: `src/control/activity.ts` — 批 latest seq 查询并复用 entryOf。
- Create: `tests/panel/controlPollPerformance.test.ts`。
- Create: `tests/control/fixtures/controlReadCounters.ts` — test-only SQL/JSON instrumentation。
- Existing regression files run unchanged: `tests/panel/groupSummaryFields.test.ts`, `tests/panel/controlViewOrder.test.ts`, `tests/control/loopPlanViewFields.test.ts`, `tests/panel/runContinuable.test.ts`, `tests/panel/runGitView.test.ts`, `tests/control/activity.test.ts`, `tests/control/activityRuns.test.ts`。

**Interfaces:**
- `StoredWorkRow = Readonly<{ id: string; group_id: string; body: string }>`。
- `StoredRunRow = Readonly<{ id: string; group_id: string; work_item_id: string; generation: number; active: number; body: string }>`。
- `StoredJsonResult = { ok: true; value: unknown } | { ok: false; error: SyntaxError }`。
- `readGroupSnapshot(store: ControlStore, groupId: string): GroupReadSnapshot`；snapshot 的 `groupId`, `workById`, `runById`, `runsByRowid` 为 readonly；`decodeWork(id: string)` / `decodeRun(id: string): StoredJsonResult | undefined` 懒 parse，missing 是 undefined。
- `readLatestRunActivityByGroup(store: ControlStore, groupId: string): LatestRunActivitySnapshot`；`get(runId: string): ActivityEntry | null` 懒 entryOf，与 readRunActivity 对同一 run 最新行等价。
- 私有 `readGroupSummaryFromSnapshot(store, groupId, snapshot)` 供 readControlGroup 嵌入 summary；公开 readGroupSummary/readControlSummary/readControlGroup/readRunEvidence 签名不变。strict schema wrapper 消费 StoredJsonResult 时重用旧 detail；summary 只按旧 catch 位置转 null。
- `ReadCounters = { prepares: readonly { sql: string }[]; executions: readonly { sql: string; method: "get" | "all" | "run"; rows: number }[]; parses: ReadonlyMap<string, number> }`；handler/probe/accept用fake deps自带spies单列，不混进SQL计数。
- `installControlReadCounters(store: ControlStore): { store: ControlStore; reset(): void; snapshot(): ReadCounters; restore(): void }`；透传 bound native db/statement 方法，记录 prepare、实际 get/all/run、返回行数；JSON spy 根据 fixture raw-body 集合分类，finally 恢复。返回store必须为原ControlStore同一对象（不能proxy/clone store导致transaction/projection WeakMap身份失配），只包装db/statement方法；业务调用通过返回的 store，fixture写入/expected查询在 reset 前/after counting 外。

- [ ] **Step 1: Write failing real-entry tests** in controlPollPerformance.test.ts. 10、50任务 fixture 分别调用 readGroupSummary/readControlGroup；assert body batch executions exactly work=1/run=1、target body point gets=0、group latest batch=1/per-run latest=0、summary latest batch=0；每个使用的 raw body parse<=1。输出 counts/completion/work category/progress/current/historical lineage/activity/排序与既有期望逐字段 deepEqual。
- [ ] **Step 2: Add refusal/freshness cases** with named tests from Review Focus. 缺/坏 work summary 不算done/类别；严格 group保留相同ControlError code+detail。bad dependency/currentrun、不被引用坏row、跨组同taskid、amendment/identity/frozen mismatch各pin旧拒绝。调用之后写真实状态/recordActivity，再第二请求必须看到变化；两个store内容不同，第二store不能读第一store。同一instrumented store第一次读取目标statements各prepare=1，reset计数后的第二请求目标prepare=0且SELECT仍各执行1；另store目标prepare各1。close/reopen后的新store重建statement。历史run id lexical顺序与rowid相反；最大seq的at较小；最新activity badkind/badbody拒绝；无行/retention返回null。
- [ ] **Step 3: Observe red** with `rtk proxy npx vitest run tests/panel/controlPollPerformance.test.ts`（整份log、rc）；计数测试必须因真实旧入口的重复get失败，不能只因helper不存在失败。
- [ ] **Step 4: Implement interfaces and wiring**. 两个 group-scoped all statements；rowid-order run 原始集合不丢历史/estimate/handoff。lazy解码结果留请求内，strict wrapper保留原parse/schema detail与调用顺序；有效plan读取也从快照给effectivePlanTask。runViews显示按原id顺序；其它evidence/冻结读取保持。activity SELECT按runs成员join最大seq原始activity完整行并懒entryOf，不MAX(at)。statement WeakMap仅存statement。
- [ ] **Step 5: Run focused verification**: `rtk proxy npx vitest run tests/panel/controlPollPerformance.test.ts tests/panel/groupSummaryFields.test.ts tests/panel/controlViewOrder.test.ts tests/control/loopPlanViewFields.test.ts tests/panel/runContinuable.test.ts tests/panel/runGitView.test.ts tests/control/activity.test.ts tests/control/activityRuns.test.ts` and `rtk proxy npm run typecheck`；全部rc0且无跳过。本任务不改已有tests。
- [ ] **Step 6: Mutations in isolated clone**: 去掉group限定→跨组红；decode result跨请求保留→freshness红；删strictwork schema/authority→strict红；run排序用id代rowid→lineage红；MAX(at)→rollback红；删entryOf→corruptactivity红；还原逐taskbodyget→count红。分别跑对应命名test，记录每个独立nonzero，不共享一次变异掩盖多个guard。clone还原diff/stageddiff字节数0。
- [ ] **Step 7: Record and commit** only owned source/new tests/new report into `.superpowers/sdd/2026-10-09-control-poll-performance/task-1-report.md`，含真实commit/命令/rc/计数/变异，commit message `perf: batch control view work and run reads`。

