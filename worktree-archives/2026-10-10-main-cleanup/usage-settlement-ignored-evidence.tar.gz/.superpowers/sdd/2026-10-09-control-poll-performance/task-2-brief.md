## Task 2: Reuse driver body and filter archived wakes safely

**Files:**
- Modify: `src/control/executionDriver.ts` — replenishStartWakes 的原nextClaimable位置传group。
- Modify: `src/control/webDispatch.ts` — nextClaimableTask可选body；所有claimarchive checks保留。
- Modify: `src/control/dispatch.ts` — deliverSchedulerWakes局部合法归档filter。
- Create: `tests/control/archivedWakePerformance.test.ts`。
- Consume: `tests/control/fixtures/controlReadCounters.ts`。
- Existing regression files run unchanged: `tests/control/archiveGroup.test.ts`, `tests/control/webDispatch.test.ts`, `tests/control/dispatch.test.ts`, `tests/control/driverRoundIsolation.test.ts`, `tests/control/driverContinuation.test.ts`。

**Interfaces:**
- `nextClaimableTask(store: ControlStore, groupId: string, groupBody?: unknown): ClaimableTask | null`；body only from same group/current synchronous read，undefined保留oldstore read。
- replenishStartWakes与deliverSchedulerWakes公开签名、结果不变；泵内局部filter的状态为合法archived/合法unarchived/unknown（坏row，不优化）。不是新的authority。
- live handlers继续用createWebWakeHandlers；归档filter不能替代deliverScheduledStart交易内isGroupArchived。

- [ ] **Step 1: Write failing entry/count tests**. 已启动可dispatch group、无pendingwake、存在laststart的replenish入口：groupbody parse exactly1，传body的nextClaimable额外groupsbodyget=0，现有arm/noarm输出相同。100合法archivedgroups各3种wake连续置入；连续3pump每次 target handler/probe/accept=0，每组groups lookup/parse=1，全部wake仍delivered=0且deferred按rowid原序；比较before入口返回IDs，不改派发种类。
- [ ] **Step 2: Pin refusal/lifecycle/races**. absent mark的真实handler照常可claim；null/string/array/缺actor/extrafield/坏groupJSON的真实handlers保持原拒绝并pending；直接deliverScheduledStart的code/detail相同，invalid不是filterhit。unarchive命令后第一pump实际投递。混合pump先一livehandler await期间unarchive后面group，下一wake看到当前mark；同样archive时拒绝。fakeprobe期间archive，最终交易拒绝、active runs=0、pending不消费。requirement/estimatekindhandler行为与旧入口同；global blocker/nohandler/groupblocker优先序相同。
- [ ] **Step 3: Observe red**: `rtk proxy npx vitest run tests/control/archivedWakePerformance.test.ts`；旧真实路径应因重复groupread或handlercallcounts失败。
- [ ] **Step 4: Implement minimal changes**. body参数只替换nextClaimable原archive-read；不提前对不dispatchable/stopped坏mark加拒绝。pumpfilter在原blocker判断后、wakeJSON/handler前，用isGroupArchived/archivedMarkOf同一语义；异常仅设置unknown并继续旧handler。await handler完成后清map，含false/throw，保留resultorder与UPDATE位置。用store-boundprepared group lookup，判定不跨pump。
- [ ] **Step 5: Verify**: `rtk proxy npx vitest run tests/control/archivedWakePerformance.test.ts tests/control/archiveGroup.test.ts tests/control/webDispatch.test.ts tests/control/dispatch.test.ts tests/control/driverRoundIsolation.test.ts tests/control/driverContinuation.test.ts` plus `rtk proxy npm run typecheck`；rc0/无skip。
- [ ] **Step 6: Independent clone mutations**. 删入口filter→handler0红；filter把invalid当true→invalidreachesauthority红；跨pump保留map→unarchive红；不在await后清map→samepumpupdate红；删交易archiveguard→probe race红（不能被前置guard挡住）；删driverbody实参→groupcounts红。每个命名testnonzero后还原，clone diff/stageddiff字节数0。
- [ ] **Step 7: Record/commit** new task-2-report.md，`perf: reuse driver group bodies and defer archived wakes early`；明确mixedawait条件下仍读/解析的实际次数，不承诺SQL零parse。

