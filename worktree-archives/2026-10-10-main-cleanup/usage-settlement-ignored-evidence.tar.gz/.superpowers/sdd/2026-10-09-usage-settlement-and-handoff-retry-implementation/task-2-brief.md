### Task 2: M3 retrying/source 生命周期与真实执行上界

**Files:** Create src/control/retryGrant.ts（共享 live retry校验）、tests/control/handoffFailedRetry.test.ts。Modify src/control/retryTask.ts、executionSnapshot.ts、webProtocol.ts、stopIntent.ts、continuation.ts、webDispatch.ts、executionDriver.ts、src/panel/controlViews.ts 和必要work/run schema。Consume Task1 marker/request状态与hasValidUsageSettlement。

**Interfaces:** Produce validateRetryGrantSource(store, groupId, work)（无源为旧行为；retrying源缺失/错误抛 recovery-blocked），driver和panel共同调用。沿用 applyRetryTask(deps, command)、withinGrant(policy,grant)；字段 work.retryGrantSourceRunId 可选。所有writer在held/continuing/terminal转移原子清 live源，不删除历史run。

- [ ] Step 1: 新增失败判据 `retries a handoff-settled failed continuation at its claim grant`、`retries released manual settlement without releasing twice`；再新增 `settles unknown usage before handoff then resumes and retries from head`（§9.5）；真实失败→D9→handoff→空选resume→retry→claim和真实失败→handoff→空选resume→retry，断言amount/source/endedAt/原因，真实claim读view/driver并截取port.accept，policy三维min、hash不变、head最新、checkpoint null。
- [ ] Step 2: 先运行新文件看到缺inactive admission/lifecycle/policy错误；禁止改原stop就拒绝的retryTask断言。
- [ ] Step 3: 实现 active、inactive held recoverable、manual released failed 三种retry reservation区别；retrying schema、frozen shape与source完整校验、consumed registration精确身份/清除；普通confirmed active retry原语义保留。A2统一 task policy clamp。
- [ ] Step 4: 新增 `rearms invalid first proof with the newest currentRunId and no second reservation`、`resumes a pre-provider stopped retry without a second reservation`、`active retry after reduced retry remains valid`；真实claim/settleProviderAttempt/handoff命令→view/driver→close/reopen→再claim，校验lineage/grants/零cumulative/source身份。拒绝不足、旧源、漂移、pending continuation、其它未知、stop/archived；Continue旧合法能力保留，新manualfailed不能Continue。
- [ ] Step 5: 运行本task与 tests/control/retryTask.test.ts、continuation/handoff相关直接调用者文件、Task1新判据及typecheck。clone内删除inactive/released admission、grant恢复、source校验、no-start/restartable reader、policyclamp、清consumed关键分支，各匹配判据红；正常恢复绿，按路径commit、写task报告。

