### Task 4: 全轮验证、终审修复与交接

**Files:** 本轮新增SDD报告、docs/handoff/handoff.md、两 sibling handoff 的 Orca章节；只在review发现需要时修改本轮产品/新增测试。不改其它仓产品。

**Interfaces:** Consume前三task提交与测试/变异证据；produce round-close ledger、review报告、三仓紧凑handoff、给人的10行以内executive summary（不写文件）。

- [ ] Step 1: controller委派fresh verifier，隔离env和固定ccloop clone，先webbuild；顺序运行typecheck/build、新增task测试、web check、verify:control、verify:scheduler、verify:ccloop-pin、verify:panel、npm test、check-tmp-leak。完整输出真实RC带观测commit，不重复无意义全门。
- [ ] Step 2: 登记的负载timeout按名单低负载单文件复验并记uptime；断言失败查根因，不豁免。核对关键变异都实际见红（不是启动失败）；变异只clone，主工作树src/tests零额外漂移。
- [ ] Step 3: controller fresh全分支review spec+quality，读证据与whole-range diff；必要一波fix worker、scoped re-review，无真实付费验收则明说。
- [ ] Step 4: controller按人授权更新Orca/ccloop/ccmem handoff，各Orca段替换为当前结论/必要next，不无限追加，不以本次handoff可变HEAD当定位。保留commit/report语义与固定dependency pin。每仓精确路径本地commit，不push/merge。
- [ ] Step 5: ledger追加Round close、逐task结论和全部Ruling成本；保留本轮历史证据，不删除worktree/branch。最终报告给人审核并直接给10行以内executive summary。
