### Task 3: owner 结清预览与失败恢复界面

**Files:** Create web/tests/settleUnknownUsage.test.tsx、web/tests/handoffFailedRetry.test.tsx。Modify web/src/controlTypes.ts、authority command wire分类所在文件、runFacts.ts、ControlGroupView.tsx、locales/en.ts、locales/zh.ts、activity rendering直接调用者。Consume Task1 RunViewV1.unknownUsageSettlement、Task2新Retry资格；客户端不得自行宣称proof通过或重算权威费用。

**Interfaces:** POST独立D9命令，仅owner入口，两个bucket四维预览/不可撤销保守说明；member联系owner；显示usageSettlement method/charged/at/principal。已有command action/recovery/Revision机制复用；恢复派发入口发送 resume-from-handoff selections=[]，与checkpoint Continue区分。

- [ ] Step 1: 新test先失败：owner看金额确认、member无授权入口；D9前后failed原因不消失；handoff complete无续跑选择时空选resume→Retry；其它run未决时不可误报整组已恢复；success/普通中断/旧run/pending continuation不出现错误Retry。
- [ ] Step 2: 实现状态/权限/拒绝原因/错误文案、独立确认和request、两桶费用、activity人话、空选resume和M3按钮。中英文完整，不暴露实现细节作为用户决策。
- [ ] Step 3: npm run --workspace web check、root typecheck、panel相关前先web build；跑新tests及 web/tests/driverRetry.test.tsx web/tests/taskActivity.test.tsx web/tests/controlCommandRecovery.test.tsx。clone删owner入口守卫、费用确认、失败原因分支/空选resume、新retry资格，各相关新增判据红，正常恢复绿。
- [ ] Step 4: 按路径commit、self-review与task报告，交controller task spec+quality review。

