
- 用户授权 controller 完成设计修正、plan、subagent-driven 实施，问题先按建议处理，最后统一审核；不另暂停中间 artifact approval。
- 只做 D9/M3；issue-fixes 旧任务和旧台账一个字不改；M5/M6 为下一独立轮。
- 结清两桶 work/handoff remaining 的 tokens/activeMs/attempts/sessions 全维度；不是组 reserve。commit/replay/rollback 只计一次。
- 固定 ccloop ab824d16004de2d3c1613a76ec0431520aa16cc9；ORCA_CCLOOP_BIN=/private/tmp/orca-d9-ccloop-ab824d1/dist/cli.js。ccloop/ccmem 产品不修改。
- schema 10 单向门；旧 run/work 无新字段兼容，持久字段出现时必须严格校验。
- owner Web 认证 principal 授权；member/socket/MCP agent 拒绝。actorId/acknowledge 不构成身份。
- git 核对 rtk proxy /usr/bin/git；只 git add 具名路径（SDD 精确 -f），不 add -A；不 push/merge/删分支/worktree。
- tests/panel 前 npm run build --workspace web。所有 shell 经 rtk，验证输出写文件后整份读回，记录真实 RC、观测提交。
- 不碰真实 HOME/XDG/控制库/服务/付费 agent；测试临时根改道；变异只在 no-hardlinks local clone，不能改主工作树。
- 现有历史 spec/SDD 只能追加更正；handoff 可压缩活文档。worker 不派 subagent，controller 提供 task review。

