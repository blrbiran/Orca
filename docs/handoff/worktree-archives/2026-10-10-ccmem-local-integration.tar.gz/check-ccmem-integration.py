from pathlib import Path
import os, subprocess, tempfile, json, hashlib, sys

phase = sys.argv[1]
assert phase in ('candidate', 'merged')
label = sys.argv[2] if len(sys.argv) > 2 else phase
assert all(c.isalnum() or c == '-' for c in label)
source = Path('/Users/biran/code/skills/ccmem')
root = Path(tempfile.mkdtemp(prefix=f'ccmem-parity-{phase}-', dir='/private/tmp'))
clone = root / 'clone'
env = {'PATH': os.environ['PATH'], 'LANG': 'en_US.UTF-8'}
for key, name in [('HOME', 'home'), ('XDG_CONFIG_HOME', 'config'),
                  ('XDG_CACHE_HOME', 'cache'), ('XDG_DATA_HOME', 'data'),
                  ('XDG_STATE_HOME', 'state'), ('TMPDIR', 'tmp'),
                  ('CCMEM_DATA_ROOT', 'ccmem')]:
    p = root / name
    p.mkdir()
    env[key] = str(p)
log = Path('/private/tmp/od9/logs') / f'ccmem-parity-{label}.log'
rcfile = log.with_suffix('.rc')
with log.open('wb') as out:
    subprocess.run(['/usr/bin/git', 'clone', '--local', '--no-hardlinks', '--branch', 'main', str(source), str(clone)], env=env, stdout=out, stderr=subprocess.STDOUT, check=True)
    if phase == 'candidate':
        subprocess.run(['/usr/bin/git', '-C', str(clone), '-c', 'user.name=Integration Check', '-c', 'user.email=integration-check@localhost', 'merge', '--no-edit', 'origin/config-value-parity'], env=env, stdout=out, stderr=subprocess.STDOUT, check=True)
    paths = ['tests/unit/v013-config-sync.test.mjs', 'tests/unit/v013-config-fallback.test.mjs',
             'tests/unit/v014-config-delta.test.mjs', 'tests/unit/v014-config-value-parity.test.mjs']
    result = subprocess.run(['node', '--test', *paths], cwd=clone, env=env, stdout=out, stderr=subprocess.STDOUT)
rcfile.write_text(str(result.returncode) + '\n')
test = clone / paths[-1]
meta = {'phase': phase, 'root': str(root), 'clone': str(clone), 'rc': result.returncode,
        'source_head': subprocess.check_output(['/usr/bin/git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip(),
        'test_sha256': hashlib.sha256(test.read_bytes()).hexdigest(),
        'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'log': str(log)}
log.with_suffix('.metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
sys.exit(result.returncode)
