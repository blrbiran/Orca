import json, sys, subprocess
from pathlib import Path
root = Path('/private/tmp/od9')
env = json.loads((root / 'env.json').read_text())
work = '/Users/biran/code/skills/loop/Orca'
name = sys.argv[1]
command = sys.argv[2:]
log = root / 'logs' / (name + '.log')
print('COMMAND', command, 'CWD', work, 'LOG', log, flush=True)
with log.open('w') as output:
    result = subprocess.run(command, cwd=work, env=env, stdout=output, stderr=subprocess.STDOUT)
log.with_suffix('.rc').write_text(str(result.returncode) + '\n')
print('RC', result.returncode, flush=True)
raise SystemExit(result.returncode)
