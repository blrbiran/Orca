from pathlib import Path
import sys,json,hashlib
name=sys.argv[1];p=Path('/private/tmp/od9/logs')/(name+'.log');raw=p.read_bytes();lines=raw.splitlines(keepends=True);chunks=[];b=b''
for line in lines:
 if b and len(b)+len(line)>18000:chunks.append(b);b=b''
 b+=line
if b:chunks.append(b)
i=int(sys.argv[2]);offset=sum(map(len,chunks[:i]));print(f'RAW LOG {p}: chunk {i+1}/{len(chunks)}, bytes [{offset},{offset+len(chunks[i])}) of {len(raw)}');sys.stdout.flush();sys.stdout.buffer.write(chunks[i]);sys.stdout.flush()
record=Path('/private/tmp/od9/task4-log-read-proof.json');proof=json.loads(record.read_text()) if record.exists() else {};entry=proof.setdefault(name,{'read_chunks':[], 'chunk_hashes':{}});entry.update({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'chunk_count':len(chunks)});entry['chunk_hashes'][str(i)]=hashlib.sha256(chunks[i]).hexdigest();entry['read_chunks']=sorted(set(entry['read_chunks']+[i]));entry['all_read_chunks_still_match']=all(int(k)<len(chunks) and hashlib.sha256(chunks[int(k)]).hexdigest()==v for k,v in entry['chunk_hashes'].items());assert entry['all_read_chunks_still_match'];record.write_text(json.dumps(proof,indent=2)+'\n')
