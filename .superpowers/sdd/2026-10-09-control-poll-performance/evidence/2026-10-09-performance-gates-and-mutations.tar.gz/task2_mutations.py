import json,sys,subprocess,hashlib,time
from pathlib import Path
root=Path('/private/tmp/od9');clone=root/'performance-task2-mutation'
env=json.loads((root/'env.json').read_text())
files=['src/control/dispatch.ts','src/control/executionDriver.ts','src/control/webDispatch.ts','tests/control/fixtures/controlReadCounters.ts','tests/control/archivedWakePerformance.test.ts']
original={f:(clone/f).read_text() for f in files}
base=subprocess.check_output(['rtk','proxy','/usr/bin/git','rev-parse','HEAD'],cwd=clone,text=True).strip()
print('CLONE COMMIT',base,flush=True)
def mutate(name,file,old,new,test):
 s=original[file]
 assert s.count(old)==1,(name,s.count(old))
 changed=s.replace(old,new)
 if name=="store-scope": changed=changed.replace("wakeGroupStatements.set(store,statement)","wakeGroupStatements.set(globalThis as unknown as ControlStore,statement)")
 (clone/file).write_text(changed)
 log=root/'logs'/('perf-task2-mutation-'+name+'.log')
 cmd=['npx','vitest','run','tests/control/archivedWakePerformance.test.ts','-t',test]
 print('COMMAND',cmd,'CWD',str(clone),'LOG',str(log),'BASE',base,flush=True)
 try:
  with log.open('w') as out: result=subprocess.run(cmd,cwd=clone,env=env,stdout=out,stderr=subprocess.STDOUT)
  (root/'logs'/('perf-task2-mutation-'+name+'.rc')).write_text(str(result.returncode)+'\n')
  print('MUTATION',name,'RC',result.returncode,flush=True)
  assert result.returncode!=0,name+' survived'
 finally:
  for f,saved in original.items(): (clone/f).write_text(saved)
 diff=subprocess.check_output(['rtk','proxy','/usr/bin/git','diff'],cwd=clone)
 staged=subprocess.check_output(['rtk','proxy','/usr/bin/git','diff','--cached'],cwd=clone)
 print('RESTORED',name,'diff_bytes',len(diff),'staged_diff_bytes',len(staged),flush=True)
 assert len(diff)==len(staged)==0
 if sys.argv[1]!=name and sys.argv[1]!='all': raise RuntimeError('unexpected name')
mutations={
 'filter':('src/control/dispatch.ts','if(archiveStates.get(groupId)===true){deferred.push(id);continue;}','if(false){deferred.push(id);continue;}','defers 100 archived groups'),
 'invalid':('src/control/dispatch.ts','catch {archiveStates.set(groupId,"unknown");}','catch {archiveStates.set(groupId,true);}','keeps invalid mark|keeps malformed group JSON'),
 'cross-pump':('src/control/dispatch.ts',' const archiveStates=new Map<string,boolean|"unknown">();',' const archiveStates=(store as ControlStore & { task2States?: Map<string,boolean|"unknown"> }).task2States ??= new Map<string,boolean|"unknown">();','delivers on the first pump after a real unarchive'),
 'await-clear':('src/control/dispatch.ts','finally {if(enteredHandler)archiveStates.clear();}','finally {}','sees same-pump'),
 'transaction':('src/control/webDispatch.ts','      if (isGroupArchived(store, groupId)) return { kind: "blocked" as const, reason: "group-archived" };','','keeps the final claim transaction archive guard'),
 'driver-body':('src/control/executionDriver.ts','nextClaimableTask(store, groupId, group)','nextClaimableTask(store, groupId)','replenishes from one parsed group body'),
 'body-reuse':('src/control/webDispatch.ts','groupBody === undefined ? isGroupArchived(store, groupId) : archivedMarkOf(groupBody) !== null','isGroupArchived(store, groupId)','retains optional-body and default authority results'),
 'sync-map':('src/control/dispatch.ts','if(!archiveStates.has(groupId))','if(true)','defers 100 archived groups'),
 'statement-reuse':('src/control/dispatch.ts','let statement=wakeGroupStatements.get(store);','let statement: StatementSync | undefined=undefined;','defers 100 archived groups'),
 'kind-scope':('src/control/dispatch.ts','if(kind==="start"||kind==="no-start"||kind==="resume")','if(true)','keeps estimate and requirement handlers'),
 'no-await':('src/control/dispatch.ts','finally {if(enteredHandler)archiveStates.clear();}','finally {archiveStates.clear();}','parses an archived group once across a malformed live wake'),
 'store-scope':('src/control/dispatch.ts','wakeGroupStatements.get(store)','wakeGroupStatements.get(globalThis as unknown as ControlStore)','does not share prepared archive lookups'),
}
selected=mutations if sys.argv[1]=='all' else {sys.argv[1]:mutations[sys.argv[1]]}
for name,(file,old,new,test) in selected.items():
 mutate(name,file,old,new,test)
