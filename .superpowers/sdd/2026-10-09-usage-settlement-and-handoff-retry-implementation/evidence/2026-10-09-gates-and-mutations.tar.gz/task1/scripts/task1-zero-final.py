import subprocess,json,shutil
from pathlib import Path
root=Path('/private/tmp/orca-task1-clones');clone=root/'mutation';work=Path('/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca');logs=root/'logs'
files=json.loads((root/'task-files.json').read_text())
for f in files:shutil.copyfile(work/f,clone/f)
def git(*args):return subprocess.run(['rtk','proxy','/usr/bin/git',*args],cwd=clone,check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout
git('add','--',*files);git('-c','core.hooksPath=/dev/null','-c','user.name=Codex Task1 mutation','-c','user.email=task1@localhost','commit','-m','test: sync final typed Task1 readers')
base=git('rev-parse','HEAD').decode().strip();print('CLONE_BASE',base,flush=True)
p=clone/'src/control/usageLedger.ts';original=p.read_text();old='  if (input.tokens === 0) return;\n  insertRow(store, { appliedAt: input.appliedAt, groupId: input.run.groupId';new='  insertRow(store, { appliedAt: input.appliedAt, groupId: input.run.groupId';assert old in original;p.write_text(original.replace(old,new,1))
env=json.loads(Path('/private/tmp/od9/env.json').read_text());env['FORCE_COLOR']='0'
cmd=['rtk','proxy',str(clone/'node_modules/.bin/vitest'),'run','tests/control/settleUnknownUsage.test.ts','-t','no zero-token ledger rows','--reporter=dot']
with (logs/'zero-token-final.log').open('w') as f:r=subprocess.run(cmd,cwd=clone,env=env,stdout=f,stderr=subprocess.STDOUT)
p.write_text(original);print('ZERO_RC',r.returncode,'DIFF_BYTES',len(git('diff')),'CACHED_DIFF_BYTES',len(git('diff','--cached')),flush=True)
cmd=['rtk','proxy',str(clone/'node_modules/.bin/vitest'),'run','tests/control/settleUnknownUsage.test.ts','tests/control/schema10.test.ts','tests/panel/settleUnknownUsage.test.ts','--reporter=dot']
with (logs/'restored-final.log').open('w') as f:r=subprocess.run(cmd,cwd=clone,env=env,stdout=f,stderr=subprocess.STDOUT)
print('RESTORED_RC',r.returncode,'DIFF_BYTES',len(git('diff')),'CACHED_DIFF_BYTES',len(git('diff','--cached')),flush=True)
