import { openControlStore } from "/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca/src/control/store.ts";
async function main() { const store = await openControlStore({ stateDir: "/private/tmp/orca-task1-clones/schema10-state" }); store.close();
console.log("new reader created schema10"); }
main().catch(e=>{console.error(e);process.exitCode=1;});
