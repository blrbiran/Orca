import subprocess,json,os,shutil
from pathlib import Path
work=Path('/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca')
root=Path('/private/tmp/orca-task1-clones');clone=root/'mutation';logs=root/'logs';logs.mkdir(mode=0o700,exist_ok=True)
files=json.loads((root/'task-files.json').read_text())
for f in files:shutil.copyfile(work/f,clone/f)
def git(*args):return subprocess.run(['rtk','proxy','/usr/bin/git',*args],cwd=clone,check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout
if git('diff','--name-only'):
 git('add','--',*files);git('-c','core.hooksPath=/dev/null','-c','user.name=Codex Task1 mutation','-c','user.email=task1@localhost','commit','-m','test: isolated Task1 mutation baseline')
print('CLONE_BASE',git('rev-parse','HEAD').decode().strip(),flush=True)
env=json.loads(Path('/private/tmp/od9/env.json').read_text());env['FORCE_COLOR']='0';env['ORCA_CCLOOP_BIN']='/private/tmp/orca-d9-ccloop-ab824d1/dist/cli.js'
ctl='tests/control/settleUnknownUsage.test.ts';panel='tests/panel/settleUnknownUsage.test.ts'
mutants=[
('committed-reserved','src/control/settleUnknownUsage.ts','if (disposition === "committed") group.reserved = subtract(group.reserved, delta);','void disposition;',ctl,'charges both buckets'),
('released-admission','src/control/settleUnknownUsage.ts','return "released";','throw new ControlError("run-usage-not-settleable", "deleted-released-admission");',ctl,'charges a released failed handoff'),
('released-reserved','src/control/settleUnknownUsage.ts','if (disposition === "committed") group.reserved = subtract(group.reserved, delta);','group.reserved = subtract(group.reserved, delta);',ctl,'charges a released failed handoff'),
('manual-close','src/control/settleUnknownUsage.ts','if (disposition === "released") settleManuallyFailedRequestInTransaction(store, groupId, request!.requestId, marker);','void marker;',ctl,'completes only'),
('marker-observed','src/control/budget.ts','if((run as {usageSettlement?:unknown}).usageSettlement!==undefined) return hasValidUsageSettlement(store,run as never);','',ctl,'settlement before handoff counts'),
('human-only','src/panel/humanOnly.ts','"settle-unknown-usage": "human-only"','"settle-unknown-usage": "any"',panel,'authenticated principal'),
('proof-content','src/control/usageSettlement.ts','if (proof.isolated !== true || proof.executionId !== run.executionId || proof.generation !== run.generation) throw new Error("stop-proof-content");','void proof;',ctl,'refuses isolation'),
('pending','src/control/settleUnknownUsage.ts','if (store.db.prepare("SELECT seq FROM usage_events WHERE run_id=? AND seq>?").get(run.runId, run.highWater)) throw new ControlError("run-usage-pending");','',ctl,'refuses pending'),
('settled-replay','src/control/settleUnknownUsage.ts','if (run.usageSettlement !== undefined) throw new ControlError("run-usage-settled");','',ctl,'charges both buckets'),
('late-event','src/control/usage.ts','if((run as {usageSettlement?:unknown}).usageSettlement!==undefined) throw new ControlError("run-usage-settled");','',ctl,'charges both buckets'),
('checkpoint-missing','src/control/usageSettlement.ts','|| c.missing.length || c.unresolvedRequestIds.length || c.snapshot === null','|| c.unresolvedRequestIds.length || c.snapshot === null',ctl,'a missing defect'),
('checkpoint-unresolved','src/control/usageSettlement.ts','|| c.missing.length || c.unresolvedRequestIds.length || c.snapshot === null','|| c.missing.length || c.snapshot === null',ctl,'a unresolved defect'),
('transaction-recheck','src/control/settleUnknownUsage.ts','!settlementSame(run, evidence.body) || !settlementSame(settlementProof(store, run), evidence.proof)','!settlementSame(settlementProof(store, run), evidence.proof)',ctl,'rechecks changed remaining'),
('ledger','src/control/settleUnknownUsage.ts','bookSettledUsage(store, { run, groupBody: group as unknown as Record<string, unknown>, bucket: b, tokens: charged[b].tokens, appliedAt: at });','',ctl,'charges both buckets'),
('other-unknown','src/control/budget.ts','const usageUnknown=groupUsageUnknown(store,group.groupId,currentRun);','const usageUnknown=false;',ctl,'unknown/open request blocker'),
('marker-receipt','src/control/usageSettlement.ts','if (!row || row.principal !== m.principal || row.client !== "web" || row.verb !== "settle-unknown-usage") return false;','if (!row) return true;',ctl,'fake receipt marker'),
('manual-provenance','src/control/stopIntent.ts','marker?.reservationDisposition !== "released" || marker.handoffResolution?.requestId !== requestId || !hasValidUsageSettlement(store, run as never)','!hasValidUsageSettlement(store, run as never)',ctl,'backed only by a committed settlement marker'),
('group-used','src/control/settleUnknownUsage.ts','group.used = add(group.used, delta);','',ctl,'charges both buckets'),
('zero-token-ledger','src/control/usageLedger.ts','if (input.tokens === 0) return;','',ctl,'no zero-token ledger rows'),
('claim-cap','src/control/webDispatch.ts','if (!gateClaim(store, groupId, claimGrantTokens(store, groupId, still), at, "start")) return { kind: "blocked" as const, reason: "spend-cap-reached" };','',ctl,'gates the next retry claim'),
('checkpoint-artifacts','src/control/usageSettlement.ts','for (const ref of [...c.artifacts, c.handoff, c.snapshot]) settlementArtifact(store, ref);','',ctl,'a snapshot defect|a artifact defect'),
]
results=[]
for name,file,old,new,test,pattern in mutants:
 p=clone/file;original=p.read_text();assert old in original,(name,old)
 p.write_text(original.replace(old,new,1))
 cmd=['rtk','proxy',str(clone/'node_modules/.bin/vitest'),'run',test,'-t',pattern,'--reporter=dot']
 with (logs/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=clone,env=env,stdout=f,stderr=subprocess.STDOUT)
 p.write_text(original)
 unstaged=len(git('diff'));staged=len(git('diff','--cached'))
 result={'name':name,'file':file,'test':test,'pattern':pattern,'rc':r.returncode,'diffBytes':unstaged,'cachedDiffBytes':staged,'log':str(logs/(name+'.log'))}
 results.append(result);print(json.dumps(result),flush=True)
 assert unstaged==staged==0,result
(root/'mutations.json').write_text(json.dumps(results,indent=2))
cmd=['rtk','proxy',str(clone/'node_modules/.bin/vitest'),'run',ctl,'tests/control/schema10.test.ts',panel,'--reporter=dot']
with (logs/'restored.log').open('w') as f:r=subprocess.run(cmd,cwd=clone,env=env,stdout=f,stderr=subprocess.STDOUT)
print('RESTORED_RC',r.returncode,'DIFF_BYTES',len(git('diff')),'CACHED_DIFF_BYTES',len(git('diff','--cached')),flush=True)
