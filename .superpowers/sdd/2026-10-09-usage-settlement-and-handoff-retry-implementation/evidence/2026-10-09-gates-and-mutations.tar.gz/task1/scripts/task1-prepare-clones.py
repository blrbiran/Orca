import subprocess,os,shutil,json
from pathlib import Path
work=Path('/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca')
root=Path('/private/tmp/orca-task1-clones');root.mkdir(mode=0o700,exist_ok=True)
for name in ['mutation','old-v9']:
 dest=root/name
 if not dest.exists():subprocess.run(['rtk','proxy','/usr/bin/git','clone','--local','--no-hardlinks',str(work),str(dest)],cwd=work,check=True)
 if not (dest/'node_modules').exists():os.symlink(str(work/'node_modules'),str(dest/'node_modules'))
subprocess.run(['rtk','proxy','/usr/bin/git','checkout','--detach','c29676d6d0050d46b9cf61f45ffaee583f9dec76'],cwd=root/'old-v9',check=True)
files=[p for p in subprocess.check_output(['rtk','proxy','/usr/bin/git','diff','--name-only'],cwd=work,text=True).splitlines() if not p.startswith('.superpowers/')]
files += ['src/control/settleUnknownUsage.ts','src/control/usageSettlement.ts','tests/control/fixtures/unknownFailure.ts','tests/control/schema10.test.ts','tests/control/settleUnknownUsage.test.ts','tests/panel/settleUnknownUsage.test.ts']
for f in files:
 p=root/'mutation'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/f,p)
(root/'task-files.json').write_text(json.dumps(files))
print('CLONES',root,'SYNC',len(files))
