import json, subprocess,sys
from pathlib import Path
root=Path('/private/tmp/od9');clone=root/'task2-mutations';env=json.loads((root/'env.json').read_text())
files=['src/control/budget.ts','src/control/continuation.ts','src/control/executionDriver.ts','src/control/executionSnapshot.ts','src/control/queries.ts','src/control/retryTask.ts','src/control/retryGrant.ts','src/control/stopIntent.ts','src/control/webDispatch.ts','src/control/webProtocol.ts','src/panel/controlViews.ts','web/src/controlTypes.ts','web/src/locales/en.ts','web/src/locales/zh.ts','tests/control/handoffFailedRetry.test.ts']
original={f:(clone/f).read_text() for f in files}
def change(f,a,b):
 p=clone/f;s=p.read_text();assert a in s,(f,a);p.write_text(s.replace(a,b))
def mutation(name):
 if name=='strict-source-pending':change('src/control/retryGrant.ts','work.pendingRunId !== null','work.pendingRunId != null')
 if name=='strict-admission-pending':change('src/control/retryTask.ts','if ((held || released) ? work.pendingRunId !== null : work.pendingRunId != null)','if (work.pendingRunId != null)')
 if name=='admission-identity':
  p=clone/'src/control/retryTask.ts';s=p.read_text();a=s.index('        const newest =');b=s.index('        const allocations =',a);p.write_text(s[:a]+s[b:])
 if name=='inactive':change('src/control/retryTask.ts','const held = !live','const held = false && !live')
 if name=='released':change('src/control/retryTask.ts','const released = !live','const released = false && !live')
 if name=='restore-grant':change('src/control/retryTask.ts','work.grant = structuredClone(run.grant);','')
 if name=='source':change('src/control/retryGrant.ts','  const work = subject as Record<string, any>;','  return;\n  const work = subject as Record<string, any>;')
 if name=='no-start':change('src/control/retryGrant.ts','const noStart = run.state','const noStart = false && run.state')
 if name=='restartable':change('src/control/retryGrant.ts','const restartable = run.state','const restartable = false && run.state')
 if name=='clamp':change('src/control/executionDriver.ts','executionPolicy: withinGrant(confirmed.contract.executionPolicy, (run.grant as { work: { tokens: number; activeMs: number; attempts: number } }).work),','executionPolicy: confirmed.contract.executionPolicy,')
 if name=='consumed':change('src/control/retryTask.ts','if (work.continuation != null) delete work.continuation;','')
 if name=='live-clear':
  p=clone/'src/control/queries.ts';s=p.read_text();a=s.index('  // A live retry source');b=s.index('  const body=JSON.stringify(work);',a);p.write_text(s[:a]+s[b:])
  p=clone/'src/control/stopIntent.ts';s=p.read_text();a=s.index('  if (["held", "continuing", "terminal"].includes(state)) {');b=s.index('  const proposal = readBudgetProposal(store, groupId);',a);s=s[:a]+s[b:];s=s.replace('    delete (work as { retryGrantSourceRunId?: string }).retryGrantSourceRunId;','');p.write_text(s)
 if name=='other-usage':change('src/control/retryTask.ts','if ((held || released) && groupUsageUnknown(store, groupId))','if (false && (held || released) && groupUsageUnknown(store, groupId))')
 if name in ['tokens','attempts','runtime']:
  keys={'tokens':('tokenBudget','tokens'),'attempts':('maxAttempts','attempts'),'runtime':('totalRuntimeBudgetMs','activeMs')};key,dim=keys[name];change('src/control/executionDriver.ts',f'{key}: Math.min(policy.{key}, grant.{dim})',f'{key}: policy.{key}')
patterns={'strict-source-pending':'rejects retry source','strict-admission-pending':'refuses reduced retry','admission-identity':'failed predecessor with drifted','inactive':'retries a handoff-settled','released':'retries released manual','restore-grant':'retries a handoff-settled','source':'rejects retry source','no-start':'rearms invalid first','restartable':'resumes a pre-provider','clamp':'retries a handoff-settled','consumed':'retries a handoff-settled','live-clear':'clears the live source|clears live retry','other-usage':'another historical','tokens':'retries a handoff-settled','attempts':'retries a handoff-settled','runtime':'retries a handoff-settled'}
results=json.loads((root/'task2-mutations.json').read_text()) if (root/'task2-mutations.json').exists() else []
try:
 for name in sys.argv[1:] or patterns:
  for f,s in original.items():(clone/f).write_text(s)
  mutation(name)
  cmd=['rtk','proxy','npx','vitest','run','--reporter=dot','tests/control/handoffFailedRetry.test.ts','-t',patterns[name]]
  log=root/'logs'/('task2-mut-'+name+'.log')
  with log.open('w') as out:r=subprocess.run(cmd,cwd=clone,env=env,stdout=out,stderr=subprocess.STDOUT)
  (root/'logs'/('task2-mut-'+name+'.rc')).write_text(str(r.returncode)+'\n')
  results.append({'mutation':name,'RC':r.returncode,'log':str(log),'command':cmd})
  print(name,'RC',r.returncode,'LOG',log,flush=True)
finally:
 for f,s in original.items():(clone/f).write_text(s)
 (root/'task2-mutations.json').write_text(json.dumps(results,indent=2))
