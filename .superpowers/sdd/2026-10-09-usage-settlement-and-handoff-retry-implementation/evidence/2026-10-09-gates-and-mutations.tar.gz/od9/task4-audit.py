from pathlib import Path
import ast,json,subprocess
w=Path('/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca'); checks=[]
def add(task,name,f,old):checks.append({'task':task,'name':name,'file':f,'present':old in (w/f).read_text(),'matches':(w/f).read_text().count(old)})
a=ast.parse(Path('/private/tmp/task1-mutate.py').read_text());rows=next(n.value.elts for n in a.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mutants' for t in n.targets))
for row in rows:
 name,f,old=[ast.literal_eval(n) for n in row.elts[:3]]
 if name=='zero-token-ledger':old='  if (input.tokens === 0) return;\n  insertRow(store, { appliedAt: input.appliedAt, groupId: input.run.groupId'
 add(1,name,f,old)
a=ast.parse(Path('/private/tmp/od9/task2-mutation-run.py').read_text())
for n in ast.walk(a):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='change' and len(n.args)>=2 and all(isinstance(x,ast.Constant) for x in n.args[:2]):
  f,old=[x.value for x in n.args[:2]];add(2,old,f,old)
for f,old in [('src/control/retryTask.ts','        const newest ='),('src/control/retryTask.ts','        const allocations ='),('src/control/queries.ts','  // A live retry source'),('src/control/stopIntent.ts','  if (["held", "continuing", "terminal"].includes(state)) {'),('src/control/executionDriver.ts','tokenBudget: Math.min(policy.tokenBudget, grant.tokens)'),('src/control/executionDriver.ts','maxAttempts: Math.min(policy.maxAttempts, grant.attempts)'),('src/control/executionDriver.ts','totalRuntimeBudgetMs: Math.min(policy.totalRuntimeBudgetMs, grant.activeMs)')]:add(2,old,f,old)
a=ast.parse(Path('/private/tmp/od9/task3-mutations.py').read_text());rows=next(ast.literal_eval(n.value) for n in a.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mutation_specs' for t in n.targets))
for name,f,old,*_ in rows:add(3,name,f,old)
add(3,'empty-resume','web/src/ControlGroupView.tsx','          {handoffActive && view.summary.stopState === "handoff-complete" && (')
proof={'command':'rtk proxy python3 /private/tmp/od9/task4-audit.py','commit':subprocess.check_output(['rtk','proxy','/usr/bin/git','rev-parse','HEAD'],cwd=w).decode().strip(),'checks':checks}
Path('/private/tmp/od9/task4-prior-mutation-code-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2));assert all(c['present'] for c in checks)
