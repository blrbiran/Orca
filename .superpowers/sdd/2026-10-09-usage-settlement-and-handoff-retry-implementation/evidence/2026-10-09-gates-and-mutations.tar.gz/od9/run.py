import json,sys,subprocess
from pathlib import Path
root=Path('/private/tmp/od9')
env=json.loads((root/'env.json').read_text())
work='/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca'
name=sys.argv[1]
cmd=sys.argv[2:]
log=root/'logs'/(name+'.log')
print('COMMAND',cmd,'CWD',work,'LOG',log,flush=True)
with log.open('w') as f:
 r=subprocess.run(cmd,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
print('RC',r.returncode,flush=True)
(root/'logs'/(name+'.rc')).write_text(str(r.returncode)+'\n')
sys.exit(r.returncode)
