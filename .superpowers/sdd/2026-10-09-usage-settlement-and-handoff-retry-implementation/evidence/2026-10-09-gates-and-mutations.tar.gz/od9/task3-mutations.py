import os,json,subprocess,hashlib
from pathlib import Path
main=Path('/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca')
clone=Path('/private/tmp/od9/task3-mutations')
env=json.loads(Path('/private/tmp/od9/env.json').read_text()); env['DEBUG_PRINT_LIMIT']='80'; env['NO_COLOR']='1'
paths=['web/src/App.tsx','web/src/ControlPanel.tsx','web/src/ControlGroupView.tsx','web/src/UsageSettlement.tsx','web/src/TaskDetail.tsx','web/src/controlApi.ts','web/src/locales/en.ts','web/src/locales/zh.ts','web/src/runFacts.ts','web/tests/settleUnknownUsage.test.tsx','web/tests/handoffFailedRetry.test.tsx','web/tests/usageRecoveryFixture.ts','web/tests/controlCommandRecovery.test.tsx','web/tests/i18nPseudo.test.tsx','web/tests/archiveGroup.test.tsx']
def git(where,*args): return subprocess.check_output(['/usr/bin/git',*args],cwd=where)
if not clone.exists():
 subprocess.run(['/usr/bin/git','clone','--local','--no-hardlinks',str(main),str(clone)],check=True)
 (clone/'node_modules').symlink_to(main/'node_modules',target_is_directory=True)
for path in paths: (clone/path).write_bytes((main/path).read_bytes())
original={p:(clone/p).read_text() for p in paths}; main_hash={p:hashlib.sha256((main/p).read_bytes()).hexdigest() for p in paths}
main_diff=git(main,'diff'); main_staged=git(main,'diff','--cached')
mutation_specs=[
 ('owner','web/src/UsageSettlement.tsx','const owner = roles?.includes("owner") === true;','const owner = true;','settleUnknownUsage'),
 ('confirmation','web/src/UsageSettlement.tsx','disabled={!approved}','disabled={false}','settleUnknownUsage'),
 ('amounts','web/src/UsageSettlement.tsx','<ChargeTable amounts={preview.remaining} settled={false} />','', 'settleUnknownUsage'),
 ('reason','web/src/runFacts.ts','if (hasFailureOutcome(run) || run.state === "settled-failed")','if (run.state === "blocked" || run.state === "settled-failed")','handoffFailedRetry'),
 ('held-retry','web/src/runFacts.ts','if (run.state === "settled-recoverable") return work.status', 'if (run.state === "settled-recoverable") return false && work.status','handoffFailedRetry'),
 ('released-retry','web/src/runFacts.ts','return run.state === "settled-failed" && work.status', 'return false && run.state === "settled-failed" && work.status','handoffFailedRetry'),
 ('group-unknown','web/src/runFacts.ts',' || view.ledger.usageUnknown','', 'handoffFailedRetry'),
 ('current','web/src/runFacts.ts','work.currentRunId !== run.runId || ','','handoffFailedRetry'),
 ('manual-continue','web/src/ControlGroupView.tsx',' || run.state === "settled-failed"','', 'handoffFailedRetry'),
 ('account','web/src/App.tsx','roles={account?.user.roles ?? []}','roles={[]}','controlCommandRecovery'),
 ('activity','web/src/TaskDetail.tsx','entry.kind === "usage-settled" && body.method', 'false && entry.kind === "usage-settled" && body.method','settleUnknownUsage'),
]
manifest=[]
def run(name,files):
 cmd=['npm','exec','--workspace','web','--','vitest','run',*[f'tests/{file}.test.tsx' for file in files],'--maxWorkers=2','--reporter=dot']
 log=Path('/private/tmp/od9/logs')/f'task3-mut-{name}.log'
 with log.open('w') as f: result=subprocess.run(cmd,cwd=clone,env=env,stdout=f,stderr=subprocess.STDOUT)
 log.with_suffix('.rc').write_text(str(result.returncode)+'\n')
 manifest.append({'name':name,'command':cmd,'rc':result.returncode,'log':str(log)})
 print(name,result.returncode,flush=True)
 return result.returncode
try:
 for name,path,before,after,file in mutation_specs:
  assert before in original[path],name
  (clone/path).write_text(original[path].replace(before,after))
  assert run(name,[file]) != 0,name
  (clone/path).write_text(original[path])
 path='web/src/ControlGroupView.tsx'; s=original[path]; a=s.index('          {handoffActive && view.summary.stopState === "handoff-complete" && ('); b=s.index('          {view.recoveryBlockers.length',a)
 (clone/path).write_text(s[:a]+s[b:]); assert run('empty-resume',['handoffFailedRetry']) != 0; (clone/path).write_text(s)
 assert run('restored-green',['settleUnknownUsage','handoffFailedRetry','controlCommandRecovery'])==0
finally:
 for p,s in original.items(): (clone/p).write_text(s)
 Path('/private/tmp/od9/task3-mutations.json').write_text(json.dumps(manifest,indent=2))
 proof={'main_commit':git(main,'rev-parse','HEAD').decode().strip(),'clone_commit':git(clone,'rev-parse','HEAD').decode().strip(),'main_diff_before':len(main_diff),'main_diff_after':len(git(main,'diff')),'main_diff_unchanged':main_diff==git(main,'diff'),'main_staged_before':len(main_staged),'main_staged_after':len(git(main,'diff','--cached')),'main_staged_unchanged':main_staged==git(main,'diff','--cached'),'hashes':{p:{'main':hashlib.sha256((main/p).read_bytes()).hexdigest(),'clone':hashlib.sha256((clone/p).read_bytes()).hexdigest(),'unchanged':main_hash[p]==hashlib.sha256((main/p).read_bytes()).hexdigest()} for p in paths}}
 Path('/private/tmp/od9/task3-mutation-proof.json').write_text(json.dumps(proof,indent=2))
