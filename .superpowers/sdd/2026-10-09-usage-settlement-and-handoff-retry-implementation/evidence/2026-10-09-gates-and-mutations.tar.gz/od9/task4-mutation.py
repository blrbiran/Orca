from pathlib import Path
import os,subprocess,json,hashlib
root=Path('/private/tmp/od9'); main=Path('/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca'); clone=root/'task4-mutation'
def git(cwd,*args):return subprocess.check_output(['rtk','proxy','/usr/bin/git',*args],cwd=cwd)
subprocess.run(['rtk','proxy','/usr/bin/git','clone','--local','--no-hardlinks',str(main),str(clone)],check=True)
(clone/'node_modules').symlink_to((main/'node_modules').resolve(),target_is_directory=True)
p=clone/'src/control/retryTask.ts'; original=p.read_bytes(); test='tests/control/handoffFailedRetry.test.ts'
proof={'main_commit':git(main,'rev-parse','HEAD').decode().strip(),'clone_commit':git(clone,'rev-parse','HEAD').decode().strip(),'mutation':'delete only || allocations.some(a => a.state === "continuing") from retrying admission','runs':[]}
def run(name,args):
 cmd=['node_modules/.bin/vitest','run',test,*args,'--maxWorkers=2']
 with (root/'logs'/f'{name}.log').open('w') as f:r=subprocess.run(cmd,cwd=clone,env=os.environ,stdout=f,stderr=subprocess.STDOUT)
 (root/'logs'/f'{name}.rc').write_text(str(r.returncode)+'\n');proof['runs'].append({'command':cmd,'cwd':str(clone),'name':name,'RC':r.returncode});print(name,r.returncode,flush=True)
 return r.returncode
try:
 s=original.decode();old=' || allocations.some(a => a.state === "continuing")';assert s.count(old)==1;p.write_text(s.replace(old,''))
 red=run('task4-mut-direct-continuing-red',['-t','directly retries an active failed continuation from head'])
finally:p.write_bytes(original)
green=run('task4-mut-restored-green',[])
proof.update({'main_diff_bytes':len(git(main,'diff')),'main_cached_bytes':len(git(main,'diff','--cached')),'clone_diff_bytes':len(git(clone,'diff')),'clone_cached_bytes':len(git(clone,'diff','--cached')),'main_clone_source_equal':(main/'src/control/retryTask.ts').read_bytes()==p.read_bytes(),'main_clone_test_equal':(main/test).read_bytes()==(clone/test).read_bytes()})
(root/'task4-mutation-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2));assert red==1 and green==0
