import subprocess
for paths in [['src','tests','scripts'],['/private/tmp/orca-d9-ccloop-ab824d1/src','/private/tmp/orca-d9-ccloop-ab824d1/tests']]:
 cmd=['rtk','rg','-n','ORCA_CONTROL_VERIFY',*paths];r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print('COMMAND',cmd,'RC',r.returncode);print(r.stdout);assert r.returncode in [0,1]
 if paths[0].startswith('/private/'):assert r.returncode==1 and not r.stdout
