from pathlib import Path
import subprocess,hashlib,json
w=Path('/Users/biran/.codex/worktrees/usage-settlement-handoff-retry/Orca');f='.decisions/orca-dev-09cc3ea1.jsonl'
def blob(ref):return subprocess.check_output(['rtk','proxy','/usr/bin/git','show',ref+':'+f],cwd=w)
a=blob('c29676d');b=blob('HEAD');c=(w/f).read_bytes();assert a==b==c
print('BLOB byte equality c29676d == HEAD == working file',len(a),'SHA256',hashlib.sha256(a).hexdigest())
print('HEAD',subprocess.check_output(['rtk','proxy','/usr/bin/git','rev-parse','HEAD'],cwd=w).decode().strip())
print('ORIGINAL DATA',a.decode(),sep='\n')
