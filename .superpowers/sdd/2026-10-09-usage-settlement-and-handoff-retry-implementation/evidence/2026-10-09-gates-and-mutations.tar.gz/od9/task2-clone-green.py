import json,subprocess
from pathlib import Path
r=Path('/private/tmp/od9');env=json.loads((r/'env.json').read_text());cmd=['rtk','proxy','npx','vitest','run','--reporter=dot','tests/control/handoffFailedRetry.test.ts'];log=r/'logs/task2-clone-restored-green.log'
with log.open('w') as out:p=subprocess.run(cmd,cwd=r/'task2-mutations',env=env,stdout=out,stderr=subprocess.STDOUT)
(r/'logs/task2-clone-restored-green.rc').write_text(str(p.returncode)+'\n');print('RC',p.returncode,'LOG',log);raise SystemExit(p.returncode)
