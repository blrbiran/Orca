import json,subprocess
from pathlib import Path
r=Path(__file__).parent
e=json.loads((r/'validator-env.json').read_text())
with (r/'skill-validate-final.log').open('w') as out:
 p=subprocess.run(['/opt/homebrew/bin/python3','/Users/biran/.codex/skills/.system/skill-creator/scripts/quick_validate.py','skills/orca-control'],env=e,stdout=out,stderr=subprocess.STDOUT)
(r/'skill-validate-final.rc').write_text(str(p.returncode)+'\n')
print('skill-validate-final',p.returncode)
raise SystemExit(p.returncode)
