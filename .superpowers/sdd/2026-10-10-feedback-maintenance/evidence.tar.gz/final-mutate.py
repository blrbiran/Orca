import json,subprocess,sys,hashlib
from pathlib import Path
r=Path(__file__).parent;c=Path('/private/tmp/orca-feedback-mutations-20261010')
b=json.loads((r/'final-mutation-base.json').read_text());e=json.loads((r/'env.json').read_text())
mutants=[
('codex-submit', 'web/src/RequirementsPanel.tsx','if (repoId === "" || limitBad || unsupported) return;', 'if (repoId === "" || limitBad) return;'),
('codex-button', 'web/src/RequirementsPanel.tsx','repoId === "" || limitBad || unsupported}>','repoId === "" || limitBad}>'),
('archive-call','web/src/RequirementsPanel.tsx','&& !drafting && blockedRun === null','&& blockedRun === null'),
('archive-stop','web/src/RequirementsPanel.tsx','view.summary.stopState === "handoff-complete" || view.summary.stopState === "handoff-partial"','true'),
('archive-blocked','web/src/RequirementsPanel.tsx','&& !drafting && blockedRun === null','&& !drafting'),
('archived-answer','web/src/RequirementsPanel.tsx','!archived && r.state === "awaiting-answers"','r.state === "awaiting-answers"'),
('archived-draft','web/src/RequirementsPanel.tsx','!props.archived && draft.state === "awaiting-review"','draft.state === "awaiting-review"'),
('archived-retry','web/src/RequirementsPanel.tsx','!archived && (reason !== null || retryable)','(reason !== null || retryable)'),
('archived-filter','web/src/RequirementsPanel.tsx','(showArchived || group.archived !== true)','true'),
('archive-app-route','web/src/App.tsx','|| requirementArchive',''),
('archive-lookup','web/src/App.tsx','if (group?.state === "clarifying" || group?.requirement !== undefined)','if (false)'),
('startup-owner','web/src/App.tsx','command.importPlan !== true && group === undefined','false'),
('accepted-route','web/src/App.tsx','&& owner?.requirement !== undefined','&& false'),
('accepted-refresh','web/src/App.tsx','(requirementArchive && owner?.state !== "clarifying")','false'),
('accepted-lookup-refresh','web/src/App.tsx','if (group.state !== "clarifying") await readControlGroup(command.groupId);',''),
('activity-order','web/src/TaskDetail.tsx','[...entries].reverse().map','entries.map'),
('compact-count','web/src/ControlGroupView.tsx','shortTokens(run.used.tokens, "en")','String(run.used.tokens)'),
('exact-count','web/src/ControlGroupView.tsx','title={formatTokens(run.used.tokens, currentLanguage())}','title=""'),
('auth-frame','web/src/AuthGate.tsx','className="authenticated-shell"','className=""'),
('viewport-height','web/src/styles.css','height: 100vh; height: 100dvh; display: flex','height: auto; display: flex'),
]
rows=[]
for name,file,old,new in mutants:
 assert old in b[file],(name,old)
 for f,s in b.items():(c/f).write_text(s)
 (c/file).write_text(b[file].replace(old,new,1))
 log=r/('final-mutant-'+name+'.log')
 with log.open('w') as out:
  p=subprocess.run([str(c/'node_modules/.bin/vitest'),'run','--root',str(c/'web'),{'RequirementsPanel.tsx':'tests/feedbackRequirements.test.tsx','App.tsx':'tests/requirementsApp.test.tsx','ControlGroupView.tsx':'tests/feedbackReadability.test.tsx','TaskDetail.tsx':'tests/taskActivity.test.tsx','AuthGate.tsx':'tests/authGate.test.tsx','styles.css':'tests/styles.test.ts'}[Path(file).name],'--maxWorkers=1'],cwd=c,env=e,stdout=out,stderr=subprocess.STDOUT)
 (r/('final-mutant-'+name+'.rc')).write_text(str(p.returncode)+'\n')
 for f,s in b.items():(c/f).write_text(s)
 restored=all((c/f).read_text()==s for f,s in b.items())
 work_bytes=len(subprocess.check_output(['/usr/bin/git','-C',str(c),'diff']));cached_bytes=len(subprocess.check_output(['/usr/bin/git','-C',str(c),'diff','--cached']));assert (work_bytes,cached_bytes)==(0,0);rows.append(dict(name=name,rc=p.returncode,restored=restored,work_diff_bytes=work_bytes,cached_diff_bytes=cached_bytes,log=log.name))
 print(name,p.returncode,restored,flush=True)
 (r/'final-mutations.json').write_text(json.dumps(rows,indent=2))
 if p.returncode==0 or not restored:sys.exit(1)
print('all guard deletions rejected and exact working baseline restored')
